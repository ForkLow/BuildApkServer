# OXVA Final Rework

## Perubahan
- Music dipindahkan ke menu Tools. Tidak ada tombol bulat Music di Home.
- Music dapat dicari dan diputar langsung di OXVA.
- Panel Music tersedia dari halaman Music dan dapat tampil di atas aplikasi lain setelah izin overlay Android diberikan.
- Panel Music berbentuk panel kecil, bukan tombol bulat.
- Group Chat: pesan teks, foto/video, reaction, edit, polling.
- Private Chat: pesan teks, foto/video, reaction, edit, block/unblock, polling.
- Status: teks, foto, video, viewer, delete, masa aktif 24 jam.
- Server API diperbaiki agar `path` tidak dipakai sebelum inisialisasi.
- Path database/chat/uploads memakai `__dirname` agar tidak bergantung pada current working directory.
- JSON body limit server 50MB; media dibatasi 25MB.
- `pubspec.yaml` berada di root project ZIP agar CI Flutter dapat menemukannya.

## Server
Masuk ke folder `server` lalu jalankan:

```bash
npm install
node index.js
```

## Flutter
Dari root project:

```bash
flutter pub get
flutter build apk --release
```

Catatan: build APK perlu Flutter SDK/CI. Di environment pengerjaan ini Flutter SDK tidak tersedia, sehingga hanya validasi struktur/sintaks yang dapat dilakukan.
