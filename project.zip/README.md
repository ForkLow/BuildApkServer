# OXVA Dashboard

Flutter dashboard with the OXVA-style home layout plus two new smart features:

- **NGE-HD-IN VIDEO** — select a local video or paste a video URL, then use **CLICK HD IN VIDEO**.
- **OXVA AI / COPILOT** — chat with the Copilot endpoint and attach photos or other files.
- Dashboard quick cards and the floating OXVA feature panel expose both features.
- Tools page also contains direct **Chat AI** and **HD Video** entries.

## API endpoints

- HD Video: `https://api.nexray.eu.cc/tools/v1/hdvideo?resolusi=hd`
- Copilot: `https://api.nexray.eu.cc/ai/copilot`

## Build

```bash
flutter pub get
flutter build apk --release
```

The API response parser accepts common JSON keys such as `answer`, `response`, `message`, `text`, `content`, `result`, and nested `data`/`choices` responses.
