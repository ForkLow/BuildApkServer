package com.dark.darkverse;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.NonNull;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "oxva/music_overlay";
    private static final int OVERLAY_REQUEST = 9101;
    private static final String NOTIFY_CHANNEL = "oxva_chat";
    @Override public void configureFlutterEngine(@NonNull FlutterEngine engine) {
        super.configureFlutterEngine(engine);
        new MethodChannel(engine.getDartExecutor().getBinaryMessenger(), CHANNEL).setMethodCallHandler((call,result)->{
            switch(call.method){
                case "hasOverlayPermission": result.success(hasOverlayPermission()); break;
                case "requestOverlayPermission": requestOverlayPermission(); result.success(true); break;
                case "startMusicOverlay":
                    if(!hasOverlayPermission()){requestOverlayPermission(); result.success(false);}
                    else {startMusicService(call.arguments); result.success(true);}
                    break;
                case "stopMusicOverlay": stopService(new Intent(this, MusicOverlayService.class)); result.success(true); break;
                case "requestNotificationPermission": requestNotificationPermission(); result.success(true); break;
                case "notifyChat":
                    if (call.arguments instanceof java.util.Map) {
                        java.util.Map<?,?> m=(java.util.Map<?,?>)call.arguments;
                        showChatNotification(String.valueOf(m.get("title")), String.valueOf(m.get("body")));
                    }
                    result.success(true); break;
                default: result.notImplemented();
            }
        });
    }
    private boolean hasOverlayPermission(){return Build.VERSION.SDK_INT<Build.VERSION_CODES.M || Settings.canDrawOverlays(this);}
    private void requestOverlayPermission(){if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M&&!Settings.canDrawOverlays(this)){startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())),OVERLAY_REQUEST);}}
    private void startMusicService(Object args){
        Intent i=new Intent(this,MusicOverlayService.class);
        if(args instanceof java.util.Map){java.util.Map<?,?> m=(java.util.Map<?,?>)args;i.putExtra("url",String.valueOf(m.get("url")));i.putExtra("title",String.valueOf(m.get("title")));i.putExtra("artist",String.valueOf(m.get("artist")));}
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)startForegroundService(i);else startService(i);
    }
    private void requestNotificationPermission(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9201);
        }
        ensureNotificationChannel();
    }
    private void ensureNotificationChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch=new NotificationChannel(NOTIFY_CHANNEL,"OXVA Chat",NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Notifikasi pesan Group Chat dan Private Chat");
            nm.createNotificationChannel(ch);
        }
    }
    private void showChatNotification(String title,String body){
        ensureNotificationChannel();
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,NOTIFY_CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true).setDefaults(Notification.DEFAULT_ALL);
        nm.notify((int)(System.currentTimeMillis()%100000),b.build());
    }

}
