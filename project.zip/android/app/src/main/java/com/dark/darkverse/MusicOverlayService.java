package com.dark.darkverse;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;
import java.util.Locale;

public class MusicOverlayService extends Service {
    private static final String CHANNEL_ID = "oxva_music";
    private static final int NOTIFICATION_ID = 2410;
    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private LinearLayout panel;
    private MediaPlayer player;
    private String url = "", title = "Music", artist = "";
    private TextView state;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String value, float size, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans", Typeface.BOLD)); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private GradientDrawable bg(int color, float radius, int strokeColor) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius));
        g.setStroke(dp(1), strokeColor); return g;
    }

    @Override public void onCreate() { super.onCreate(); createChannel(); startForeground(NOTIFICATION_ID, notification()); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) { url = intent.getStringExtra("url"); title = intent.getStringExtra("title"); artist = intent.getStringExtra("artist"); }
        if (url == null) url = ""; if (title == null) title = "Music"; if (artist == null) artist = "";
        if (Settings.canDrawOverlays(this)) { showPanel(); startPlayback(); }
        return START_NOT_STICKY;
    }

    private void startPlayback() {
        try {
            if (player != null) player.release();
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(url);
            player.setOnPreparedListener(mp -> { mp.start(); updateState(); });
            player.setOnCompletionListener(mp -> { mp.seekTo(0); mp.start(); });
            player.setOnErrorListener((mp, what, extra) -> { if (state != null) state.setText("Audio gagal diputar"); return true; });
            player.prepareAsync();
        } catch (Exception e) { if (state != null) state.setText("Audio gagal diputar"); }
    }

    private void showPanel() {
        removePanel(); wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(12),dp(10),dp(12),dp(10));
        panel.setBackground(bg(Color.rgb(12,18,30), 18, Color.rgb(47,111,237)));

        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = text("♪", 22, Color.rgb(87,166,255)); icon.setGravity(Gravity.CENTER); header.addView(icon, new LinearLayout.LayoutParams(dp(34),dp(34)));
        LinearLayout names = new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL);
        TextView titleView = text(title, 12, Color.WHITE); titleView.setSingleLine(true); titleView.setMaxLines(1);
        names.addView(titleView, new LinearLayout.LayoutParams(0,dp(20),1));
        TextView artistView = text(artist, 9, Color.rgb(137,147,166)); artistView.setSingleLine(true); names.addView(artistView,new LinearLayout.LayoutParams(0,dp(15),1));
        header.addView(names,new LinearLayout.LayoutParams(0,dp(38),1));
        TextView close=text("×",22,Color.WHITE); close.setGravity(Gravity.CENTER); close.setOnClickListener(v->stopSelf()); header.addView(close,new LinearLayout.LayoutParams(dp(30),dp(34)));
        panel.addView(header);

        state=text("MUSIC • READY",9,Color.rgb(87,166,255)); panel.addView(state,new LinearLayout.LayoutParams(-1,dp(22)));
        LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER);
        ImageButton prev=button("↶"); prev.setOnClickListener(v->{ if(player!=null) player.seekTo(0); });
        ImageButton play=button("▶"); play.setOnClickListener(v->{ if(player==null)return; if(player.isPlaying())player.pause();else player.start(); updateState(); });
        ImageButton stop=button("■"); stop.setOnClickListener(v->{ if(player!=null){player.pause();player.seekTo(0);updateState();} });
        controls.addView(prev,new LinearLayout.LayoutParams(dp(42),dp(38))); controls.addView(play,new LinearLayout.LayoutParams(dp(50),dp(42))); controls.addView(stop,new LinearLayout.LayoutParams(dp(42),dp(38)));
        panel.addView(controls);

        panel.setOnTouchListener(new ViewDragListener());
        int type=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        params=new WindowManager.LayoutParams(dp(220),dp(132),type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START; params.x=dp(12); params.y=dp(110);
        try { wm.addView(panel,params); } catch(Exception e){ stopSelf(); }
    }

    private ImageButton button(String s){
        ImageButton b=new ImageButton(this);
        b.setBackground(bg(Color.rgb(24,31,48),16,Color.rgb(47,111,237)));
        b.setContentDescription(s);
        b.setImageResource(s.equals("▶") ? android.R.drawable.ic_media_play : s.equals("■") ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_rew);
        b.setColorFilter(Color.WHITE);
        return b;
    }
    private void updateState(){ if(state!=null && player!=null) state.setText(player.isPlaying()?"MUSIC • PLAYING":"MUSIC • PAUSED"); }

    private class ViewDragListener implements android.view.View.OnTouchListener {
        float downX,downY; int startX,startY;
        public boolean onTouch(android.view.View v, MotionEvent e){ switch(e.getAction()){case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();startX=params.x;startY=params.y;return true;case MotionEvent.ACTION_MOVE:params.x=startX+(int)(e.getRawX()-downX);params.y=startY+(int)(e.getRawY()-downY);if(wm!=null&&panel!=null)wm.updateViewLayout(panel,params);return true;}return true; }
    }

    private void removePanel(){if(wm!=null&&panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;}}
    @Override public void onDestroy(){removePanel();if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}

    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL_ID,"OXVA Music",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    private Notification notification(){ Intent launch=getPackageManager().getLaunchIntentForPackage(getPackageName()); PendingIntent pi=PendingIntent.getActivity(this,0,launch,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT); if(Build.VERSION.SDK_INT>=26)return new Notification.Builder(this,CHANNEL_ID).setContentTitle("OXVA Music").setContentText(title).setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(true).build(); return new Notification.Builder(this).setContentTitle("OXVA Music").setContentText(title).setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(true).build(); }
}
