import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'hadis_page.dart';
import 'chat_main_page.dart'; // ✅ Tambahan
import 'ai_chat_page.dart';
import 'hd_video_page.dart';
import 'music_page.dart';

// ===================== DESIGN TOKENS (tema terang, sama dengan landing page) =====================
class _C {
  static const bgTop = Color(0xFFEAF4FF);
  static const bgBottom = Color(0xFFCFE7FF);

  static const cardBg = Color(0xFFF3F8FF);
  static const cardBorder = Color(0xFF0B0B0B);

  static const textDark = Color(0xFF10131A);
  static const textGrey = Color(0xFF7A8394);

  static const blue = Color(0xFF2F6FED);
  static const blueDark = Color(0xFF1B4FC4);
  static const blueLight = Color(0xFF57A6FF);

  static const pink = Color(0xFFFF7FC0);
  static const yellow = Color(0xFFFFD93B);

  static const live    = Color(0xFF16A34A);
  static const danger  = Color(0xFFE0245E);
  static const warning = Color(0xFFC98A00);
  static const islamic = Color(0xFF0E9B6E);
  static const chat    = Color(0xFF7C4DFF); // ✅ Tambahan — aksen ungu khas menu Group Chat
}

class _T {
  static const font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w800,
    color: _C.textDark, letterSpacing: 0.5,
  );
  static TextStyle heading(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textDark,
  );
  static TextStyle label(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w500,
    color: _C.textGrey, letterSpacing: 0.2,
  );
}

// ===================== TOOLS PAGE =====================
class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;
  final String username; // ✅ Tambahan — dibutuhkan ChatMainPagePage

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
    required this.username,
  });

  // Pasangan kategori: [icon, title, subtitle, key]
  static const _categories = [
    {'icon': Icons.auto_awesome_rounded, 'title': 'Chat AI', 'subtitle': 'Copilot + Foto + Berkas', 'key': 'ai'},
    {'icon': Icons.high_quality_rounded, 'title': 'HD Video', 'subtitle': 'Nge-HD-in Video', 'key': 'hdvideo'},
    {'icon': Icons.music_note_rounded, 'title': 'Music', 'subtitle': 'Cari & Putar Musik + Panel', 'key': 'music'},
    {'icon': Icons.forum_rounded,  'title': 'Chat Tools',  'subtitle': 'Chat Semua User',   'key': 'ChatMainPage'}, // ✅ Tambahan — paling atas
    {'icon': Icons.flash_on,       'title': 'DDoS Tools',  'subtitle': 'Attack & Server',  'key': 'ddos'},
    {'icon': Icons.wifi,           'title': 'Network',     'subtitle': 'WiFi & Spam',       'key': 'network'},
    {'icon': Icons.search,         'title': 'OSINT',       'subtitle': 'Investigation',     'key': 'osint'},
    {'icon': Icons.download,       'title': 'Downloader',  'subtitle': 'Social Media',      'key': 'downloader'},
    {'icon': Icons.build,          'title': 'Utilities',   'subtitle': 'Extra Tools',       'key': 'utility'},
    {'icon': Icons.mosque_rounded, 'title': 'Islamic',     'subtitle': 'Hadis & Quran',     'key': 'islamic'},
    {'icon': Icons.rocket_launch,  'title': 'Quick Access','subtitle': 'Favorites',         'key': 'quick'},
  ];

  // Warna per-baris bergantian blue & blueLight
  Color _cardAccent(int i) => i.isEven ? _C.blue : _C.blueLight;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bgBottom,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_C.bgTop, _C.bgBottom],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                  itemCount: _categories.length,
                  itemBuilder: (context, i) {
                    final cat = _categories[i];
                    return _buildToolRow(
                      context: context,
                      index: i,
                      icon: cat['icon'] as IconData,
                      title: cat['title'] as String,
                      subtitle: cat['subtitle'] as String,
                      catKey: cat['key'] as String,
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── HEADER ──────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 22),
      decoration: BoxDecoration(
        color: _C.cardBg,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
        border: const Border(
          bottom: BorderSide(color: _C.cardBorder, width: 2),
          left: BorderSide(color: _C.cardBorder, width: 2),
          right: BorderSide(color: _C.cardBorder, width: 2),
        ),
        boxShadow: const [
          BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(0, 4)),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _C.blue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _C.cardBorder, width: 1.5),
                ),
                child: const Icon(Icons.tune_rounded, color: _C.blue, size: 22),
              ),
              const SizedBox(width: 12),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(text: 'TOOLS ', style: _T.display(20).copyWith(color: _C.textDark)),
                    TextSpan(text: 'DASHBOARD', style: _T.display(20).copyWith(color: _C.blue)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            height: 1.5,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent,
                _C.blue.withOpacity(0.5),
                Colors.transparent,
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Advanced Security & OSINT Tools',
            style: _T.label(13),
          ),
        ],
      ),
    );
  }

  // ── TOOL ROW (satu tools per baris, ditumpuk ke bawah) ────
  Widget _buildToolRow({
    required BuildContext context,
    required int index,
    required IconData icon,
    required String title,
    required String subtitle,
    required String catKey,
  }) {
    // ✅ Group Chat pakai warna ungu, Islamic hijau, sisanya bergantian blue/blueLight
    final color = catKey == 'ChatMainPage'
        ? _C.chat
        : (catKey == 'islamic' ? _C.islamic : _cardAccent(index));

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + index * 80),
      curve: Curves.easeOutBack,
      builder: (_, v, child) => Transform.translate(
        offset: Offset((1 - v) * 30, 0),
        child: Opacity(opacity: v.clamp(0, 1), child: child),
      ),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: GestureDetector(
          onTap: () => _onCategoryTap(context, catKey),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: _C.cardBg,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _C.cardBorder, width: 2),
              boxShadow: const [
                BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
              ],
            ),
            child: Row(
              children: [
                // Icon container
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: color, width: 1.5),
                  ),
                  child: Icon(icon, color: color, size: 24),
                ),
                const SizedBox(width: 14),
                // Text
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: _T.heading(16)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: _T.label(12)),
                    ],
                  ),
                ),
                // Chevron
                Container(
  padding: const EdgeInsets.all(14),
  decoration: BoxDecoration(
    // ✅ Background kotak dibikin lebih gelap biar kontras
    color: Colors.black.withOpacity(0.35), 
    borderRadius: BorderRadius.circular(16),
    border: Border.all(
      color: theme.primaryColor.withOpacity(0.5), // Border lebih tegas
      width: 1.2,
    ),
    boxShadow: [
      BoxShadow(
        color: theme.primaryColor.withOpacity(0.2),
        blurRadius: 10,
        spreadRadius: 1,
      ),
    ],
  ),
  // ✅ Icon dibikin lebih gelap 40% dari warna aslinya, dan ukurannya dibesarin dikit
  child: Icon(
    icon, 
    color: Color.lerp(theme.primaryColor, Colors.black, 0.4) ?? theme.primaryColor, 
    size: 24, 
  ),
),

  void _onCategoryTap(BuildContext context, String key) {
    switch (key) {
      case 'ai':
        Navigator.push(context, MaterialPageRoute(builder: (_) => AiChatPage(username: username)));
        break;
      case 'hdvideo':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const HdVideoPage()));
        break;
      case 'music':
        Navigator.push(context, MaterialPageRoute(builder: (_) => const MusicPage()));
        break;
      case 'ChatMainPage': _openChatMainPage(context); break; // ✅ Sesuaikan key dengan string 'ChatMainPage'
      case 'ddos':      _showDDoSTools(context); break;
      case 'network':   _showNetworkTools(context); break;
      case 'osint':     _showOSINTTools(context); break;
      case 'downloader':_showDownloaderTools(context); break;
      case 'utility':   _showUtilityTools(context); break;
      case 'islamic':   _showIslamicTools(context); break;
      case 'quick':     _showComingSoon(context); break;
    }
  }

  // ✅ Tambahan — langsung buka halaman Group Chat (tidak perlu bottom sheet)
  void _openChatMainPage(BuildContext context) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => ChatMainPage(
        username: username,
        sessionKey: sessionKey,
        role: userRole,
      ),
    ),
  );
}

  // ── BOTTOM SHEET BASE ────────────────────────────────────
  void _showSheet({
    required BuildContext context,
    required String title,
    required IconData headerIcon,
    required Color accentColor,
    required double heightFactor,
    required List<Widget> options,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        height: MediaQuery.of(context).size.height * heightFactor,
        decoration: BoxDecoration(
          color: _C.bgTop,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          border: Border.all(color: _C.cardBorder, width: 2),
          boxShadow: const [
            BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(0, -3)),
          ],
        ),
        child: Column(
          children: [
            // Handle
            Container(
              margin: const EdgeInsets.only(top: 12, bottom: 4),
              width: 36, height: 4,
              decoration: BoxDecoration(
                color: _C.textGrey.withOpacity(0.4),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            // Sheet header
            Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: accentColor, width: 1.5),
                    ),
                    child: Icon(headerIcon, color: accentColor, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Text(title, style: _T.heading(18)),
                ],
              ),
            ),
            // Divider
            Container(
              height: 1.5,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  Colors.transparent,
                  accentColor.withOpacity(0.5),
                  Colors.transparent,
                ]),
              ),
            ),
            // Options
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: options,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── TOOL OPTION ITEM ─────────────────────────────────────
  Widget _buildToolOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    String? badge,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: _C.cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.cardBorder, width: 1.5),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        leading: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color, width: 1.5),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
        title: Text(label, style: _T.heading(14)),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (badge != null)
              Container(
                margin: const EdgeInsets.only(right: 8),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _C.warning.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: _C.warning.withOpacity(0.6)),
                ),
                child: Text(
                  badge,
                  style: TextStyle(
                    fontFamily: _T.font,
                    fontSize: 9,
                    color: _C.warning,
                    letterSpacing: 1,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            Icon(Icons.arrow_forward_ios_rounded, color: _C.textGrey, size: 13),
          ],
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        onTap: onTap,
      ),
    );
  }

  // ── CATEGORY SHEETS ──────────────────────────────────────
  void _showDDoSTools(BuildContext context) {
    _showSheet(
      context: context,
      title: 'DDoS Tools',
      headerIcon: Icons.flash_on,
      accentColor: _C.danger,
      heightFactor: 0.55,
      options: [
        _buildToolOption(
          icon: Icons.flash_on,
          label: 'Attack Panel',
          color: _C.danger,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(
              builder: (_) => AttackPanel(sessionKey: sessionKey, listDoos: listDoos),
            ));
          },
        ),
        _buildToolOption(
          icon: Icons.dns,
          label: 'Manage Server',
          color: _C.danger,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(
              builder: (_) => ManageServerPage(keyToken: sessionKey),
            ));
          },
        ),
      ],
    );
  }

  void _showNetworkTools(BuildContext context) {
    _showSheet(
      context: context,
      title: 'Network Tools',
      headerIcon: Icons.wifi,
      accentColor: _C.blue,
      heightFactor: 0.65,
      options: [
        _buildToolOption(
          icon: Icons.newspaper_outlined,
          label: 'Spam NGL',
          color: _C.blue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => NglPage()));
          },
        ),
        _buildToolOption(
          icon: Icons.wifi_off,
          label: 'WiFi Killer (Internal)',
          color: _C.blue,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => WifiKillerPage()));
          },
        ),
        if (userRole == 'owner' || userRole == 'developer')
          _buildToolOption(
            icon: Icons.router,
            label: 'WiFi Killer (External)',
            color: _C.blue,
            badge: 'VIP',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => WifiInternalPage(sessionKey: sessionKey),
              ));
            },
          ),
      ],
    );
  }

  void _showOSINTTools(BuildContext context) {
    _showSheet(
      context: context,
      title: 'OSINT Tools',
      headerIcon: Icons.search,
      accentColor: _C.blueLight,
      heightFactor: 0.72,
      options: [
        _buildToolOption(
          icon: Icons.badge,
          label: 'NIK Detail',
          color: _C.blueLight,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
          },
        ),
        _buildToolOption(
          icon: Icons.domain,
          label: 'Domain OSINT',
          color: _C.blueLight,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const DomainOsintPage()));
          },
        ),
        _buildToolOption(
          icon: Icons.person_search,
          label: 'Phone Lookup',
          color: _C.blueLight,
          badge: 'SOON',
          onTap: () => _showComingSoon(context),
        ),
        _buildToolOption(
          icon: Icons.email,
          label: 'Email OSINT',
          color: _C.blueLight,
          badge: 'SOON',
          onTap: () => _showComingSoon(context),
        ),
      ],
    );
  }

  void _showDownloaderTools(BuildContext context) {
    _showSheet(
      context: context,
      title: 'Media Downloader',
      headerIcon: Icons.download,
      accentColor: _C.live,
      heightFactor: 0.55,
      options: [
        _buildToolOption(
          icon: Icons.video_library,
          label: 'TikTok Downloader',
          color: _C.live,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
          },
        ),
        _buildToolOption(
          icon: Icons.camera_alt,
          label: 'Instagram Downloader',
          color: _C.live,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
          },
        ),
      ],
    );
  }

  void _showUtilityTools(BuildContext context) {
    _showSheet(
      context: context,
      title: 'Utility Tools',
      headerIcon: Icons.build,
      accentColor: _C.warning,
      heightFactor: 0.65,
      options: [
        _buildToolOption(
          icon: Icons.qr_code,
          label: 'QR Generator',
          color: _C.warning,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
          },
        ),
        _buildToolOption(
          icon: Icons.security,
          label: 'IP Scanner',
          color: _C.warning,
          badge: 'SOON',
          onTap: () => _showComingSoon(context),
        ),
        _buildToolOption(
          icon: Icons.network_check,
          label: 'Port Scanner',
          color: _C.warning,
          badge: 'SOON',
          onTap: () => _showComingSoon(context),
        ),
      ],
    );
  }

  void _showIslamicTools(BuildContext context) {
    _showSheet(
      context: context,
      title: 'Islamic Tools',
      headerIcon: Icons.mosque_rounded,
      accentColor: _C.islamic,
      heightFactor: 0.45,
      options: [
        _buildToolOption(
          icon: Icons.menu_book_rounded,
          label: 'Kumpulan Hadis',
          color: _C.islamic,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const HadisPage()));
          },
        ),
        _buildToolOption(
          icon: Icons.auto_stories_rounded,
          label: "Al-Qur'an",
          color: _C.islamic,
          badge: 'SOON',
          onTap: () => _showComingSoon(context),
        ),
      ],
    );
  }

  // ── SNACKBAR ─────────────────────────────────────────────
  void _showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.hourglass_top_rounded, color: _C.warning, size: 18),
            const SizedBox(width: 10),
            Text(
              'Feature Coming Soon!',
              style: _T.heading(13).copyWith(color: _C.textDark),
            ),
          ],
        ),
        backgroundColor: _C.cardBg,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: _C.cardBorder, width: 1.5),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}