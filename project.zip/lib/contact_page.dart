// contact_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// ── Design Tokens (tema terang, sama dengan halaman lain) ──
class _C {
  static const bgTop = Color(0xFFEAF4FF);
  static const bgBottom = Color(0xFFCFE7FF);

  static const cardBg = Color(0xFFF3F8FF);
  static const cardBorder = Color(0xFF0B0B0B);

  static const accent     = Color(0xFF2F6FED);
  static const accentDim  = Color(0xFF1B4FC4);
  static const accentSoft = Color(0x1A2F6FED);

  static const cyan     = Color(0xFF57A6FF);

  static const textPrimary   = Color(0xFF10131A);
  static const textSecondary = Color(0xFF7A8394);
  static const textMuted     = Color(0xFFA3ADBD);
}

class _T {
  static const font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w800,
    color: _C.textPrimary, letterSpacing: 1,
  );
  static TextStyle heading(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textPrimary, letterSpacing: 0.3,
  );
  static TextStyle label(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w500,
    color: _C.textSecondary, letterSpacing: 0.2,
  );
}

// ── Data kontak ────────────────────────────────────────────
class _ContactItem {
  final String label;
  final IconData icon;
  final Color brandColor;
  final String url;
  final String handle;

  const _ContactItem({
    required this.label,
    required this.icon,
    required this.brandColor,
    required this.url,
    required this.handle,
  });
}

const _contacts = [
  _ContactItem(
    label: 'Telegram',
    icon: FontAwesomeIcons.telegram,
    brandColor: Color(0xFF29B6F6),
    url: 'https://t.me/SenzOkkotsu',
    handle: 'SenzOkkotsu.t.me',
  ),
  _ContactItem(
    label: 'WhatsApp',
    icon: FontAwesomeIcons.whatsapp,
    brandColor: Color(0xFF25D366),
    url: 'https://wa.me/628138768292',
    handle: '+62 8138768292',
  ),
  _ContactItem(
    label: 'TikTok',
    icon: FontAwesomeIcons.tiktok,
    brandColor: Color(0xFFEE1D52),
    url: 'https://www.tiktok.com/@senzokkotsu',
    handle: '@senzokkotsu',
  ),
  _ContactItem(
    label: 'Instagram',
    icon: FontAwesomeIcons.instagram,
    brandColor: Color(0xFFE1306C),
    url: 'https://www.instagram.com/senzokkotsu',
    handle: '@senzokkotsu',
  ),
];

// ── Page ───────────────────────────────────────────────────
class ContactPage extends StatefulWidget {
  const ContactPage({super.key});

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseCtrl;
  late final Animation<double> _pulseAnim;

  final PageController _pageCtrl = PageController(viewportFraction: 0.78);
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _pageCtrl.dispose();
    super.dispose();
  }

  Future<void> _launch(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bgBottom,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          color: _C.textPrimary,
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Customer Service', style: _T.heading(16)),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_C.bgTop, _C.bgBottom],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
              children: [
                const SizedBox(height: 24),
                _buildHeroIcon(),
                const SizedBox(height: 24),
                _buildTitle(),
                const SizedBox(height: 40),
                _buildSectionLabel(),
                const SizedBox(height: 16),
                _buildCardSlider(),
                const SizedBox(height: 20),
                _buildDots(),
                const SizedBox(height: 36),
                _buildListSection(),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Hero icon ─────────────────────────────────────────────
  Widget _buildHeroIcon() {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, __) => Container(
        width: 88,
        height: 88,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _C.cardBg,
          border: Border.all(color: _C.cardBorder, width: 2),
          boxShadow: [
            BoxShadow(
              color: _C.accent.withOpacity(_pulseAnim.value * 0.3),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: const Icon(
          Icons.support_agent_rounded,
          color: _C.accent,
          size: 40,
        ),
      ),
    );
  }

  // ── Title block ───────────────────────────────────────────
  Widget _buildTitle() {
    return Column(
      children: [
        RichText(
          text: TextSpan(
            children: [
              TextSpan(text: 'Need ', style: _T.display(28).copyWith(color: _C.textPrimary)),
              TextSpan(text: 'Help?', style: _T.display(28).copyWith(color: _C.accent)),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Contact us through our social media platforms below.',
          textAlign: TextAlign.center,
          style: _T.label(13),
        ),
      ],
    );
  }

  // ── Section label ─────────────────────────────────────────
  Widget _buildSectionLabel() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          Container(
            width: 4, height: 18,
            decoration: BoxDecoration(
              color: _C.accent,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(width: 10),
          Text('Swipe to explore', style: _T.label(13)),
        ],
      ),
    );
  }

  // ── Horizontal swipe cards ────────────────────────────────
  Widget _buildCardSlider() {
    return SizedBox(
      height: 220,
      child: PageView.builder(
        controller: _pageCtrl,
        itemCount: _contacts.length,
        onPageChanged: (i) {
          HapticFeedback.selectionClick();
          setState(() => _currentPage = i);
        },
        itemBuilder: (context, i) {
          final c = _contacts[i];
          final isActive = i == _currentPage;
          return AnimatedScale(
            scale: isActive ? 1.0 : 0.92,
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
            child: _buildSwipeCard(c, isActive),
          );
        },
      ),
    );
  }

  Widget _buildSwipeCard(_ContactItem c, bool isActive) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        _launch(c.url);
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          color: _C.cardBg,
          border: Border.all(
            color: _C.cardBorder,
            width: isActive ? 2.5 : 2,
          ),
          boxShadow: isActive
              ? const [
                  BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 5)),
                ]
              : const [
                  BoxShadow(color: Colors.black12, blurRadius: 0, offset: Offset(2, 3)),
                ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top: icon + label
              Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: c.brandColor.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: c.brandColor, width: 1.5),
                    ),
                    child: Icon(c.icon, color: c.brandColor, size: 26),
                  ),
                  const SizedBox(width: 14),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(c.label, style: _T.heading(20)),
                      const SizedBox(height: 2),
                      Text(c.handle, style: _T.label(12)),
                    ],
                  ),
                ],
              ),
              // Bottom: tap hint
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: c.brandColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: c.brandColor.withOpacity(0.5)),
                    ),
                    child: Text(
                      'TAP TO OPEN',
                      style: TextStyle(
                        fontFamily: _T.font,
                        fontSize: 9,
                        color: c.brandColor,
                        letterSpacing: 1.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: c.brandColor.withOpacity(0.12),
                      shape: BoxShape.circle,
                      border: Border.all(color: c.brandColor.withOpacity(0.4)),
                    ),
                    child: Icon(
                      Icons.arrow_forward_rounded,
                      color: c.brandColor,
                      size: 16,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Page dots ─────────────────────────────────────────────
  Widget _buildDots() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(_contacts.length, (i) {
        final isActive = i == _currentPage;
        final color = _contacts[i].brandColor;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: isActive ? 20 : 6,
          height: 6,
          decoration: BoxDecoration(
            color: isActive ? color : _C.cardBorder.withOpacity(0.15),
            borderRadius: BorderRadius.circular(4),
          ),
        );
      }),
    );
  }

  // ── List section (vertikal, semua sekaligus) ──────────────
  Widget _buildListSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section header
          Row(
            children: [
              Container(
                width: 4, height: 18,
                decoration: BoxDecoration(
                  color: _C.accent,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(width: 10),
              Text('All Channels', style: _T.label(13)),
            ],
          ),
          const SizedBox(height: 14),
          ..._contacts.map((c) => _buildListTile(c)),
        ],
      ),
    );
  }

  Widget _buildListTile(_ContactItem c) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        _launch(c.url);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _C.cardBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.cardBorder, width: 1.5),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: c.brandColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: c.brandColor, width: 1.3),
              ),
              child: Icon(c.icon, color: c.brandColor, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(c.label, style: _T.heading(14)),
                  Text(c.handle, style: _T.label(11)),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios_rounded, color: _C.textMuted, size: 13),
          ],
        ),
      ),
    );
  }
}