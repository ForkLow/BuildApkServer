// change_password_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config.dart';

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final oldPassCtrl = TextEditingController();
  final newPassCtrl = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool isLoading = false;
  bool _obscurePassword = true;

  // --- TEMA TERANG (biru muda + border hitam) ---
  static const Color bgTop = Color(0xFFEAF4FF);
  static const Color bgBottom = Color(0xFFCFE7FF);
  static const Color cardBg = Color(0xFFF3F8FF);
  static const Color cardBorder = Color(0xFF0B0B0B);

  static const Color accent = Color(0xFF2F6FED);
  static const Color accentDim = Color(0xFF1B4FC4);
  static const Color accentSoft = Color(0x1A2F6FED);

  static const Color textPrimary = Color(0xFF10131A);
  static const Color textSecondary = Color(0xFF7A8394);
  static const Color textMuted = Color(0xFFA3ADBD);

  static const LinearGradient blueGradient = LinearGradient(
    colors: [accentDim, accent],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );

  Future<void> _changePassword() async {
    final oldPass = oldPassCtrl.text.trim();
    final newPass = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _showMessage("Semua field harus diisi.");
      return;
    }

    if (newPass != confirmPass) {
      _showMessage("Password baru tidak cocok dengan konfirmasi.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$apiBaseUrl/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPass,
          "newPass": newPass,
          "sessionKey": widget.sessionKey,
        },
      );

      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _showMessage("Password berhasil diubah!", isSuccess: true);
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
      } else {
        _showMessage(data['message'] ?? "Gagal mengubah password");
      }
    } catch (e) {
      _showMessage("Koneksi error: $e");
    }

    setState(() => isLoading = false);
  }

  void _showMessage(String msg, {bool isSuccess = false}) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: cardBorder, width: 2),
            boxShadow: const [
              BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 6)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  color: (isSuccess ? accent : accent).withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: accent, width: 1.5),
                ),
                child: Icon(
                  isSuccess ? Icons.check_circle_outline_rounded : Icons.info_outline_rounded,
                  color: accent,
                  size: 24,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                isSuccess ? "Sukses" : "Peringatan",
                style: const TextStyle(
                  color: textPrimary,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.w700,
                  fontSize: 17,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                msg,
                textAlign: TextAlign.center,
                style: const TextStyle(color: textSecondary, fontFamily: 'Rajdhani', fontSize: 13),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 13),
                    decoration: BoxDecoration(
                      gradient: blueGradient,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: cardBorder, width: 2),
                      boxShadow: const [
                        BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
                      ],
                    ),
                    child: const Text(
                      "OK",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontFamily: 'Rajdhani', fontWeight: FontWeight.w700, fontSize: 15),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInput(TextEditingController controller, String label, IconData icon, [bool isPassword = false]) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cardBorder, width: 2),
      ),
      child: TextFormField(
        controller: controller,
        obscureText: isPassword ? _obscurePassword : false,
        style: const TextStyle(color: textPrimary, fontSize: 15, fontFamily: 'Rajdhani', fontWeight: FontWeight.w600),
        cursorColor: accent,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: textSecondary, fontFamily: 'Rajdhani'),
          prefixIcon: Icon(icon, color: accent, size: 20),
          suffixIcon: isPassword
              ? IconButton(
                  icon: Icon(
                    _obscurePassword ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                    color: textMuted,
                    size: 20,
                  ),
                  onPressed: () {
                    setState(() {
                      _obscurePassword = !_obscurePassword;
                    });
                  },
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 4),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBottom,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: textPrimary, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          "CHANGE PASSWORD",
          style: TextStyle(
            color: textPrimary,
            fontFamily: 'Rajdhani',
            fontWeight: FontWeight.w800,
            letterSpacing: 1,
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgTop, bgBottom],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 12),

              Center(
                child: Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: cardBg,
                    border: Border.all(color: cardBorder, width: 2),
                    boxShadow: const [
                      BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 5)),
                    ],
                  ),
                  child: const Icon(Icons.lock_reset_rounded, color: accent, size: 44),
                ),
              ),
              const SizedBox(height: 20),

              const Center(
                child: Text(
                  "SECURITY UPDATE",
                  style: TextStyle(
                    color: textPrimary,
                    fontSize: 20,
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Center(
                child: Text(
                  "Masukkan password lama dan baru.",
                  style: TextStyle(
                    color: textSecondary,
                    fontFamily: 'Rajdhani',
                    fontSize: 13,
                  ),
                ),
              ),

              const SizedBox(height: 36),

              _buildInput(oldPassCtrl, "Old Password", Icons.lock_outline_rounded, true),
              _buildInput(newPassCtrl, "New Password", Icons.vpn_key_rounded, true),
              _buildInput(confirmPassCtrl, "Confirm Password", Icons.enhanced_encryption_rounded, true),

              const SizedBox(height: 26),

              GestureDetector(
                onTap: isLoading ? null : _changePassword,
                child: Container(
                  width: double.infinity,
                  height: 55,
                  decoration: BoxDecoration(
                    gradient: blueGradient,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: cardBorder, width: 2),
                    boxShadow: const [
                      BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 5)),
                    ],
                  ),
                  child: Center(
                    child: isLoading
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: Colors.white,
                            ),
                          )
                        : const Text(
                            "UPDATE PASSWORD",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Rajdhani',
                              letterSpacing: 1,
                              fontSize: 15,
                            ),
                          ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}