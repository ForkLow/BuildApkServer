import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─────────────────────────────────────────────────────────────────────────────
// UNO CARD GAME  —  1 Player vs 3 Bots
// ─────────────────────────────────────────────────────────────────────────────

// ══════════════════════════════════════════════════════════
// MODEL
// ══════════════════════════════════════════════════════════

enum UnoColor { red, yellow, green, blue, wild }
enum UnoType  { zero, one, two, three, four, five, six, seven, eight, nine,
                skip, reverse, drawTwo, wild, wildDrawFour }

class UnoCard {
  final UnoColor color;
  final UnoType  type;
  UnoColor? chosenColor; // untuk wild

  UnoCard(this.color, this.type);

  bool get isWild => color == UnoColor.wild;
  bool get isAction => type == UnoType.skip || type == UnoType.reverse ||
      type == UnoType.drawTwo || isWild || type == UnoType.wildDrawFour;

  int get point {
    if (type.index <= UnoType.nine.index) return type.index;
    if (type == UnoType.skip || type == UnoType.reverse || type == UnoType.drawTwo) return 20;
    return 50;
  }

  String get label {
    switch (type) {
      case UnoType.skip:        return '⊘';
      case UnoType.reverse:     return '⇄';
      case UnoType.drawTwo:     return '+2';
      case UnoType.wild:        return 'W';
      case UnoType.wildDrawFour:return '+4';
      default:                  return type.index.toString();
    }
  }

  Color get displayColor {
    final c = isWild && chosenColor != null ? chosenColor! : color;
    switch (c) {
      case UnoColor.red:    return const Color(0xFFE53935);
      case UnoColor.yellow: return const Color(0xFFFDD835);
      case UnoColor.green:  return const Color(0xFF43A047);
      case UnoColor.blue:   return const Color(0xFF1E88E5);
      case UnoColor.wild:   return const Color(0xFF212121);
    }
  }

  UnoCard clone() => UnoCard(color, type)..chosenColor = chosenColor;
}

// ══════════════════════════════════════════════════════════
// DECK BUILDER
// ══════════════════════════════════════════════════════════

List<UnoCard> buildDeck() {
  final deck = <UnoCard>[];
  for (final c in [UnoColor.red, UnoColor.yellow, UnoColor.green, UnoColor.blue]) {
    deck.add(UnoCard(c, UnoType.zero));
    for (var t = UnoType.one; t.index <= UnoType.drawTwo.index; t = UnoType.values[t.index + 1]) {
      deck.add(UnoCard(c, t));
      deck.add(UnoCard(c, t));
    }
  }
  for (var i = 0; i < 4; i++) {
    deck.add(UnoCard(UnoColor.wild, UnoType.wild));
    deck.add(UnoCard(UnoColor.wild, UnoType.wildDrawFour));
  }
  deck.shuffle(Random());
  return deck;
}

// ══════════════════════════════════════════════════════════
// GAME STATE
// ══════════════════════════════════════════════════════════

class UnoGame extends ChangeNotifier {
  static const int numPlayers = 4; // 0 = human, 1-3 = bot

  late List<List<UnoCard>> hands;
  late List<UnoCard> drawPile;
  late List<UnoCard> discardPile;
  late int currentPlayer;
  late int direction; // 1 = clockwise, -1 = counter
  bool gameOver = false;
  int winner = -1;
  bool waitingForColor = false; // wild played, choosing color
  String log = '';
  bool unoCallable = false; // human can call UNO
  bool botThinking = false;

  final _rng = Random();

  void startGame() {
    drawPile = buildDeck();
    discardPile = [];
    hands = List.generate(numPlayers, (_) => <UnoCard>[]);
    direction = 1;
    currentPlayer = 0;
    gameOver = false;
    winner = -1;
    waitingForColor = false;
    unoCallable = false;
    botThinking = false;
    log = 'Game started!';

    // Deal 7 cards each
    for (var i = 0; i < 7; i++) {
      for (var p = 0; p < numPlayers; p++) {
        hands[p].add(_draw());
      }
    }

    // Flip first card — must be number (not wild)
    UnoCard first;
    do {
      first = _draw();
    } while (first.isWild);
    discardPile.add(first);

    notifyListeners();
    if (currentPlayer != 0) _scheduleBotTurn();
  }

  UnoCard get topCard => discardPile.last;

  UnoCard _draw() {
    if (drawPile.isEmpty) {
      final top = discardPile.removeLast();
      drawPile = discardPile..shuffle(_rng);
      discardPile = [top];
    }
    return drawPile.removeLast();
  }

  bool canPlay(UnoCard card) {
    if (card.isWild) return true;
    final top = topCard;
    final effectiveColor = top.isWild ? top.chosenColor ?? top.color : top.color;
    return card.color == effectiveColor || card.type == top.type;
  }

  // ── Human plays a card ────────────────────────────────
  void humanPlay(int cardIndex) {
    if (currentPlayer != 0 || gameOver || waitingForColor || botThinking) return;
    final card = hands[0][cardIndex];
    if (!canPlay(card)) {
      log = 'Cannot play that card!';
      notifyListeners();
      return;
    }
    hands[0].removeAt(cardIndex);
    discardPile.add(card);
    log = 'You played ${card.label}';

    if (card.isWild) {
      waitingForColor = true;
      notifyListeners();
      return;
    }

    _applyAction(card, 0);
    _checkWin(0);
  }

  // ── Human chooses wild color ──────────────────────────
  void chooseColor(UnoColor color) {
    if (!waitingForColor) return;
    topCard.chosenColor = color;
    waitingForColor = false;
    log = 'You chose ${color.name}';
    _applyAction(topCard, 0);
    _checkWin(0);
  }

  // ── Human draws ──────────────────────────────────────
  void humanDraw() {
    if (currentPlayer != 0 || gameOver || waitingForColor || botThinking) return;
    final card = _draw();
    hands[0].add(card);
    log = 'You drew a card';
    if (canPlay(card)) {
      log += ' (you can play it!)';
    } else {
      _advanceTurn();
    }
    notifyListeners();
    if (currentPlayer != 0) _scheduleBotTurn();
  }

  // ── Apply card effect ─────────────────────────────────
  void _applyAction(UnoCard card, int player) {
    _advanceTurn();
    switch (card.type) {
      case UnoType.skip:
        log += ' → next player skipped';
        _advanceTurn();
        break;
      case UnoType.reverse:
        direction *= -1;
        log += ' → direction reversed';
        if (numPlayers == 2) _advanceTurn(); // reverse = skip in 2p
        break;
      case UnoType.drawTwo:
        final next = currentPlayer;
        hands[next].add(_draw());
        hands[next].add(_draw());
        log += ' → ${_name(next)} draws 2';
        _advanceTurn();
        break;
      case UnoType.wildDrawFour:
        final next = currentPlayer;
        for (var i = 0; i < 4; i++) hands[next].add(_draw());
        log += ' → ${_name(next)} draws 4';
        _advanceTurn();
        break;
      default:
        break;
    }
    notifyListeners();
    if (currentPlayer != 0 && !gameOver) _scheduleBotTurn();
  }

  void _advanceTurn() {
    currentPlayer = (currentPlayer + direction + numPlayers) % numPlayers;
  }

  void _checkWin(int player) {
    if (hands[player].isEmpty) {
      gameOver = true;
      winner = player;
      log = '${_name(player)} wins! 🎉';
      notifyListeners();
    }
  }

  String _name(int p) => p == 0 ? 'You' : 'Bot ${p}';

  // ── Bot AI ─────────────────────────────────────────────
  void _scheduleBotTurn() {
    if (gameOver || waitingForColor) return;
    botThinking = true;
    notifyListeners();
    Future.delayed(const Duration(milliseconds: 900), _doBotTurn);
  }

  void _doBotTurn() {
    if (gameOver || currentPlayer == 0) {
      botThinking = false;
      notifyListeners();
      return;
    }
    final p = currentPlayer;
    final hand = hands[p];

    // Find playable cards — prefer non-wild first
    final playable = hand.where(canPlay).toList();
    playable.sort((a, b) => (a.isWild ? 1 : 0).compareTo(b.isWild ? 1 : 0));

    if (playable.isEmpty) {
      // Draw
      final card = _draw();
      hand.add(card);
      log = '${_name(p)} draws';
      if (canPlay(card)) {
        // Play drawn card immediately
        hand.remove(card);
        discardPile.add(card);
        log = '${_name(p)} draws & plays ${card.label}';
        if (card.isWild) {
          // Bot picks most common color in hand
          card.chosenColor = _botPickColor(p);
        }
        botThinking = false;
        _applyAction(card, p);
        _checkWin(p);
        return;
      } else {
        _advanceTurn();
        botThinking = false;
        notifyListeners();
        if (currentPlayer != 0 && !gameOver) _scheduleBotTurn();
        return;
      }
    }

    final card = playable.first;
    hand.remove(card);
    discardPile.add(card);
    log = '${_name(p)} plays ${card.label}';

    if (card.isWild) {
      card.chosenColor = _botPickColor(p);
      log += ' → picks ${card.chosenColor!.name}';
    }

    botThinking = false;
    _applyAction(card, p);
    _checkWin(p);
  }

  UnoColor _botPickColor(int p) {
    final counts = <UnoColor, int>{};
    for (final c in hands[p]) {
      if (!c.isWild) counts[c.color] = (counts[c.color] ?? 0) + 1;
    }
    if (counts.isEmpty) return UnoColor.values[_rng.nextInt(4)];
    return counts.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
  }
}

// ══════════════════════════════════════════════════════════
// PAGE
// ══════════════════════════════════════════════════════════

class UnoPage extends StatefulWidget {
  const UnoPage({super.key});
  @override
  State<UnoPage> createState() => _UnoPageState();
}

class _UnoPageState extends State<UnoPage> with TickerProviderStateMixin {
  final _game = UnoGame();
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 1))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _game.addListener(() => setState(() {}));
    _game.startGame();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  // ── Colors ──────────────────────────────────────────────
  static const _bg  = Color(0xFF0F1B0F);
  static const _bg2 = Color(0xFF162316);
  static const _surface = Color(0xFF1E2E1E);

  // ── BUILD ────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (!_game.gameOver && _game.drawPile.isEmpty && _game.discardPile.length <= 1) {
      return _buildLoading();
    }

    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg2,
        foregroundColor: Colors.white,
        title: const Text('UNO',
            style: TextStyle(fontFamily: 'Rajdhani', fontSize: 22,
                fontWeight: FontWeight.w800, letterSpacing: 3)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () {
              HapticFeedback.lightImpact();
              _game.startGame();
            },
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: Colors.white12),
        ),
      ),
      body: _game.gameOver ? _buildGameOver() : _buildGame(),
    );
  }

  Widget _buildLoading() => const Scaffold(
        backgroundColor: Color(0xFF0F1B0F),
        body: Center(child: CircularProgressIndicator(color: Colors.green)),
      );

  // ── GAME OVER ────────────────────────────────────────────
  Widget _buildGameOver() {
    final isHuman = _game.winner == 0;
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF0F1B0F), Color(0xFF162316)],
        ),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(isHuman ? '🏆' : '😢',
                style: const TextStyle(fontSize: 72)),
            const SizedBox(height: 16),
            Text(
              isHuman ? 'YOU WIN!' : '${_game._name(_game.winner)} Wins!',
              style: TextStyle(
                fontFamily: 'Rajdhani', fontSize: 32,
                fontWeight: FontWeight.w800,
                color: isHuman ? const Color(0xFFFDD835) : Colors.white70,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 8),
            Text(_game.log,
                style: const TextStyle(color: Colors.white54, fontSize: 14)),
            const SizedBox(height: 40),
            _buildActionBtn('PLAY AGAIN', const Color(0xFF43A047), () {
              HapticFeedback.lightImpact();
              _game.startGame();
            }),
          ],
        ),
      ),
    );
  }

  // ── MAIN GAME ────────────────────────────────────────────
  Widget _buildGame() {
    return Column(
      children: [
        // Bots area (top)
        _buildBotsRow(),
        // Table (center)
        Expanded(child: _buildTable()),
        // Log bar
        _buildLogBar(),
        // Human hand (bottom)
        _buildHumanHand(),
        const SizedBox(height: 8),
      ],
    );
  }

  // ── BOTS ROW ─────────────────────────────────────────────
  Widget _buildBotsRow() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      color: _bg2,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [1, 2, 3].map((p) => _buildBotChip(p)).toList(),
      ),
    );
  }

  Widget _buildBotChip(int p) {
    final isActive = _game.currentPlayer == p && !_game.gameOver;
    final count = _game.hands[p].length;
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, __) => Transform.scale(
        scale: isActive ? _pulseAnim.value : 1.0,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: isActive
                ? const Color(0xFF43A047).withOpacity(0.2)
                : _surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isActive
                  ? const Color(0xFF43A047)
                  : Colors.white24,
              width: isActive ? 2 : 1,
            ),
          ),
          child: Column(
            children: [
              Text('Bot $p',
                  style: TextStyle(
                    fontFamily: 'Rajdhani', fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: isActive ? const Color(0xFF43A047) : Colors.white54,
                  )),
              const SizedBox(height: 2),
              Row(
                children: [
                  const Icon(Icons.style_rounded, size: 12, color: Colors.white38),
                  const SizedBox(width: 4),
                  Text('$count',
                      style: TextStyle(
                        fontFamily: 'Rajdhani', fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: count == 1
                            ? const Color(0xFFE53935)
                            : Colors.white,
                      )),
                ],
              ),
              if (count == 1)
                const Text('UNO!',
                    style: TextStyle(
                        color: Color(0xFFE53935),
                        fontSize: 9,
                        fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  // ── TABLE ─────────────────────────────────────────────────
  Widget _buildTable() {
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: Alignment.center,
          radius: 0.8,
          colors: [
            const Color(0xFF1A2E1A),
            _bg,
          ],
        ),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Direction indicator
          Positioned(
            top: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _game.direction == 1 ? '↻ Clockwise' : '↺ Counter',
                style: const TextStyle(color: Colors.white38, fontSize: 11,
                    fontFamily: 'Rajdhani'),
              ),
            ),
          ),

          // Draw pile + Discard pile
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Draw pile
              GestureDetector(
                onTap: _game.currentPlayer == 0 && !_game.gameOver &&
                        !_game.waitingForColor && !_game.botThinking
                    ? _game.humanDraw
                    : null,
                child: Stack(
                  children: [
                    _buildCardBack(label: '${_game.drawPile.length}'),
                    if (_game.currentPlayer == 0 && !_game.gameOver &&
                        !_game.waitingForColor && !_game.botThinking)
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: Colors.white38, width: 1.5),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 24),
              // Discard pile (top card)
              _buildCard(_game.topCard, size: 80),
            ],
          ),

          // Wild color chooser
          if (_game.waitingForColor) _buildColorPicker(),

          // Bot thinking indicator
          if (_game.botThinking)
            Positioned(
              bottom: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white10,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 12, height: 12,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white54),
                    ),
                    SizedBox(width: 8),
                    Text('Bot thinking...',
                        style: TextStyle(
                            color: Colors.white54, fontSize: 12,
                            fontFamily: 'Rajdhani')),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ── LOG BAR ───────────────────────────────────────────────
  Widget _buildLogBar() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      color: _surface,
      child: Text(
        _game.log,
        style: const TextStyle(
            color: Colors.white70, fontSize: 12, fontFamily: 'Rajdhani'),
        textAlign: TextAlign.center,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  // ── HUMAN HAND ───────────────────────────────────────────
  Widget _buildHumanHand() {
    final isMyTurn = _game.currentPlayer == 0 && !_game.gameOver &&
        !_game.waitingForColor && !_game.botThinking;
    final hand = _game.hands[0];

    return Container(
      color: _bg2,
      padding: const EdgeInsets.fromLTRB(0, 8, 0, 0),
      child: Column(
        children: [
          // Hand label + card count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  isMyTurn ? 'YOUR TURN' : 'YOUR HAND',
                  style: TextStyle(
                    fontFamily: 'Rajdhani', fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: isMyTurn
                        ? const Color(0xFF43A047)
                        : Colors.white38,
                    letterSpacing: 1.5,
                  ),
                ),
                Row(
                  children: [
                    if (hand.length == 1)
                      GestureDetector(
                        onTap: () {
                          HapticFeedback.heavyImpact();
                          // UNO call (cosmetic)
                        },
                        child: Container(
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            color: const Color(0xFFE53935),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Text('UNO!',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'Rajdhani',
                                  fontWeight: FontWeight.w800,
                                  fontSize: 12)),
                        ),
                      ),
                    Text('${hand.length} cards',
                        style: const TextStyle(
                            color: Colors.white38,
                            fontSize: 11,
                            fontFamily: 'Rajdhani')),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          // Scrollable hand
          SizedBox(
            height: 110,
            child: hand.isEmpty
                ? const Center(
                    child: Text('No cards',
                        style: TextStyle(color: Colors.white38)))
                : ListView.builder(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    itemCount: hand.length,
                    itemBuilder: (_, i) {
                      final card = hand[i];
                      final playable = isMyTurn && _game.canPlay(card);
                      return GestureDetector(
                        onTap: playable
                            ? () {
                                HapticFeedback.lightImpact();
                                _game.humanPlay(i);
                              }
                            : null,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          margin: const EdgeInsets.only(right: 8),
                          transform: Matrix4.translationValues(
                              0, playable ? -10 : 0, 0),
                          child: _buildCard(card,
                              size: 68,
                              dimmed: isMyTurn && !playable),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  // ── COLOR PICKER ──────────────────────────────────────────
  Widget _buildColorPicker() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A).withOpacity(0.95),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white24),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('Choose a color',
              style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Rajdhani',
                  fontSize: 16,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              UnoColor.red, UnoColor.yellow,
              UnoColor.green, UnoColor.blue,
            ].map((c) {
              final col = UnoCard(c, UnoType.zero).displayColor;
              return GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  _game.chooseColor(c);
                },
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    color: col,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white54, width: 2),
                    boxShadow: [
                      BoxShadow(color: col.withOpacity(0.6), blurRadius: 12),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // CARD WIDGETS
  // ══════════════════════════════════════════════════════════

  Widget _buildCard(UnoCard card, {double size = 72, bool dimmed = false}) {
    final bg = card.displayColor;
    final isWild = card.isWild;

    return Opacity(
      opacity: dimmed ? 0.45 : 1.0,
      child: Container(
        width: size,
        height: size * 1.45,
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(size * 0.14),
          border: Border.all(color: Colors.white, width: size * 0.03),
          boxShadow: [
            BoxShadow(
                color: bg.withOpacity(0.5),
                blurRadius: 8, offset: const Offset(2, 4)),
          ],
        ),
        child: Stack(
          children: [
            // Inner oval
            Center(
              child: Container(
                width: size * 0.72,
                height: size * 1.05,
                decoration: BoxDecoration(
                  color: isWild ? Colors.transparent : Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(size * 0.1),
                  border: isWild
                      ? null
                      : Border.all(color: Colors.white24, width: 1),
                  gradient: isWild
                      ? const SweepGradient(colors: [
                          Color(0xFFE53935), Color(0xFFFDD835),
                          Color(0xFF43A047), Color(0xFF1E88E5),
                          Color(0xFFE53935),
                        ])
                      : null,
                ),
              ),
            ),
            // Center label
            Center(
              child: Text(
                card.label,
                style: TextStyle(
                  fontSize: size * 0.38,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                  shadows: const [
                    Shadow(color: Colors.black45, blurRadius: 4,
                        offset: Offset(1, 2)),
                  ],
                ),
              ),
            ),
            // Top-left small label
            Positioned(
              top: size * 0.06, left: size * 0.08,
              child: Text(card.label,
                  style: TextStyle(
                      fontSize: size * 0.17,
                      fontWeight: FontWeight.w900,
                      color: Colors.white70)),
            ),
            // Bottom-right small label (rotated)
            Positioned(
              bottom: size * 0.06, right: size * 0.08,
              child: Transform.rotate(
                angle: pi,
                child: Text(card.label,
                    style: TextStyle(
                        fontSize: size * 0.17,
                        fontWeight: FontWeight.w900,
                        color: Colors.white70)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCardBack({String label = ''}) {
    return Container(
      width: 80,
      height: 116,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: const LinearGradient(
          colors: [Color(0xFF212121), Color(0xFF424242)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: Colors.white, width: 2.5),
        boxShadow: const [
          BoxShadow(color: Colors.black54, blurRadius: 8, offset: Offset(2, 4)),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Diagonal stripe
          Transform.rotate(
            angle: -0.5,
            child: Container(
              width: 60, height: 90,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: const SweepGradient(colors: [
                  Color(0xFFE53935), Color(0xFFFDD835),
                  Color(0xFF43A047), Color(0xFF1E88E5),
                  Color(0xFFE53935),
                ]),
              ),
            ),
          ),
          // UNO text
          Text('UNO',
              style: const TextStyle(
                fontFamily: 'Rajdhani', fontSize: 18,
                fontWeight: FontWeight.w900, color: Colors.white,
                letterSpacing: 2,
                shadows: [Shadow(color: Colors.black, blurRadius: 4)],
              )),
          if (label.isNotEmpty)
            Positioned(
              bottom: 6,
              child: Text(label,
                  style: const TextStyle(
                      color: Colors.white54, fontSize: 10,
                      fontFamily: 'Rajdhani')),
            ),
        ],
      ),
    );
  }

  Widget _buildActionBtn(String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 14),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.5), blurRadius: 16,
                offset: const Offset(0, 6)),
          ],
        ),
        child: Text(label,
            style: const TextStyle(
                fontFamily: 'Rajdhani', fontSize: 18,
                fontWeight: FontWeight.w800, color: Colors.white,
                letterSpacing: 1.5)),
      ),
    );
  }
}