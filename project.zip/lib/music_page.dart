import 'dart:convert';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

class MusicPage extends StatefulWidget {
  const MusicPage({super.key});
  @override
  State<MusicPage> createState() => _MusicPageState();
}

class _MusicPageState extends State<MusicPage> {
  static const _channel = MethodChannel('azzorible/music_overlay');
  final _search = TextEditingController();
  final _player = AudioPlayer();
  Map<String, dynamic>? _track;
  bool _loading = false;
  bool _playing = false;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;

  static const bg = Color(0xFF050507);
  static const card = Color(0xFF11131A);
  static const blue = Color(0xFF2F6FED);
  static const cyan = Color(0xFF57A6FF);
  static const text = Color(0xFFF2F6FF);
  static const muted = Color(0xFF8993A6);

  @override
  void initState() {
    super.initState();
    _player.onDurationChanged.listen((d) { if (mounted) setState(() => _duration = d); });
    _player.onPositionChanged.listen((p) { if (mounted) setState(() => _position = p); });
    _player.onPlayerStateChanged.listen((s) { if (mounted) setState(() => _playing = s == PlayerState.playing); });
  }

  @override
  void dispose() { _search.dispose(); _player.dispose(); super.dispose(); }

  Future<void> _searchTrack() async {
    final q = _search.text.trim();
    if (q.isEmpty || _loading) return;
    setState(() { _loading = true; _track = null; });
    try {
      final uri = Uri.parse('https://api.deline.web.id/downloader/spotifyplay').replace(queryParameters: {'q': q});
      final r = await http.get(uri).timeout(const Duration(seconds: 30));
      if (r.statusCode != 200) throw Exception('Server ${r.statusCode}');
      final data = jsonDecode(r.body);
      if (data is! Map || data['status'] != true || data['result'] == null) throw Exception('Lagu tidak ditemukan');
      final result = Map<String, dynamic>.from(data['result']);
      final dlink = result['dlink']?.toString() ?? '';
      if (dlink.isEmpty) throw Exception('Link audio tidak tersedia');
      setState(() => _track = result);
      await _player.stop();
      await _player.setSourceUrl(dlink);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally { if (mounted) setState(() => _loading = false); }
  }

  Map<String, dynamic>? get _meta => _track == null ? null : Map<String, dynamic>.from((_track!['metadata'] as Map?) ?? {});
  String get _url => _track?['dlink']?.toString() ?? '';

  Future<void> _toggle() async {
    if (_url.isEmpty) return;
    if (_playing) await _player.pause(); else await _player.resume();
  }
  Future<void> _replay() async { if (_url.isNotEmpty) { await _player.seek(Duration.zero); await _player.resume(); } }

  Future<void> _openPanel() async {
    if (_url.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cari lagu terlebih dahulu.'))); return; }
    try {
      await _player.pause();
      final allowed = await _channel.invokeMethod<bool>('hasOverlayPermission') ?? false;
      if (!allowed) {
        await _channel.invokeMethod('requestOverlayPermission');
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Izinkan AZZORIBLE tampil di atas aplikasi lain, lalu tekan Panel Musik lagi.')));
        return;
      }
      await _channel.invokeMethod('startMusicOverlay', {
        'url': _url,
        'title': _meta?['title']?.toString() ?? 'Unknown Title',
        'artist': _meta?['artist']?.toString() ?? 'Unknown Artist',
      });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Panel gagal: $e')));
    }
  }

  String _fmt(Duration d) => '${d.inMinutes.remainder(60).toString().padLeft(2, '0')}:${d.inSeconds.remainder(60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final meta = _meta;
    final cover = meta?['cover']?.toString() ?? '';
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(backgroundColor: bg, foregroundColor: text, title: const Text('MUSIC', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 2)), actions: [
        IconButton(onPressed: _url.isEmpty ? null : _openPanel, icon: const Icon(Icons.open_in_new_rounded), tooltip: 'Panel Musik'),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Expanded(child: TextField(controller: _search, onSubmitted: (_) => _searchTrack(), style: const TextStyle(color: text), decoration: InputDecoration(hintText: 'Cari lagu atau artis...', hintStyle: const TextStyle(color: muted), prefixIcon: const Icon(Icons.search, color: cyan), filled: true, fillColor: card, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)))),
          const SizedBox(width: 8),
          IconButton.filled(onPressed: _loading ? null : _searchTrack, icon: _loading ? const SizedBox(width: 20,height:20,child:CircularProgressIndicator(strokeWidth:2,color:Colors.white)) : const Icon(Icons.search)),
        ]),
        const SizedBox(height: 24),
        if (meta == null) const Padding(padding: EdgeInsets.only(top: 120), child: Column(children: [Icon(Icons.music_note_rounded, size: 76, color: blue), SizedBox(height: 14), Text('Cari lagu favoritmu', style: TextStyle(color: text, fontSize: 22, fontWeight: FontWeight.w800)), SizedBox(height: 6), Text('Putar langsung di AZZORIBLE atau buka Panel Musik.', style: TextStyle(color: muted))]))
        else ...[
          Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(24), border: Border.all(color: blue.withOpacity(.55))), child: Column(children: [
            ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.network(cover, width: 230, height: 230, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width:230,height:230,color:bg,child:const Icon(Icons.music_note,color:blue,size:80)))),
            const SizedBox(height: 18),
            Text(meta['title']?.toString() ?? 'Unknown Title', maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color:text,fontSize:20,fontWeight:FontWeight.w800)),
            const SizedBox(height:5), Text(meta['artist']?.toString() ?? 'Unknown Artist', style: const TextStyle(color:muted,fontSize:15)),
            const SizedBox(height:18),
            Slider(value: _position.inMilliseconds.clamp(0, _duration.inMilliseconds > 0 ? _duration.inMilliseconds : 1).toDouble(), max: (_duration.inMilliseconds > 0 ? _duration.inMilliseconds : 1).toDouble(), activeColor: blue, inactiveColor: Colors.white12, onChanged: (v) => _player.seek(Duration(milliseconds: v.round()))),
            Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(_fmt(_position),style:const TextStyle(color:muted,fontSize:11)),Text(_fmt(_duration),style:const TextStyle(color:muted,fontSize:11))]),
            const SizedBox(height: 10),
            Row(mainAxisAlignment:MainAxisAlignment.center,children:[
              IconButton(onPressed:_replay,icon:const Icon(Icons.replay_rounded,color:text,size:28)), const SizedBox(width:18),
              Container(decoration:const BoxDecoration(shape:BoxShape.circle,gradient:LinearGradient(colors:[blue,cyan])),child:IconButton(onPressed:_toggle,icon:Icon(_playing?Icons.pause_rounded:Icons.play_arrow_rounded,color:Colors.white,size:38))), const SizedBox(width:18),
              IconButton(onPressed:()=>_player.stop(),icon:const Icon(Icons.stop_rounded,color:text,size:28)),
            ]),
          ])),
          const SizedBox(height: 14),
          SizedBox(width:double.infinity,child:ElevatedButton.icon(onPressed:_openPanel,icon:const Icon(Icons.picture_in_picture_alt_rounded),label:const Text('BUKA PANEL MUSIK'))),
        ],
      ]),
    );
  }
}
