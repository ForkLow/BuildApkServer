// chat_main_page.dart
// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'dart:io';
import 'config.dart'; // apiBaseUrl

// ── Design tokens ───────────────────
class _C {
  static const bg0         = Color(0xFF050507);
  static const bg1         = Color(0xFF0C0C10);
  static const bg2         = Color(0xFF12121A);
  static const bg3         = Color(0xFF1A1A24);
  static const accent      = Color(0xFF7C6FFF);
  static const accentDim   = Color(0xFF4A41C4);
  static const accentGlow  = Color(0x337C6FFF);
  static const accentSoft  = Color(0x1A7C6FFF);
  static const cyan        = Color(0xFF00D4FF);
  static const live        = Color(0xFF10B981);
  static const danger      = Color(0xFFFF4757);
  static const textPrimary = Color(0xFFF0EEFF);
  static const textSec     = Color(0xFF8A8AA0);
  static const textMuted   = Color(0xFF4A4A60);
  static const border      = Color(0xFF2E2E46);
  static const font        = 'Rajdhani';
}

const List<String> kQuickEmojis = ['👍', '❤️', '😂', '😮', '🗿', '🥰', '👎', '😢', '🙏'];

// ── Model ────────────────────────────────────────────────────
class ChatMessage {
  final int id;
  final String from;
  final String to;
  final String room;
  final String role;
  String message;
  final String type;
  final String? mimeType;
  final String? mediaUrl;
  final DateTime time;
  bool edited;
  Map<String, List<String>> reactions;

  ChatMessage({
    required this.id,
    required this.from,
    this.to = '',
    this.room = '',
    required this.role,
    required this.message,
    required this.type,
    this.mimeType,
    this.mediaUrl,
    required this.time,
    this.edited = false,
    Map<String, List<String>>? reactions,
  }) : reactions = reactions ?? {};

  factory ChatMessage.fromGroupJson(Map<String, dynamic> j) => ChatMessage(
    id: j['id'] ?? 0,
    from: j['username'] ?? '',
    room: j['room'] ?? 'global',
    role: j['role'] ?? 'member',
    message: j['message'] ?? '',
    type: j['type'] ?? 'text',
    mimeType: j['mimeType'],
    mediaUrl: j['mediaUrl'],
    time: (DateTime.tryParse(j['time'] ?? '') ?? DateTime.now()).toLocal(),
    edited: j['edited'] == true,
    reactions: _parseReactions(j['reactions']),
  );

  factory ChatMessage.fromPrivateJson(Map<String, dynamic> j) => ChatMessage(
    id: j['id'] ?? 0,
    from: j['from'] ?? '',
    to: j['to'] ?? '',
    role: '',
    message: j['message'] ?? '',
    type: j['type'] ?? 'text',
    mimeType: j['mimeType'],
    mediaUrl: j['mediaUrl'],
    time: (DateTime.tryParse(j['time'] ?? '') ?? DateTime.now()).toLocal(),
    edited: j['edited'] == true,
    reactions: _parseReactions(j['reactions']),
  );

  static Map<String, List<String>> _parseReactions(dynamic raw) {
    if (raw == null) return {};
    final map = <String, List<String>>{};
    (raw as Map<String, dynamic>).forEach((k, v) {
      map[k] = List<String>.from(v ?? []);
    });
    return map;
  }
}

class StatusItem {
  final int id;
  final String username;
  final String role;
  final String type;
  final String caption;
  final String? mediaUrl;
  final List<String> viewers;
  final DateTime time;

  StatusItem({
    required this.id,
    required this.username,
    required this.role,
    required this.type,
    required this.caption,
    this.mediaUrl,
    required this.viewers,
    required this.time,
  });

  factory StatusItem.fromJson(Map<String, dynamic> j) => StatusItem(
    id: j['id'] ?? 0,
    username: j['username'] ?? '',
    role: j['role'] ?? 'member',
    type: j['type'] ?? 'text',
    caption: j['caption'] ?? '',
    mediaUrl: j['mediaUrl'],
    viewers: List<String>.from(j['viewers'] ?? []),
    time: (DateTime.tryParse(j['time'] ?? '') ?? DateTime.now()).toLocal(),
  );
}

// ════════════════════════════════════════════════════════════
//  ENTRY POINT
// ════════════════════════════════════════════════════════════
class ChatMainPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;
  final int initialTabIndex;

  const ChatMainPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
    this.initialTabIndex = 0,
  });

  @override
  State<ChatMainPage> createState() => _ChatMainPageState();
}

class _ChatMainPageState extends State<ChatMainPage> with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    final safeInitialTab = widget.initialTabIndex < 0 ? 0 : (widget.initialTabIndex > 2 ? 2 : widget.initialTabIndex);
    _tab = TabController(length: 3, vsync: this, initialIndex: safeInitialTab);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg0,
      appBar: AppBar(
        backgroundColor: _C.bg1,
        elevation: 0,
        iconTheme: const IconThemeData(color: _C.textPrimary),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('CHAT', style: TextStyle(color: _C.textPrimary, fontFamily: _C.font, fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 2)),
            Text(widget.username, style: const TextStyle(color: _C.cyan, fontFamily: _C.font, fontSize: 11, letterSpacing: 1)),
          ],
        ),
        bottom: TabBar(
          controller: _tab,
          labelColor: _C.accent,
          unselectedLabelColor: _C.textMuted,
          indicatorColor: _C.accent,
          indicatorWeight: 2.5,
          labelStyle: const TextStyle(fontFamily: _C.font, fontWeight: FontWeight.w700, fontSize: 13, letterSpacing: 1),
          tabs: const [
            Tab(text: 'GROUP', icon: Icon(Icons.group_rounded, size: 18)),
            Tab(text: 'PRIVATE', icon: Icon(Icons.chat_bubble_rounded, size: 18)),
            Tab(text: 'STATUS', icon: Icon(Icons.circle_rounded, size: 18)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          GroupChatTab(username: widget.username, sessionKey: widget.sessionKey, role: widget.role),
          PrivateTab(username: widget.username, sessionKey: widget.sessionKey, role: widget.role),
          StatusTab(username: widget.username, sessionKey: widget.sessionKey, role: widget.role),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
//  API HELPERS — react / edit / block
// ════════════════════════════════════════════════════════════
class _ChatApi {
  static Future<bool> react({
    required bool isGroup,
    required String sessionKey,
    required int messageId,
    required String emoji,
  }) async {
    try {
      final endpoint = isGroup ? 'groupchat/reactMessage' : 'private/reactMessage';
      final resp = await http.post(
        Uri.parse('$apiBaseUrl/$endpoint'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': sessionKey, 'messageId': messageId, 'emoji': emoji}),
      );
      return jsonDecode(resp.body)['valid'] == true;
    } catch (_) { return false; }
  }

  static Future<bool> edit({
    required bool isGroup,
    required String sessionKey,
    required int messageId,
    required String newMessage,
  }) async {
    try {
      final endpoint = isGroup ? 'groupchat/editMessage' : 'private/editMessage';
      final resp = await http.post(
        Uri.parse('$apiBaseUrl/$endpoint'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': sessionKey, 'messageId': messageId, 'message': newMessage}),
      );
      return jsonDecode(resp.body)['valid'] == true;
    } catch (_) { return false; }
  }

  static Future<bool> blockUser({required String sessionKey, required String target}) async {
    try {
      final resp = await http.post(
        Uri.parse('$apiBaseUrl/private/blockUser'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': sessionKey, 'target': target}),
      );
      return jsonDecode(resp.body)['valid'] == true;
    } catch (_) { return false; }
  }

  static Future<bool> unblockUser({required String sessionKey, required String target}) async {
    try {
      final resp = await http.post(
        Uri.parse('$apiBaseUrl/private/unblockUser'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': sessionKey, 'target': target}),
      );
      return jsonDecode(resp.body)['valid'] == true;
    } catch (_) { return false; }
  }

  static Future<List<String>> getBlocked(String sessionKey) async {
    try {
      final uri = Uri.parse('$apiBaseUrl/private/getBlocked').replace(queryParameters: {'key': sessionKey});
      final resp = await http.get(uri);
      final data = jsonDecode(resp.body);
      if (data['valid'] == true) return List<String>.from(data['data']);
    } catch (_) {}
    return [];
  }
}

Future<Map<String, dynamic>> _encodeChatMedia(XFile file, String type) async {
  final bytes = await File(file.path).readAsBytes();
  if (bytes.length > 25 * 1024 * 1024) throw Exception('Media maksimal 25MB');
  final lower = file.path.toLowerCase();
  String mime;
  if (type == 'video') {
    mime = lower.endsWith('.mov') ? 'video/quicktime' : 'video/mp4';
  } else {
    mime = lower.endsWith('.png') ? 'image/png' : lower.endsWith('.webp') ? 'image/webp' : 'image/jpeg';
  }
  return {'mediaBase64': base64Encode(bytes), 'mimeType': mime, 'type': type};
}

String _mediaUrl(String? value) {
  if (value == null || value.isEmpty) return '';
  if (value.startsWith('http://') || value.startsWith('https://')) return value;
  return '$apiBaseUrl${value.startsWith('/') ? '' : '/'}$value';
}

// ════════════════════════════════════════════════════════════
//  GROUP CHAT TAB
// ════════════════════════════════════════════════════════════
class GroupChatTab extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;
  const GroupChatTab({super.key, required this.username, required this.sessionKey, required this.role});

  @override
  State<GroupChatTab> createState() => _GroupChatTabState();
}

class _GroupChatTabState extends State<GroupChatTab> {
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _messages = <ChatMessage>[];
  Timer? _poll;
  int _lastId = 0;
  bool _loading = true;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _loadInitial();
    _poll = Timer.periodic(const Duration(seconds: 3), (_) => _pollNew());
  }

  @override
  void dispose() {
    _poll?.cancel();
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadInitial() async {
    setState(() => _loading = true);
    try {
      final uri = Uri.parse('$apiBaseUrl/groupchat/getMessages')
          .replace(queryParameters: {'key': widget.sessionKey, 'room': 'global', 'lastId': '0'});
      final resp = await http.get(uri);
      final data = jsonDecode(resp.body);
      if (data['valid'] == true) {
        final list = (data['data'] as List).map((e) => ChatMessage.fromGroupJson(e)).toList();
        setState(() {
          _messages..clear()..addAll(list);
          if (_messages.isNotEmpty) _lastId = _messages.last.id;
        });
        _scrollToBottom();
      }
    } catch (_) {}
    finally { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _pollNew() async {
    try {
      final uri = Uri.parse('$apiBaseUrl/groupchat/getMessages')
          .replace(queryParameters: {'key': widget.sessionKey, 'room': 'global', 'lastId': '$_lastId'});
      final resp = await http.get(uri);
      final data = jsonDecode(resp.body);
      if (data['valid'] == true) {
        final list = (data['data'] as List).map((e) => ChatMessage.fromGroupJson(e)).toList();
        if (list.isNotEmpty) {
          setState(() { _messages.addAll(list); _lastId = _messages.last.id; });
          _scrollToBottom();
        }
      }
    } catch (_) {}
  }

  Future<void> _sendText() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    _msgCtrl.clear();
    try {
      final resp = await http.post(
        Uri.parse('$apiBaseUrl/groupchat/sendMessage'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'room': 'global', 'message': text}),
      );
      final data = jsonDecode(resp.body);
      if (data['valid'] == true) await _pollNew();
    } catch (_) {}
    finally { if (mounted) setState(() => _sending = false); }
  }

  Future<void> _sendMedia(XFile file, String type) async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      final media = await _encodeChatMedia(file, type);
      final resp = await http.post(
        Uri.parse('$apiBaseUrl/groupchat/sendMessage'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'room': 'global',
          'message': '',
          'mediaBase64': media['mediaBase64'],
          'mimeType': media['mimeType'],
        }),
      ).timeout(const Duration(minutes: 2));
      final data = jsonDecode(resp.body);
      if (data['valid'] == true) await _pollNew();
      else if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['error'] ?? 'Gagal mengirim media')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _onReact(ChatMessage msg, String emoji) async {
    final ok = await _ChatApi.react(isGroup: true, sessionKey: widget.sessionKey, messageId: msg.id, emoji: emoji);
    if (ok) {
      setState(() {
        final list = msg.reactions.putIfAbsent(emoji, () => []);
        if (list.contains(widget.username)) {
          list.remove(widget.username);
          if (list.isEmpty) msg.reactions.remove(emoji);
        } else {
          list.add(widget.username);
        }
      });
    }
  }

  Future<void> _onEdit(ChatMessage msg) async {
    final newText = await _showEditDialog(context, msg.message);
    if (newText == null || newText.trim().isEmpty || newText.trim() == msg.message) return;
    final ok = await _ChatApi.edit(isGroup: true, sessionKey: widget.sessionKey, messageId: msg.id, newMessage: newText.trim());
    if (ok) setState(() { msg.message = newText.trim(); msg.edited = true; });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(_scrollCtrl.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator(color: _C.accent))
              : _messages.isEmpty
                  ? const Center(child: Text('Belum ada pesan', style: TextStyle(color: _C.textMuted, fontFamily: _C.font)))
                  : ListView.builder(
                      controller: _scrollCtrl,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      itemCount: _messages.length,
                      itemBuilder: (_, i) => _ChatBubble(
                        msg: _messages[i],
                        isMe: _messages[i].from == widget.username,
                        isGroup: true,
                        currentUsername: widget.username,
                        onReact: (emoji) => _onReact(_messages[i], emoji),
                        onEdit: _messages[i].from == widget.username ? () => _onEdit(_messages[i]) : null,
                      ),
                    ),
        ),
        _InputBar(
          controller: _msgCtrl,
          sending: _sending,
          onSendText: _sendText,
          onSendMedia: _sendMedia,
        ),
      ],
    );
  }
}

// ════════════════════════════════════════════════════════════
//  PRIVATE TAB — daftar konversasi
// ════════════════════════════════════════════════════════════
class PrivateTab extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;
  const PrivateTab({super.key, required this.username, required this.sessionKey, required this.role});

  @override
  State<PrivateTab> createState() => _PrivateTabState();
}

class _PrivateTabState extends State<PrivateTab> {
  List<Map<String, dynamic>> _convs = [];
  List<Map<String, dynamic>> _users = [];
  List<String> _blocked = [];
  bool _loading = true;
  Timer? _poll;

  @override
  void initState() {
    super.initState();
    _load();
    _poll = Timer.periodic(const Duration(seconds: 5), (_) => _load());
  }

  @override
  void dispose() { _poll?.cancel(); super.dispose(); }

  Future<void> _load() async {
    try {
      final uriConv = Uri.parse('$apiBaseUrl/private/getConversations')
          .replace(queryParameters: {'key': widget.sessionKey});
      final uriUsers = Uri.parse('$apiBaseUrl/private/getUsers')
          .replace(queryParameters: {'key': widget.sessionKey});

      final resConv  = await http.get(uriConv);
      final resUsers = await http.get(uriUsers);
      final blocked  = await _ChatApi.getBlocked(widget.sessionKey);

      final dConv  = jsonDecode(resConv.body);
      final dUsers = jsonDecode(resUsers.body);

      if (mounted) {
        setState(() {
          if (dConv['valid'] == true)  _convs = List<Map<String, dynamic>>.from(dConv['data']);
          if (dUsers['valid'] == true) _users = List<Map<String, dynamic>>.from(dUsers['data']);
          _blocked = blocked;
          _loading = false;
        });
      }
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  void _openChat(String peer) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => PrivateChatPage(
        username: widget.username,
        sessionKey: widget.sessionKey,
        peerUsername: peer,
      ),
    )).then((_) => _load());
  }

  Future<void> _toggleBlock(String peer) async {
    final isBlocked = _blocked.contains(peer);
    final ok = isBlocked
        ? await _ChatApi.unblockUser(sessionKey: widget.sessionKey, target: peer)
        : await _ChatApi.blockUser(sessionKey: widget.sessionKey, target: peer);
    if (ok) {
      setState(() {
        if (isBlocked) { _blocked.remove(peer); } else { _blocked.add(peer); }
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(isBlocked ? '$peer di-unblock' : '$peer diblokir', style: const TextStyle(fontFamily: _C.font)),
          backgroundColor: _C.bg3,
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final convPeers = _convs.map((c) => c['peer'] as String).toSet();
    final newUsers  = _users.where((u) => !convPeers.contains(u['username'])).toList();

    return _loading
        ? const Center(child: CircularProgressIndicator(color: _C.accent))
        : ListView(
            padding: const EdgeInsets.all(12),
            children: [
              if (_convs.isNotEmpty) ...[
                _SectionLabel('RECENT'),
                ..._convs.map((c) {
                  final peer = c['peer'] as String;
                  final last = c['lastMessage'] as Map<String, dynamic>?;
                  final preview = last == null ? 'Mulai chat' : (last['message'] as String? ?? '');
                  return _ConvTile(
                    username: peer,
                    preview: preview,
                    time: last != null ? DateTime.tryParse(last['time'] ?? '')?.toLocal() : null,
                    isBlocked: _blocked.contains(peer),
                    onTap: () => _openChat(peer),
                    onToggleBlock: () => _toggleBlock(peer),
                  );
                }),
              ],
              if (newUsers.isNotEmpty) ...[
                _SectionLabel('SEMUA USER'),
                ...newUsers.map((u) {
                  final peer = u['username'] as String;
                  return _ConvTile(
                    username: peer,
                    preview: 'Mulai percakapan',
                    isBlocked: _blocked.contains(peer),
                    onTap: () => _openChat(peer),
                    onToggleBlock: () => _toggleBlock(peer),
                  );
                }),
              ],
              if (_convs.isEmpty && newUsers.isEmpty)
                const Center(child: Padding(
                  padding: EdgeInsets.only(top: 60),
                  child: Text('Tidak ada user lain', style: TextStyle(color: _C.textMuted, fontFamily: _C.font)),
                )),
            ],
          );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel(this.label);

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 10),
    child: Row(children: [
      Container(width: 3, height: 14, decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [_C.accent, _C.cyan], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        borderRadius: BorderRadius.circular(4),
      )),
      const SizedBox(width: 8),
      Text(label, style: const TextStyle(color: _C.textSec, fontFamily: _C.font, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.5)),
    ]),
  );
}

class _ConvTile extends StatelessWidget {
  final String username;
  final String preview;
  final DateTime? time;
  final bool isBlocked;
  final VoidCallback onTap;
  final VoidCallback onToggleBlock;
  const _ConvTile({
    required this.username,
    required this.preview,
    this.time,
    required this.isBlocked,
    required this.onTap,
    required this.onToggleBlock,
  });

  @override
  Widget build(BuildContext context) {
    final initials = username.isNotEmpty ? username[0].toUpperCase() : '?';
    final timeStr = time != null
        ? '${time!.hour.toString().padLeft(2,'0')}:${time!.minute.toString().padLeft(2,'0')}'
        : '';
    return GestureDetector(
      onTap: onTap,
      onLongPress: () => _showBlockMenu(context),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: _C.bg2,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: isBlocked ? _C.danger.withOpacity(0.5) : _C.border),
        ),
        child: Row(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [_C.accentDim, _C.accent]),
            ),
            child: Center(child: Text(initials, style: const TextStyle(color: Colors.white, fontFamily: _C.font, fontWeight: FontWeight.w800, fontSize: 18))),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(username, style: const TextStyle(color: _C.textPrimary, fontFamily: _C.font, fontWeight: FontWeight.w700, fontSize: 14)),
              if (isBlocked) ...[
                const SizedBox(width: 6),
                const Icon(Icons.block_rounded, color: _C.danger, size: 14),
              ],
            ]),
            const SizedBox(height: 2),
            Text(preview, style: const TextStyle(color: _C.textMuted, fontFamily: _C.font, fontSize: 12), maxLines: 1, overflow: TextOverflow.ellipsis),
          ])),
          if (timeStr.isNotEmpty)
            Text(timeStr, style: const TextStyle(color: _C.textMuted, fontFamily: _C.font, fontSize: 10)),
          IconButton(
            icon: const Icon(Icons.more_vert_rounded, color: _C.textSec, size: 18),
            onPressed: () => _showBlockMenu(context),
          ),
        ]),
      ),
    );
  }

  void _showBlockMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _C.bg2,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: Icon(isBlocked ? Icons.lock_open_rounded : Icons.block_rounded, color: _C.danger),
            title: Text(isBlocked ? 'Unblock $username' : 'Blokir $username',
                style: const TextStyle(color: _C.textPrimary, fontFamily: _C.font)),
            onTap: () { Navigator.pop(context); onToggleBlock(); },
          ),
        ]),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
//  PRIVATE CHAT PAGE
// ════════════════════════════════════════════════════════════
class PrivateChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String peerUsername;
  const PrivateChatPage({super.key, required this.username, required this.sessionKey, required this.peerUsername});

  @override
  State<PrivateChatPage> createState() => _PrivateChatPageState();
}

class _PrivateChatPageState extends State<PrivateChatPage> {
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _messages = <ChatMessage>[];
  Timer? _poll;
  int _lastId = 0;
  bool _loading = true;
  bool _sending = false;
  bool _isBlocked = false;

  @override
  void initState() {
    super.initState();
    _loadInitial();
    _checkBlocked();
    _poll = Timer.periodic(const Duration(seconds: 3), (_) => _pollNew());
  }

  @override
  void dispose() {
    _poll?.cancel();
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _checkBlocked() async {
    final blocked = await _ChatApi.getBlocked(widget.sessionKey);
    if (mounted) setState(() => _isBlocked = blocked.contains(widget.peerUsername));
  }

  Future<void> _loadInitial() async {
    setState(() => _loading = true);
    try {
      final uri = Uri.parse('$apiBaseUrl/private/getMessages').replace(
        queryParameters: {'key': widget.sessionKey, 'withUser': widget.peerUsername, 'lastId': '0'},
      );
      final resp = await http.get(uri);
      final data = jsonDecode(resp.body);
      if (data['valid'] == true) {
        final list = (data['data'] as List).map((e) => ChatMessage.fromPrivateJson(e)).toList();
        setState(() {
          _messages..clear()..addAll(list);
          if (_messages.isNotEmpty) _lastId = _messages.last.id;
        });
        _scrollToBottom();
      }
    } catch (_) {}
    finally { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _pollNew() async {
    try {
      final uri = Uri.parse('$apiBaseUrl/private/getMessages').replace(
        queryParameters: {'key': widget.sessionKey, 'withUser': widget.peerUsername, 'lastId': '$_lastId'},
      );
      final resp = await http.get(uri);
      final data = jsonDecode(resp.body);
      if (data['valid'] == true) {
        final list = (data['data'] as List).map((e) => ChatMessage.fromPrivateJson(e)).toList();
        if (list.isNotEmpty) {
          setState(() { _messages.addAll(list); _lastId = _messages.last.id; });
          _scrollToBottom();
        }
      }
    } catch (_) {}
  }

  Future<void> _sendText() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _sending || _isBlocked) return;
    setState(() => _sending = true);
    _msgCtrl.clear();
    try {
      final resp = await http.post(
        Uri.parse('$apiBaseUrl/private/sendMessage'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'to': widget.peerUsername, 'message': text}),
      );
      if (jsonDecode(resp.body)['valid'] == true) await _pollNew();
    } catch (_) {}
    finally { if (mounted) setState(() => _sending = false); }
  }

  Future<void> _sendMedia(XFile file, String type) async {
    if (_sending || _isBlocked) return;
    setState(() => _sending = true);
    try {
      final media = await _encodeChatMedia(file, type);
      final resp = await http.post(
        Uri.parse('$apiBaseUrl/private/sendMessage'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'to': widget.peerUsername,
          'message': '',
          'mediaBase64': media['mediaBase64'],
          'mimeType': media['mimeType'],
        }),
      ).timeout(const Duration(minutes: 2));
      final data = jsonDecode(resp.body);
      if (data['valid'] == true) {
        await _pollNew();
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['error'] ?? 'Gagal mengirim media')));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _onReact(ChatMessage msg, String emoji) async {
    final ok = await _ChatApi.react(isGroup: false, sessionKey: widget.sessionKey, messageId: msg.id, emoji: emoji);
    if (ok) {
      setState(() {
        final list = msg.reactions.putIfAbsent(emoji, () => []);
        if (list.contains(widget.username)) {
          list.remove(widget.username);
          if (list.isEmpty) msg.reactions.remove(emoji);
        } else {
          list.add(widget.username);
        }
      });
    }
  }

  Future<void> _onEdit(ChatMessage msg) async {
    final newText = await _showEditDialog(context, msg.message);
    if (newText == null || newText.trim().isEmpty || newText.trim() == msg.message) return;
    final ok = await _ChatApi.edit(isGroup: false, sessionKey: widget.sessionKey, messageId: msg.id, newMessage: newText.trim());
    if (ok) setState(() { msg.message = newText.trim(); msg.edited = true; });
  }

  Future<void> _toggleBlock() async {
    final ok = _isBlocked
        ? await _ChatApi.unblockUser(sessionKey: widget.sessionKey, target: widget.peerUsername)
        : await _ChatApi.blockUser(sessionKey: widget.sessionKey, target: widget.peerUsername);
    if (ok) setState(() => _isBlocked = !_isBlocked);
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(_scrollCtrl.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg0,
      appBar: AppBar(
        backgroundColor: _C.bg1,
        elevation: 0,
        iconTheme: const IconThemeData(color: _C.textPrimary),
        title: Row(children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [_C.accentDim, _C.accent]),
            ),
            child: Center(child: Text(
              widget.peerUsername.isNotEmpty ? widget.peerUsername[0].toUpperCase() : '?',
              style: const TextStyle(color: Colors.white, fontFamily: _C.font, fontWeight: FontWeight.w800, fontSize: 16),
            )),
          ),
          const SizedBox(width: 10),
          Text(widget.peerUsername, style: const TextStyle(color: _C.textPrimary, fontFamily: _C.font, fontWeight: FontWeight.w700, fontSize: 16)),
        ]),
        actions: [
          IconButton(
            icon: Icon(_isBlocked ? Icons.lock_open_rounded : Icons.block_rounded, color: _isBlocked ? _C.live : _C.danger),
            tooltip: _isBlocked ? 'Unblock' : 'Blokir',
            onPressed: _toggleBlock,
          ),
        ],
      ),
      body: Column(children: [
        if (_isBlocked)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 8),
            color: _C.danger.withOpacity(0.15),
            child: const Text('Kamu memblokir user ini', textAlign: TextAlign.center,
                style: TextStyle(color: _C.danger, fontFamily: _C.font, fontSize: 12, fontWeight: FontWeight.w700)),
          ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator(color: _C.accent))
              : _messages.isEmpty
                  ? const Center(child: Text('Belum ada pesan', style: TextStyle(color: _C.textMuted, fontFamily: _C.font)))
                  : ListView.builder(
                      controller: _scrollCtrl,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      itemCount: _messages.length,
                      itemBuilder: (_, i) => _ChatBubble(
                        msg: _messages[i],
                        isMe: _messages[i].from == widget.username,
                        isGroup: false,
                        currentUsername: widget.username,
                        onReact: (emoji) => _onReact(_messages[i], emoji),
                        onEdit: _messages[i].from == widget.username ? () => _onEdit(_messages[i]) : null,
                      ),
                    ),
        ),
        if (_isBlocked)
          Container(
            padding: const EdgeInsets.all(14),
            color: _C.bg1,
            child: const Text('Unblock user untuk mengirim pesan', textAlign: TextAlign.center,
                style: TextStyle(color: _C.textMuted, fontFamily: _C.font, fontSize: 12)),
          )
        else
          _InputBar(
            controller: _msgCtrl,
            sending: _sending,
            onSendText: _sendText,
            onSendMedia: _sendMedia,
          ),
      ]),
    );
  }
}

// Dialog edit pesan (dipakai group & private)
Future<String?> _showEditDialog(BuildContext context, String currentText) {
  final ctrl = TextEditingController(text: currentText);
  return showDialog<String>(
    context: context,
    builder: (_) => AlertDialog(
      backgroundColor: _C.bg2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('Edit Pesan', style: TextStyle(color: _C.textPrimary, fontFamily: _C.font, fontWeight: FontWeight.w800)),
      content: TextField(
        controller: ctrl,
        autofocus: true,
        maxLines: 4,
        style: const TextStyle(color: _C.textPrimary, fontFamily: _C.font),
        decoration: InputDecoration(
          filled: true, fillColor: _C.bg3,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Batal', style: TextStyle(color: _C.textMuted, fontFamily: _C.font)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context, ctrl.text),
          child: const Text('Simpan', style: TextStyle(color: _C.accent, fontFamily: _C.font, fontWeight: FontWeight.w700)),
        ),
      ],
    ),
  );
}

// ════════════════════════════════════════════════════════════
//  STATUS TAB
// ════════════════════════════════════════════════════════════
class StatusTab extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String role;
  const StatusTab({super.key, required this.username, required this.sessionKey, required this.role});

  @override
  State<StatusTab> createState() => _StatusTabState();
}

class _StatusTabState extends State<StatusTab> {
  List<Map<String, dynamic>> _grouped = [];
  bool _loading = true;
  Timer? _poll;

  @override
  void initState() {
    super.initState();
    _load();
    _poll = Timer.periodic(const Duration(seconds: 10), (_) => _load());
  }

  @override
  void dispose() { _poll?.cancel(); super.dispose(); }

  Future<void> _load() async {
    try {
      final uri = Uri.parse('$apiBaseUrl/status/getAll').replace(queryParameters: {'key': widget.sessionKey});
      final resp = await http.get(uri);
      final data = jsonDecode(resp.body);
      if (data['valid'] == true && mounted) {
        setState(() {
          _grouped = List<Map<String, dynamic>>.from(data['data']);
          _loading = false;
        });
      }
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _postStatus() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: _C.bg2,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _PostStatusSheet(sessionKey: widget.sessionKey, onPosted: _load),
    );
  }

  @override
  Widget build(BuildContext context) {
    final myGroup    = _grouped.where((g) => g['username'] == widget.username).toList();
    final otherGroup = _grouped.where((g) => g['username'] != widget.username).toList();

    return Stack(
      children: [
        _loading
            ? const Center(child: CircularProgressIndicator(color: _C.accent))
            : ListView(
                padding: const EdgeInsets.all(12),
                children: [
                  _SectionLabel('STATUS SAYA'),
                  _StatusRow(
                    isMine: true,
                    items: myGroup.isNotEmpty
                        ? List<StatusItem>.from((myGroup[0]['items'] as List).map((e) => StatusItem.fromJson(e as Map<String, dynamic>)))
                        : [],
                    username: widget.username,
                    sessionKey: widget.sessionKey,
                    onTap: myGroup.isNotEmpty
                        ? (items) => _openStatusViewer(items, 0, myGroup[0]['username'])
                        : null,
                    onAdd: _postStatus,
                    onDelete: (id) async {
                      await http.delete(Uri.parse('$apiBaseUrl/status/delete')
                          .replace(queryParameters: {'key': widget.sessionKey, 'statusId': '$id'}));
                      _load();
                    },
                  ),
                  const SizedBox(height: 16),
                  if (otherGroup.isNotEmpty) ...[
                    _SectionLabel('STATUS TERBARU'),
                    ...otherGroup.map((g) {
                      final items = List<StatusItem>.from((g['items'] as List).map((e) => StatusItem.fromJson(e as Map<String, dynamic>)));
                      final allSeen = items.every((s) => s.viewers.contains(widget.username));
                      return _StatusAvatarTile(
                        username: g['username'] as String,
                        role: g['role'] as String? ?? '',
                        items: items,
                        allSeen: allSeen,
                        onTap: () => _openStatusViewer(items, 0, g['username'] as String),
                      );
                    }),
                  ],
                  if (_grouped.isEmpty && !_loading)
                    Center(child: Padding(
                      padding: const EdgeInsets.only(top: 60),
                      child: Column(children: [
                        Icon(Icons.circle_outlined, color: _C.textMuted, size: 48),
                        const SizedBox(height: 12),
                        const Text('Belum ada status', style: TextStyle(color: _C.textMuted, fontFamily: _C.font)),
                      ]),
                    )),
                ],
              ),
        Positioned(
          right: 16, bottom: 16,
          child: FloatingActionButton(
            backgroundColor: _C.accent,
            onPressed: _postStatus,
            child: const Icon(Icons.add_rounded, color: Colors.white),
          ),
        ),
      ],
    );
  }

  void _openStatusViewer(List<StatusItem> items, int startIndex, String ownerUsername) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => StatusViewerPage(
        items: items,
        startIndex: startIndex,
        viewerUsername: widget.username,
        sessionKey: widget.sessionKey,
        isOwner: ownerUsername == widget.username,
        onDelete: (id) async {
          await http.delete(Uri.parse('$apiBaseUrl/status/delete')
              .replace(queryParameters: {'key': widget.sessionKey, 'statusId': '$id'}));
          _load();
        },
      ),
    ));
  }
}

class _StatusRow extends StatelessWidget {
  final bool isMine;
  final List<StatusItem> items;
  final String username;
  final String sessionKey;
  final void Function(List<StatusItem>)? onTap;
  final VoidCallback onAdd;
  final void Function(int id) onDelete;

  const _StatusRow({
    required this.isMine,
    required this.items,
    required this.username,
    required this.sessionKey,
    this.onTap,
    required this.onAdd,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.bg2,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.border),
      ),
      child: Row(children: [
        GestureDetector(
          onTap: items.isNotEmpty && onTap != null ? () => onTap!(items) : onAdd,
          child: Stack(children: [
            Container(
              width: 54, height: 54,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(colors: [_C.accentDim, _C.accent]),
                border: Border.all(
                  color: items.isNotEmpty ? _C.accent : _C.border,
                  width: items.isNotEmpty ? 2.5 : 1.5,
                ),
              ),
              child: Center(child: Text(
                username.isNotEmpty ? username[0].toUpperCase() : '?',
                style: const TextStyle(color: Colors.white, fontFamily: _C.font, fontWeight: FontWeight.w900, fontSize: 22),
              )),
            ),
            Positioned(
              right: 0, bottom: 0,
              child: GestureDetector(
                onTap: onAdd,
                child: Container(
                  width: 20, height: 20,
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: _C.accent),
                  child: const Icon(Icons.add, color: Colors.white, size: 14),
                ),
              ),
            ),
          ]),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Status Saya', style: TextStyle(color: _C.textPrimary, fontFamily: _C.font, fontWeight: FontWeight.w700, fontSize: 14)),
          const SizedBox(height: 2),
          Text(
            items.isEmpty ? 'Tambah status baru' : '${items.length} status aktif (24 jam)',
            style: const TextStyle(color: _C.textMuted, fontFamily: _C.font, fontSize: 12),
          ),
        ])),
        if (items.isNotEmpty)
          IconButton(
            icon: const Icon(Icons.more_vert_rounded, color: _C.textSec),
            onPressed: () {
              showModalBottomSheet(
                context: context,
                backgroundColor: _C.bg2,
                shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
                builder: (_) => Column(mainAxisSize: MainAxisSize.min, children: [
                  ...items.map((s) => ListTile(
                    leading: const Icon(Icons.delete_outline_rounded, color: _C.danger),
                    title: Text('Hapus: ${s.type == 'text' ? s.caption : s.type}',
                        style: const TextStyle(color: _C.textPrimary, fontFamily: _C.font)),
                    onTap: () { Navigator.pop(context); onDelete(s.id); },
                  )),
                ]),
              );
            },
          ),
      ]),
    );
  }
}

class _StatusAvatarTile extends StatelessWidget {
  final String username;
  final String role;
  final List<StatusItem> items;
  final bool allSeen;
  final VoidCallback onTap;
  const _StatusAvatarTile({
    required this.username, required this.role, required this.items,
    required this.allSeen, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final last = items.isNotEmpty ? items.last : null;
    final timeStr = last != null
        ? '${last.time.hour.toString().padLeft(2,'0')}:${last.time.minute.toString().padLeft(2,'0')}'
        : '';
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: _C.bg2,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: allSeen ? _C.border : _C.accent.withOpacity(0.5)),
        ),
        child: Row(children: [
          Container(
            width: 50, height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [_C.accentDim, _C.accent]),
              border: Border.all(
                color: allSeen ? _C.textMuted : _C.accent,
                width: allSeen ? 1.5 : 2.5,
              ),
            ),
            child: Center(child: Text(
              username.isNotEmpty ? username[0].toUpperCase() : '?',
              style: const TextStyle(color: Colors.white, fontFamily: _C.font, fontWeight: FontWeight.w800, fontSize: 20),
            )),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(username, style: const TextStyle(color: _C.textPrimary, fontFamily: _C.font, fontWeight: FontWeight.w700, fontSize: 14)),
            const SizedBox(height: 2),
            Text(role.toUpperCase(), style: const TextStyle(color: _C.cyan, fontFamily: _C.font, fontSize: 11, letterSpacing: 1)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(timeStr, style: const TextStyle(color: _C.textMuted, fontFamily: _C.font, fontSize: 11)),
            const SizedBox(height: 4),
            Text('${items.length}', style: TextStyle(
              color: allSeen ? _C.textMuted : _C.accent,
              fontFamily: _C.font, fontSize: 11, fontWeight: FontWeight.w700,
            )),
          ]),
        ]),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
//  STATUS VIEWER PAGE
// ════════════════════════════════════════════════════════════
class StatusViewerPage extends StatefulWidget {
  final List<StatusItem> items;
  final int startIndex;
  final String viewerUsername;
  final String sessionKey;
  final bool isOwner;
  final void Function(int id) onDelete;

  const StatusViewerPage({
    super.key,
    required this.items,
    required this.startIndex,
    required this.viewerUsername,
    required this.sessionKey,
    required this.isOwner,
    required this.onDelete,
  });

  @override
  State<StatusViewerPage> createState() => _StatusViewerPageState();
}

class _StatusViewerPageState extends State<StatusViewerPage> {
  late int _current;
  late PageController _pageCtrl;
  Timer? _autoNext;

  @override
  void initState() {
    super.initState();
    _current = widget.startIndex;
    _pageCtrl = PageController(initialPage: _current);
    _markViewed();
    _startAutoNext();
  }

  @override
  void dispose() {
    _autoNext?.cancel();
    _pageCtrl.dispose();
    super.dispose();
  }

  void _startAutoNext() {
    _autoNext?.cancel();
    _autoNext = Timer(const Duration(seconds: 5), () {
      if (_current < widget.items.length - 1) {
        _pageCtrl.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      } else {
        Navigator.pop(context);
      }
    });
  }

  void _markViewed() async {
    final item = widget.items[_current];
    if (!item.viewers.contains(widget.viewerUsername) && !widget.isOwner) {
      await http.post(
        Uri.parse('$apiBaseUrl/status/view'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'statusId': item.id}),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        PageView.builder(
          controller: _pageCtrl,
          itemCount: widget.items.length,
          onPageChanged: (i) {
            setState(() => _current = i);
            _markViewed();
            _startAutoNext();
          },
          itemBuilder: (_, i) => _StatusItemView(item: widget.items[i]),
        ),
        Positioned(
          top: MediaQuery.of(context).padding.top + 8,
          left: 12, right: 12,
          child: Row(children: List.generate(widget.items.length, (i) => Expanded(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 2),
              height: 3,
              decoration: BoxDecoration(
                color: i <= _current ? _C.accent : _C.textMuted.withOpacity(0.4),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ))),
        ),
        Positioned(
          top: MediaQuery.of(context).padding.top + 20,
          right: 12,
          child: Row(children: [
            if (widget.isOwner)
              IconButton(
                icon: const Icon(Icons.delete_outline_rounded, color: _C.danger),
                onPressed: () {
                  widget.onDelete(widget.items[_current].id);
                  Navigator.pop(context);
                },
              ),
            IconButton(
              icon: const Icon(Icons.close_rounded, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
          ]),
        ),
        if (widget.isOwner)
          Positioned(
            bottom: 30, left: 16,
            child: Row(children: [
              const Icon(Icons.remove_red_eye_rounded, color: Colors.white54, size: 16),
              const SizedBox(width: 6),
              Text('${widget.items[_current].viewers.length} dilihat',
                style: const TextStyle(color: Colors.white70, fontFamily: _C.font, fontSize: 13)),
            ]),
          ),
      ]),
    );
  }
}

class _StatusItemView extends StatefulWidget {
  final StatusItem item;
  const _StatusItemView({required this.item});
  @override State<_StatusItemView> createState() => _StatusItemViewState();
}

class _StatusItemViewState extends State<_StatusItemView> {
  VideoPlayerController? _video;
  @override void initState() { super.initState(); if (widget.item.type == 'video' && widget.item.mediaUrl != null) { _video = VideoPlayerController.networkUrl(Uri.parse(_mediaUrl(widget.item.mediaUrl)))..initialize().then((_) { if (mounted) { setState(() {}); _video!.setLooping(true); _video!.play(); } }); } }
  @override void dispose() { _video?.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final media = widget.item.mediaUrl;
    return Stack(fit: StackFit.expand, children: [
      if (widget.item.type == 'image' && media != null)
        Image.network(_mediaUrl(media), fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image, color: _C.danger, size: 48)))
      else if (widget.item.type == 'video' && _video != null && _video!.value.isInitialized)
        Center(child: AspectRatio(aspectRatio: _video!.value.aspectRatio, child: VideoPlayer(_video!)))
      else
        Container(decoration: const BoxDecoration(gradient: LinearGradient(colors: [_C.bg0, _C.accentDim], begin: Alignment.topLeft, end: Alignment.bottomRight)), child: Center(child: Padding(padding: const EdgeInsets.all(32), child: Text(widget.item.caption, style: const TextStyle(color: Colors.white, fontFamily: _C.font, fontSize: 24, fontWeight: FontWeight.w700), textAlign: TextAlign.center)))),
      if (widget.item.caption.isNotEmpty && widget.item.type != 'text')
        Positioned(bottom: 60,left: 0,right: 0,child: Container(padding: const EdgeInsets.symmetric(horizontal:20,vertical:12),color:Colors.black54,child:Text(widget.item.caption,style:const TextStyle(color:Colors.white,fontFamily:_C.font,fontSize:16),textAlign:TextAlign.center))),
    ]);
  }
}

// ════════════════════════════════════════════════════════════
//  POST STATUS BOTTOM SHEET (teks saja, kotak besar penuh layar)
// ════════════════════════════════════════════════════════════
class _PostStatusSheet extends StatefulWidget {
  final String sessionKey;
  final VoidCallback onPosted;

  const _PostStatusSheet({
    required this.sessionKey,
    required this.onPosted,
  });

  @override
  State<_PostStatusSheet> createState() => _PostStatusSheetState();
}

class _PostStatusSheetState extends State<_PostStatusSheet> {
  final TextEditingController _captionCtrl = TextEditingController();
  final ImagePicker _picker = ImagePicker();

  XFile? _media;
  String? _mediaType;
  bool _posting = false;

  @override
  void dispose() {
    _captionCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final file = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
      );
      if (file != null && mounted) {
        setState(() {
          _media = file;
          _mediaType = 'image';
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memilih foto: $e')),
        );
      }
    }
  }

  Future<void> _pickVideo() async {
    try {
      final file = await _picker.pickVideo(
        source: ImageSource.gallery,
        maxDuration: const Duration(minutes: 2),
      );
      if (file != null && mounted) {
        setState(() {
          _media = file;
          _mediaType = 'video';
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memilih video: $e')),
        );
      }
    }
  }

  Future<void> _post() async {
    final caption = _captionCtrl.text.trim();
    if (caption.isEmpty && _media == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tulis caption atau pilih foto/video.')),
      );
      return;
    }
    if (_posting) return;

    setState(() => _posting = true);
    try {
      String? mediaBase64;
      String? mimeType;

      if (_media != null) {
        final bytes = await File(_media!.path).readAsBytes();
        if (bytes.length > 25 * 1024 * 1024) {
          throw Exception('Media maksimal 25MB.');
        }

        mediaBase64 = base64Encode(bytes);
        final lower = _media!.path.toLowerCase();
        if (_mediaType == 'video') {
          mimeType = lower.endsWith('.mov') ? 'video/quicktime' : 'video/mp4';
        } else {
          mimeType = lower.endsWith('.png') ? 'image/png' : 'image/jpeg';
        }
      }

      final response = await http
          .post(
            Uri.parse('$apiBaseUrl/status/post'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'caption': caption,
              'type': _mediaType ?? 'text',
              'mediaBase64': mediaBase64,
              'mimeType': mimeType,
            }),
          )
          .timeout(const Duration(minutes: 2));

      final data = jsonDecode(response.body);
      if (data is Map && data['valid'] == true) {
        widget.onPosted();
        if (mounted) Navigator.pop(context);
        return;
      }

      throw Exception(
        data is Map
            ? (data['error'] ?? data['message'] ?? 'Gagal membuat status')
            : 'Gagal membuat status',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => _posting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);

    return Padding(
      padding: EdgeInsets.only(bottom: mediaQuery.viewInsets.bottom),
      child: SizedBox(
        height: mediaQuery.size.height * 0.82,
        child: Column(
          children: [
            const SizedBox(height: 12),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: _C.border,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'BUAT STATUS',
              style: TextStyle(
                color: _C.textPrimary,
                fontFamily: _C.font,
                fontWeight: FontWeight.w900,
                fontSize: 16,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 12),
            if (_media != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  height: 110,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: _C.bg3,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _C.border),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _mediaType == 'video'
                            ? Icons.videocam_rounded
                            : Icons.image_rounded,
                        color: _C.accent,
                        size: 34,
                      ),
                      const SizedBox(width: 10),
                      Text(
                        _mediaType == 'video' ? 'Video dipilih' : 'Foto dipilih',
                        style: const TextStyle(
                          color: _C.textPrimary,
                          fontFamily: _C.font,
                          fontSize: 16,
                        ),
                      ),
                      IconButton(
                        onPressed: _posting
                            ? null
                            : () => setState(() {
                                  _media = null;
                                  _mediaType = null;
                                }),
                        icon: const Icon(Icons.close, color: _C.danger),
                      ),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _posting ? null : _pickImage,
                      icon: const Icon(Icons.photo_rounded),
                      label: const Text('FOTO'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _posting ? null : _pickVideo,
                      icon: const Icon(Icons.video_library_rounded),
                      label: const Text('VIDEO'),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: TextField(
                  controller: _captionCtrl,
                  maxLines: null,
                  expands: true,
                  textAlignVertical: TextAlignVertical.top,
                  style: const TextStyle(
                    color: _C.textPrimary,
                    fontFamily: _C.font,
                    fontSize: 18,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Tulis caption...',
                    hintStyle: const TextStyle(
                      color: _C.textMuted,
                      fontFamily: _C.font,
                    ),
                    filled: true,
                    fillColor: _C.bg3,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: _C.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: _C.border),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _posting ? null : _post,
                  child: _posting
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text('BAGIKAN STATUS'),
                ),
              ),
            ),
            SizedBox(height: 16 + mediaQuery.padding.bottom),
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
//  SHARED WIDGETS
// ════════════════════════════════════════════════════════════

// Chat bubble — teks + reaction + edit
class _ChatBubble extends StatelessWidget {
  final ChatMessage msg;
  final bool isMe;
  final bool isGroup;
  final String currentUsername;
  final void Function(String emoji) onReact;
  final VoidCallback? onEdit;

  const _ChatBubble({
    required this.msg,
    required this.isMe,
    required this.isGroup,
    required this.currentUsername,
    required this.onReact,
    this.onEdit,
  });

  void _showActions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _C.bg2,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: kQuickEmojis.map((e) => GestureDetector(
                  onTap: () { Navigator.pop(context); onReact(e); },
                  child: Text(e, style: const TextStyle(fontSize: 26)),
                )).toList(),
              ),
            ),
            if (onEdit != null) ...[
              const Divider(color: _C.border, height: 1),
              ListTile(
                leading: const Icon(Icons.edit_rounded, color: _C.accent),
                title: const Text('Edit Pesan', style: TextStyle(color: _C.textPrimary, fontFamily: _C.font)),
                onTap: () { Navigator.pop(context); onEdit!(); },
              ),
            ],
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => _showActions(context),
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
          child: Column(
            crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: isMe ? _C.accentDim : _C.bg3,
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(16),
                    topRight: const Radius.circular(16),
                    bottomLeft: Radius.circular(isMe ? 16 : 4),
                    bottomRight: Radius.circular(isMe ? 4 : 16),
                  ),
                  border: Border.all(color: isMe ? _C.accent.withOpacity(0.4) : _C.border),
                  boxShadow: isMe ? [BoxShadow(color: _C.accentGlow, blurRadius: 8)] : [],
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (isGroup && !isMe)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Text('${msg.from} • ${msg.role}',
                          style: const TextStyle(color: _C.cyan, fontFamily: _C.font, fontSize: 11, fontWeight: FontWeight.w700)),
                      ),
                    if (msg.mediaUrl != null && msg.mediaUrl!.isNotEmpty)
                      _ChatMediaPreview(url: _mediaUrl(msg.mediaUrl), type: msg.type),
                    if (msg.message.isNotEmpty) ...[
                      if (msg.mediaUrl != null && msg.mediaUrl!.isNotEmpty) const SizedBox(height: 6),
                      Text(msg.message,
                        style: TextStyle(color: isMe ? Colors.white : _C.textPrimary, fontFamily: _C.font, fontSize: 14)),
                    ],
                    const SizedBox(height: 4),
                    Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(_formatTime(msg.time),
                        style: TextStyle(color: isMe ? Colors.white38 : _C.textMuted, fontFamily: _C.font, fontSize: 9)),
                      if (msg.edited) ...[
                        const SizedBox(width: 4),
                        Text('(diedit)',
                          style: TextStyle(color: isMe ? Colors.white38 : _C.textMuted, fontFamily: _C.font, fontSize: 9, fontStyle: FontStyle.italic)),
                      ],
                    ]),
                  ]),
                ),
              ),
              if (msg.reactions.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Wrap(
                    spacing: 4,
                    children: msg.reactions.entries.map((e) {
                      final reactedByMe = e.value.contains(currentUsername);
                      return GestureDetector(
                        onTap: () => onReact(e.key),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: reactedByMe ? _C.accentSoft : _C.bg2,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: reactedByMe ? _C.accent : _C.border),
                          ),
                          child: Text('${e.key} ${e.value.length}',
                            style: const TextStyle(color: _C.textPrimary, fontFamily: _C.font, fontSize: 11)),
                        ),
                      );
                    }).toList(),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatTime(DateTime t) =>
      '${t.hour.toString().padLeft(2,'0')}:${t.minute.toString().padLeft(2,'0')}';
}

// Input bar — text field + tombol kirim
class _InputBar extends StatefulWidget {
  final TextEditingController controller;
  final bool sending;
  final VoidCallback onSendText;
  final Future<void> Function(XFile file, String type) onSendMedia;
  const _InputBar({required this.controller,required this.sending,required this.onSendText,required this.onSendMedia});
  @override State<_InputBar> createState()=>_InputBarState();
}

class _InputBarState extends State<_InputBar> {
  final ImagePicker _picker = ImagePicker();

  Future<void> _chooseMedia() async {
    if (widget.sending) return;

    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: _C.bg2,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_rounded, color: _C.accent),
              title: const Text(
                'Foto',
                style: TextStyle(color: _C.textPrimary, fontFamily: _C.font),
              ),
              onTap: () => Navigator.pop(context, 'image'),
            ),
            ListTile(
              leading: const Icon(Icons.videocam_rounded, color: _C.cyan),
              title: const Text(
                'Video',
                style: TextStyle(color: _C.textPrimary, fontFamily: _C.font),
              ),
              onTap: () => Navigator.pop(context, 'video'),
            ),
          ],
        ),
      ),
    );

    if (choice == 'image') {
      final file = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
      );
      if (file != null) await widget.onSendMedia(file, 'image');
    } else if (choice == 'video') {
      final file = await _picker.pickVideo(
        source: ImageSource.gallery,
        maxDuration: const Duration(minutes: 2),
      );
      if (file != null) await widget.onSendMedia(file, 'video');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 8, 10, 12),
      decoration: const BoxDecoration(
        color: _C.bg1,
        border: Border(top: BorderSide(color: _C.border)),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: widget.sending ? null : _chooseMedia,
            icon: const Icon(
              Icons.add_circle_outline_rounded,
              color: _C.accent,
            ),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: _C.bg3,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _C.border),
              ),
              child: TextField(
                controller: widget.controller,
                style: const TextStyle(
                  color: _C.textPrimary,
                  fontFamily: _C.font,
                  fontSize: 14,
                ),
                minLines: 1,
                maxLines: 5,
                decoration: const InputDecoration(
                  hintText: 'Tulis pesan...',
                  hintStyle: TextStyle(
                    color: _C.textMuted,
                    fontFamily: _C.font,
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                ),
                onSubmitted: (_) => widget.onSendText(),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: widget.sending ? null : widget.onSendText,
            child: Container(
              width: 42,
              height: 42,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [_C.accentDim, _C.accent],
                ),
              ),
              child: widget.sending
                  ? const Padding(
                      padding: EdgeInsets.all(10),
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2,
                      ),
                    )
                  : const Icon(
                      Icons.send_rounded,
                      color: Colors.white,
                      size: 20,
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ChatMediaPreview extends StatelessWidget {
  final String url; final String type;
  const _ChatMediaPreview({required this.url,required this.type});
  @override Widget build(BuildContext context){
    if(type=='image') return ClipRRect(borderRadius:BorderRadius.circular(12),child:Image.network(url,width:220,height:220,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.broken_image,color:_C.danger,size:40)));
    if(type=='video') return GestureDetector(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>_ChatVideoPage(url:url))),child:Container(width:220,height:130,decoration:BoxDecoration(color:Colors.black,borderRadius:BorderRadius.circular(12)),child:const Center(child:Icon(Icons.play_circle_fill_rounded,color:Colors.white,size:54))));
    return const Row(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.insert_drive_file_rounded,color:_C.accent),SizedBox(width:6),Text('Media',style:TextStyle(color:_C.textPrimary,fontFamily:_C.font))]);
  }
}

class _ChatVideoPage extends StatefulWidget { final String url; const _ChatVideoPage({required this.url}); @override State<_ChatVideoPage> createState()=>_ChatVideoPageState(); }
class _ChatVideoPageState extends State<_ChatVideoPage>{ VideoPlayerController? _v; @override void initState(){super.initState();_v=VideoPlayerController.networkUrl(Uri.parse(widget.url))..initialize().then((_){if(mounted)setState((){});_v!.play();});} @override void dispose(){_v?.dispose();super.dispose();} @override Widget build(BuildContext c){return Scaffold(backgroundColor:Colors.black,appBar:AppBar(backgroundColor:Colors.black),body:Center(child:_v!=null&&_v!.value.isInitialized?AspectRatio(aspectRatio:_v!.value.aspectRatio,child:VideoPlayer(_v!)):const CircularProgressIndicator()));}}

