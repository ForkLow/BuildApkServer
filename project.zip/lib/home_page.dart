// home_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'config.dart';

// ─── PALETTE (LIGHT THEME — sama dengan Dashboard) ─────────────
class _C {
  static const bg      = Color(0xFFEAF4FF);
  static const surface = Color(0xFFF3F8FF);
  static const card    = Color(0xFFF3F8FF);
  static const line    = Color(0xFF0B0B0B);

  static const red     = Color(0xFF2F6FED);
  static const redGlow = Color(0xFF2F6FED);
  static const redDeep = Color(0xFF1B4FC4);

  static const muted   = Color(0xFF7A8394);
  static const dim     = Color(0xFFA3ADBD);
  static const white   = Color(0xFF10131A);

  static const green   = Color(0xFF16A34A);
}

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final TextEditingController targetController = TextEditingController();
  late final AnimationController _pulseController;
  String selectedBugId = "";
  String _selectedBugMode = "number";
  bool isSending = false;
  String? responseMessage;

  String _selectedSenderType = "private";
  List<String> activeSenders = [];
  bool _isLoadingSenders = false;
  String? _senderError;

  late VideoPlayerController _videoController;
  ChewieController? _chewieController;
  bool isVideoInitialized = false;

  LinearGradient get primaryGradient => LinearGradient(
    colors: [_C.red, _C.redDeep],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  LinearGradient get secondaryGradient => LinearGradient(
    colors: [_C.redDeep, _C.redGlow],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    _initializeVideoPlayer();
    _fetchActiveSenders();
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4');

    _videoController.initialize().then((_) {
      if (mounted) {
        setState(() {
          _videoController.setVolume(0.5);
          _chewieController = ChewieController(
            videoPlayerController: _videoController,
            autoPlay: true,
            looping: true,
            showControls: false,
            autoInitialize: true,
          );
          isVideoInitialized = true;
        });
      }
    }).catchError((error) {
      debugPrint("Video error: $error");
      if (mounted) {
        setState(() {
          isVideoInitialized = false;
        });
      }
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    targetController.dispose();
    _chewieController?.dispose();
    _videoController.dispose();
    super.dispose();
  }

  Future<void> _fetchActiveSenders() async {
    setState(() {
      _isLoadingSenders = true;
      _senderError = null;
    });

    try {
      final res = await http.get(
        Uri.parse("$apiBaseUrl/mySender?key=${widget.sessionKey}"),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        if (data["valid"] == true) {
          final globalConnections = data["globalConnections"] as List<dynamic>? ?? [];
          setState(() {
            activeSenders = globalConnections
                .whereType<Map>()
                .map(
                  (item) => item["sessionName"]?.toString() ??
                           item["id"]?.toString() ??
                           "Unknown",
                )
                .toList();
          });
        } else {
          setState(() {
            _senderError = data["message"] ?? "Gagal memuat sender aktif";
            activeSenders = [];
          });
        }
      } else {
        setState(() {
          _senderError = "Server error: ${res.statusCode}";
          activeSenders = [];
        });
      }
    } catch (e) {
      setState(() {
        _senderError = "Connection failed: $e";
        activeSenders = [];
      });
    } finally {
      setState(() {
        _isLoadingSenders = false;
      });
    }
  }

  String? _formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  // ─── FIX: regex WA group link standar ───
  bool isValidGroupLink(String input) {
    final trimmed = input.trim();
    final regex = RegExp(
      r'(?:https?:\/\/)?chat\.whatsapp\.com\/(?:invite\/)?([a-zA-Z0-9]{20,24})',
    );
    return regex.hasMatch(trimmed);
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;
    final mode = _selectedBugMode;

    if (mode == "number") {
      final target = _formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showMessageDialog(
          "Invalid Number",
          "Use international format (e.g., +62, +1, +44)",
        );
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showMessageDialog(
          "Invalid Link",
          "Enter a valid WhatsApp group link\n(e.g., https://chat.whatsapp.com/XXXXXXXXXX)",
        );
        return;
      }
    }

    if (_selectedSenderType == "global" && activeSenders.isEmpty) {
      await _fetchActiveSenders();
      if (activeSenders.isEmpty) {
        _showMessageDialog(
          "No Global Sender",
          "No active global sender available",
        );
        return;
      }
    }

    setState(() {
      isSending = true;
      responseMessage = null;
    });

    try {
      final uri = Uri.parse("$apiBaseUrl/sendBug").replace(queryParameters: {
        'key': key,
        'target': rawInput,
        'bug': selectedBugId,
        'senderType': _selectedSenderType,
        'mode': mode,
      });

      final res = await http.get(uri).timeout(const Duration(seconds: 30));

      final data = jsonDecode(res.body);

      if (!mounted) return;

      if (data["cooldown"] == true) {
        final wait = data["wait"];
        setState(() => responseMessage = wait == null
            ? "⏳ Cooldown: Please wait a moment"
            : "⏳ Cooldown: Wait $wait seconds");
      } else if (data["valid"] == false) {
        setState(() => responseMessage = "❌ Invalid Session: Please login again");
      } else if (data["sended"] == false) {
        setState(() => responseMessage = "⚠️ ${data["message"] ?? "Failed to send bug"}");
      } else {
        final senderLabel = _selectedSenderType == "global" ? "global sender" : "private sender";
        final targetLabel = mode == "group" ? "group" : "number";
        setState(() => responseMessage = "✅ Attack sent to $targetLabel with $senderLabel!");
        targetController.clear();
      }
    } catch (e) {
      if (mounted) {
        setState(() => responseMessage = "❌ Error: Connection failed");
      }
    } finally {
      if (mounted) {
        setState(() => isSending = false);
      }
      if (_selectedSenderType == "global") {
        _fetchActiveSenders();
      }
    }
  }

  void _showMessageDialog(String title, String msg) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: TweenAnimationBuilder(
          duration: const Duration(milliseconds: 300),
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, double scale, child) {
            return Transform.scale(scale: scale, child: child);
          },
          child: Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _C.card,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _C.line, width: 2),
              boxShadow: const [
                BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 6)),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: primaryGradient,
                    shape: BoxShape.circle,
                    border: Border.all(color: _C.line, width: 2),
                  ),
                  child: const Icon(Icons.warning_rounded, color: Colors.white, size: 32),
                ),
                const SizedBox(height: 20),
                Text(
                  title,
                  style: const TextStyle(
                    color: _C.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  msg,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: _C.muted, fontSize: 14),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        gradient: primaryGradient,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _C.line, width: 2),
                        boxShadow: const [
                          BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
                        ],
                      ),
                      child: const Center(
                        child: Text(
                          "OK",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_C.bg, Color(0xFFCFE7FF)],
          ),
        ),
        child: CustomPaint(
          painter: _GridPainter(),
          child: SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // Profile Card
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: _C.card,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: _C.line, width: 2),
                      boxShadow: const [
                        BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 6)),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 70,
                          height: 70,
                          decoration: BoxDecoration(
                            gradient: primaryGradient,
                            shape: BoxShape.circle,
                            border: Border.all(color: _C.line, width: 2),
                            boxShadow: const [
                              BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
                            ],
                          ),
                          child: ClipOval(
                            child: Image.asset(
                              'assets/images/login.png',
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Icon(
                                Icons.person,
                                color: Colors.white,
                                size: 40,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 20),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.username,
                                style: const TextStyle(
                                  color: _C.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: _C.red.withOpacity(0.10),
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(color: _C.red, width: 1.2),
                                    ),
                                    child: Text(
                                      widget.role.toUpperCase(),
                                      style: const TextStyle(color: _C.red, fontSize: 11, fontWeight: FontWeight.w600),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: _C.red.withOpacity(0.06),
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(color: _C.red.withOpacity(0.3), width: 1),
                                    ),
                                    child: Text(
                                      "Exp: ${widget.expiredDate}",
                                      style: const TextStyle(color: _C.muted, fontSize: 11),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Video Player
                  if (isVideoInitialized && _chewieController != null)
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _C.line, width: 2),
                        boxShadow: const [
                          BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 6)),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: AspectRatio(
                          aspectRatio: _videoController.value.aspectRatio,
                          child: Chewie(controller: _chewieController!),
                        ),
                      ),
                    ),

                  const SizedBox(height: 20),

                  // Mode Selector
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: _C.card,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _C.line, width: 2),
                    ),
                    child: Row(
                      children: [
                        _buildModeTab(
                          label: "BUG NOMOR",
                          icon: Icons.phone_android_rounded,
                          mode: "number",
                        ),
                        _buildModeTab(
                          label: "BUG GROUP",
                          icon: Icons.group_rounded,
                          mode: "group",
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Target Input
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _C.line, width: 2),
                    ),
                    child: TextField(
                      controller: targetController,
                      style: const TextStyle(color: _C.white, fontSize: 14),
                      cursorColor: _C.red,
                      keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
                      decoration: InputDecoration(
                        hintText: _selectedBugMode == "number"
                            ? "+62895329031575"
                            : "https://chat.whatsapp.com/...",
                        hintStyle: TextStyle(color: _C.muted.withOpacity(0.5), fontSize: 13),
                        border: InputBorder.none,
                        prefixIcon: Icon(
                          _selectedBugMode == "number"
                              ? Icons.phone_android_rounded
                              : Icons.link_rounded,
                          color: _C.red,
                          size: 20,
                        ),
                        contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Bug Selection Title
                  Row(
                    children: [
                      Container(
                        width: 4,
                        height: 20,
                        decoration: BoxDecoration(
                          gradient: primaryGradient,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        "PILIH BUG",
                        style: TextStyle(
                          color: _C.muted,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  // Horizontal Scroll Bug List
                  SizedBox(
                    height: 130,
                    child: Scrollbar(
                      thumbVisibility: false,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        physics: const BouncingScrollPhysics(),
                        itemCount: widget.listBug.length,
                        itemBuilder: (context, index) {
                          final bug = widget.listBug[index];
                          final isSelected = selectedBugId == bug['bug_id'];
                          return GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedBugId = bug['bug_id'];
                              });
                            },
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 220),
                              width: 140,
                              margin: const EdgeInsets.only(right: 12),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: isSelected ? _C.red.withOpacity(0.10) : _C.card,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: _C.line,
                                  width: isSelected ? 2.5 : 2,
                                ),
                                boxShadow: isSelected
                                    ? const [
                                        BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
                                      ]
                                    : const [
                                        BoxShadow(color: Colors.black12, blurRadius: 0, offset: Offset(2, 3)),
                                      ],
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      gradient: isSelected ? secondaryGradient : null,
                                      color: isSelected ? null : _C.red.withOpacity(0.08),
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: isSelected ? _C.line : _C.red.withOpacity(0.4),
                                        width: isSelected ? 2 : 1.2,
                                      ),
                                    ),
                                    child: Icon(
                                      Icons.bug_report,
                                      color: isSelected ? Colors.white : _C.red,
                                      size: 24,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    bug['bug_name'] ?? '',
                                    style: const TextStyle(
                                      color: _C.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                    textAlign: TextAlign.center,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: isSelected
                                          ? _C.red.withOpacity(0.15)
                                          : _C.red.withOpacity(0.08),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: isSelected ? _C.red : _C.red.withOpacity(0.4),
                                        width: 1,
                                      ),
                                    ),
                                    child: Text(
                                      "ID: ${bug['bug_id']}",
                                      style: const TextStyle(
                                        color: _C.red,
                                        fontSize: 9,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                  if (isSelected)
                                    const Padding(
                                      padding: EdgeInsets.only(top: 4),
                                      child: Icon(Icons.check_circle, color: _C.green, size: 14),
                                    ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Sender Type Selector
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _C.card,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _C.line, width: 2),
                      boxShadow: const [
                        BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 4,
                              height: 20,
                              decoration: BoxDecoration(
                                gradient: primaryGradient,
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              "PILIH SENDER",
                              style: TextStyle(
                                color: _C.muted,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(
                              child: GestureDetector(
                                onTap: () => setState(() => _selectedSenderType = "private"),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  decoration: BoxDecoration(
                                    color: _selectedSenderType == "private"
                                        ? _C.red.withOpacity(0.10)
                                        : Colors.transparent,
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(
                                      color: _selectedSenderType == "private"
                                          ? _C.line
                                          : _C.line.withOpacity(0.3),
                                      width: _selectedSenderType == "private" ? 2.5 : 2,
                                    ),
                                  ),
                                  child: Column(
                                    children: [
                                      Icon(
                                        Icons.person_rounded,
                                        color: _selectedSenderType == "private" ? _C.red : _C.muted,
                                        size: 28,
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        "PRIVATE",
                                        style: TextStyle(
                                          color: _selectedSenderType == "private" ? _C.red : _C.muted,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 12,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      const Text(
                                        "Sender pribadi",
                                        style: TextStyle(color: _C.muted, fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: GestureDetector(
                                onTap: () {
                                  setState(() => _selectedSenderType = "global");
                                  if (activeSenders.isEmpty) {
                                    _fetchActiveSenders();
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  decoration: BoxDecoration(
                                    color: _selectedSenderType == "global"
                                        ? _C.red.withOpacity(0.10)
                                        : Colors.transparent,
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(
                                      color: _selectedSenderType == "global"
                                          ? _C.line
                                          : _C.line.withOpacity(0.3),
                                      width: _selectedSenderType == "global" ? 2.5 : 2,
                                    ),
                                  ),
                                  child: Column(
                                    children: [
                                      Icon(
                                        Icons.public_rounded,
                                        color: _selectedSenderType == "global" ? _C.red : _C.muted,
                                        size: 28,
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        "GLOBAL",
                                        style: TextStyle(
                                          color: _selectedSenderType == "global" ? _C.red : _C.muted,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 12,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      const Text(
                                        "Sender global",
                                        style: TextStyle(color: _C.muted, fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        if (_selectedSenderType == "global") ...[
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: _C.line, width: 1.5),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    const Text(
                                      "SENDER AKTIF",
                                      style: TextStyle(
                                        color: _C.muted,
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 1,
                                      ),
                                    ),
                                    const Spacer(),
                                    GestureDetector(
                                      onTap: _fetchActiveSenders,
                                      child: Container(
                                        padding: const EdgeInsets.all(6),
                                        decoration: BoxDecoration(
                                          color: _C.red.withOpacity(0.10),
                                          borderRadius: BorderRadius.circular(8),
                                          border: Border.all(color: _C.red.withOpacity(0.4)),
                                        ),
                                        child: const Icon(Icons.refresh_rounded, color: _C.red, size: 16),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                if (_isLoadingSenders)
                                  const Center(
                                    child: SizedBox(
                                      height: 20,
                                      width: 20,
                                      child: CircularProgressIndicator(strokeWidth: 2, color: _C.red),
                                    ),
                                  )
                                else if (_senderError != null)
                                  Text(
                                    _senderError!,
                                    style: const TextStyle(color: _C.red, fontSize: 12),
                                  )
                                else if (activeSenders.isEmpty)
                                  const Text(
                                    "Tidak ada global sender aktif",
                                    style: TextStyle(color: _C.muted, fontSize: 12),
                                  )
                                else
                                  ...activeSenders.map((sender) => Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 4),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 6,
                                              height: 6,
                                              decoration: const BoxDecoration(
                                                color: _C.green,
                                                shape: BoxShape.circle,
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              child: Text(
                                                sender,
                                                style: const TextStyle(color: _C.white, fontSize: 12),
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                          ],
                                        ),
                                      )).toList(),
                              ],
                            ),
                          ),
                        ] else ...[
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: _C.line, width: 1.5),
                            ),
                            child: const Row(
                              children: [
                                Icon(Icons.info_outline_rounded, color: _C.red, size: 16),
                                SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    "Menggunakan sender pribadi dari session Anda",
                                    style: TextStyle(color: _C.muted, fontSize: 12),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Send Button
                  AnimatedBuilder(
                    animation: _pulseController,
                    builder: (context, child) {
                      return Container(
                        width: double.infinity,
                        height: 56,
                        decoration: BoxDecoration(
                          gradient: primaryGradient,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _C.line, width: 2.5),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 0,
                              offset: Offset(4, 4 + _pulseController.value * 2),
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: isSending ? null : _sendBug,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                          ),
                          child: isSending
                              ? const SizedBox(
                                  width: 24,
                                  height: 24,
                                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
                                )
                              : const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 22),
                                    SizedBox(width: 10),
                                    Text(
                                      "SEND BUG ATTACK",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 15,
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      );
                    },
                  ),

                  // Response Message
                  if (responseMessage != null) ...[
                    const SizedBox(height: 20),
                    TweenAnimationBuilder(
                      duration: const Duration(milliseconds: 400),
                      tween: Tween<double>(begin: 0, end: 1),
                      builder: (context, double value, child) {
                        return Opacity(opacity: value, child: child);
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: responseMessage!.contains('✅')
                              ? _C.green.withOpacity(0.1)
                              : responseMessage!.contains('❌')
                                  ? _C.redDeep.withOpacity(0.15)
                                  : responseMessage!.contains('⚠️')
                                      ? _C.redGlow.withOpacity(0.1)
                                      : _C.redDeep.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: responseMessage!.contains('✅')
                                ? _C.green
                                : responseMessage!.contains('❌')
                                    ? _C.red
                                    : responseMessage!.contains('⚠️')
                                        ? _C.redGlow
                                        : _C.red,
                            width: 2,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              responseMessage!.contains('✅')
                                  ? Icons.check_circle
                                  : responseMessage!.contains('❌')
                                      ? Icons.error
                                      : Icons.warning,
                              color: responseMessage!.contains('✅')
                                  ? _C.green
                                  : responseMessage!.contains('❌')
                                      ? _C.red
                                      : _C.redGlow,
                              size: 22,
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                responseMessage!,
                                style: TextStyle(
                                  color: responseMessage!.contains('✅')
                                      ? _C.green
                                      : responseMessage!.contains('❌')
                                          ? _C.red
                                          : _C.redGlow,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],

                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildModeTab({
    required String label,
    required IconData icon,
    required String mode,
  }) {
    final isActive = _selectedBugMode == mode;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() {
          _selectedBugMode = mode;
          targetController.clear();
        }),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            gradient: isActive ? primaryGradient : null,
            color: isActive ? null : Colors.transparent,
            borderRadius: BorderRadius.circular(16),
            border: isActive ? Border.all(color: _C.line, width: 2) : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isActive ? Colors.white : _C.muted, size: 18),
              const SizedBox(width: 7),
              Text(
                label,
                style: TextStyle(
                  color: isActive ? Colors.white : _C.muted,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Custom Grid Painter
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _C.red.withOpacity(0.05)
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;

    const gridSize = 30.0;

    for (double x = 0; x <= size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    final accentPaint = Paint()
      ..color = _C.red.withOpacity(0.10)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    for (double x = 0; x <= size.width; x += gridSize * 5) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), accentPaint);
    }
    for (double y = 0; y <= size.height; y += gridSize * 5) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), accentPaint);
    }

    final dotPaint = Paint()
      ..color = _C.red.withOpacity(0.12)
      ..style = PaintingStyle.fill;

    for (double x = 0; x <= size.width; x += gridSize) {
      for (double y = 0; y <= size.height; y += gridSize) {
        canvas.drawCircle(Offset(x, y), 1.5, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}