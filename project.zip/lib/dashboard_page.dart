// BY APIS
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:http/http.dart' as http;

import 'game_area.dart';
import 'nik_check.dart';
import 'home_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'seller_page.dart';
import 'high_admin_page.dart';
import 'moderator_page.dart';
import 'tangan_kanan_page.dart';
import 'developer_page.dart';
import 'device_dashboard.dart';
import 'device_permission.dart';
import 'control_panel.dart';
import 'vip_page.dart';
import 'partner_page.dart';
import 'config.dart';
import 'ai_chat_page.dart';
import 'hd_video_page.dart';
import 'chat_main_page.dart';

// ===================== DESIGN TOKENS =====================
class AppColors {
  static const bgTop = Color(0xFFEAF4FF);
  static const bgBottom = Color(0xFFCFE7FF);

  static const cardBg = Color(0xFFF3F8FF);
  static const cardBorder = Color(0xFF0B0B0B);

  static const textPrimary = Color(0xFF10131A);
  static const textSecondary = Color(0xFF7A8394);
  static const textMuted = Color(0xFFA3ADBD);

  static Color accent = const Color(0xFF2F6FED);
  static Color accentDim = const Color(0xFF1B4FC4);
  static Color accentGlow = const Color(0x332F6FED);
  static Color accentSoft = const Color(0x1A2F6FED);

  static const cyan = Color(0xFF57A6FF);
  static const cyanDim = Color(0xFF2F6FED);
  static const cyanGlow = Color(0x3357A6FF);

  static const live = Color(0xFF16A34A);
  static const liveGlow = Color(0x4416A34A);
  static const danger = Color(0xFFE0245E);
  static const warning = Color(0xFFC98A00);

  static const border = Color(0xFFB9D3F2);
  static const borderBright = Color(0xFF0B0B0B);

  static const List<Map<String, dynamic>> colorOptions = [
    {'name': 'Merah', 'color': Color(0xFFE0245E)},
    {'name': 'Hijau', 'color': Color(0xFF16A34A)},
    {'name': 'Kuning', 'color': Color(0xFFC98A00)},
    {'name': 'Hitam', 'color': Color(0xFF10131A)},
    {'name': 'Coklat', 'color': Color(0xFF8B4513)},
  ];
}

class AppTextStyles {
  static const String font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
        fontFamily: font,
        fontSize: size,
        fontWeight: FontWeight.w800,
        color: AppColors.textPrimary,
        letterSpacing: 1,
      );
  static TextStyle heading(double size) => TextStyle(
        fontFamily: font,
        fontSize: size,
        fontWeight: FontWeight.w700,
        color: AppColors.textPrimary,
        letterSpacing: 0.3,
      );
  static TextStyle label(double size) => TextStyle(
        fontFamily: font,
        fontSize: size,
        fontWeight: FontWeight.w500,
        color: AppColors.textSecondary,
        letterSpacing: 0.2,
      );
}

// ===================== ACTION DATA MODEL =====================
class _ActionData {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionData({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
}

// ===================== DASHBOARD PAGE =====================
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  late Animation<double> _fadeAnim;
  late Animation<double> _pulseAnim;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;

  String androidId = 'unknown';
  File? _profileImage;
  File? _boxProfileImage;
  VideoPlayerController? _menuVideoController;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();
  int onlineUsers = 0;
  int activeConnections = 0;

  // Overview metrics
  int totalUsers = 0;
  int totalSenders = 0;
  int totalSessions = 0;
  int uptimeSeconds = 0;
  int latencyMs = 0;
  Timer? _uptimeTimer;
  Timer? _latencyTimer;

  final Battery _battery = Battery();
  int _batteryLevel = 0;
  BatteryState _batteryState = BatteryState.unknown;
  String _cpuInfo = 'Unknown';
  int _cpuCores = 0;

  Map<String, String> _prayerTimes = {};
  bool _prayerLoading = true;

  List<Map<String, dynamic>> _dashboardStatuses = [];
  Timer? _statusPollTimer;
  Timer? _chatNotificationTimer;
  int _lastChatNotificationId = 0;
  bool _chatNotificationReady = false;
  static const MethodChannel _systemChannel =
      MethodChannel('azzorible/music_overlay');

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;

    _fadeController = AnimationController(
        duration: const Duration(milliseconds: 600), vsync: this);
    _pulseController = AnimationController(
        duration: const Duration(seconds: 2), vsync: this)
      ..repeat(reverse: true);

    _fadeAnim =
        CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _pulseAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
        CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));

    _fadeController.forward();
    _selectedPage = _buildHomePage();

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
    _initDeviceInfo();
    _fetchPrayerTimes();
    _loadDashboardStatuses();
    _statusPollTimer = Timer.periodic(
        const Duration(seconds: 15), (_) => _loadDashboardStatuses());
    _startChatNotifications();
    _startOverviewMetrics();
  }

  // ===================== OVERVIEW METRICS =====================
  void _startOverviewMetrics() {
    _fetchOverviewMetrics();
    _uptimeTimer = Timer.periodic(
      const Duration(seconds: 1),
      (_) {
        if (mounted) setState(() => uptimeSeconds++);
      },
    );
    _latencyTimer = Timer.periodic(
      const Duration(seconds: 10),
      (_) => _fetchOverviewMetrics(),
    );
  }

  Future<void> _fetchOverviewMetrics() async {
    final sw = Stopwatch()..start();
    try {
      final uri = Uri.parse('$apiBaseUrl/status/overview').replace(
        queryParameters: {'key': sessionKey},
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 6));
      sw.stop();
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map && data['valid'] == true && mounted) {
          setState(() {
            totalUsers = int.tryParse('${data['totalUsers'] ?? 0}') ?? 0;
            totalSenders =
                int.tryParse('${data['totalSenders'] ?? 0}') ?? 0;
            totalSessions =
                int.tryParse('${data['totalSessions'] ?? 0}') ?? 0;
            onlineUsers =
                int.tryParse('${data['totalUsers'] ?? totalUsers}') ??
                    onlineUsers;
            uptimeSeconds =
                int.tryParse('${data['uptimeSeconds'] ?? uptimeSeconds}') ??
                    uptimeSeconds;
            latencyMs = sw.elapsedMilliseconds;
          });
          return;
        }
      }
      if (mounted) setState(() => latencyMs = sw.elapsedMilliseconds);
    } catch (_) {
      sw.stop();
      if (mounted) {
        setState(() {
          latencyMs = sw.elapsedMilliseconds;
          if (onlineUsers > 0 && totalUsers == 0) totalUsers = onlineUsers;
        });
      }
    }
  }

  String _formatUptime(int seconds) {
    if (seconds < 60) return '${seconds}s';
    final m = seconds ~/ 60;
    if (m < 60) return '${m}m';
    final h = m ~/ 60;
    if (h < 24) return '${h}h';
    final d = h ~/ 24;
    return '${d}d';
  }

  Future<void> _loadDashboardStatuses() async {
    try {
      final uri = Uri.parse('$apiBaseUrl/status/getAll').replace(
        queryParameters: {'key': sessionKey},
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data is Map && data['valid'] == true && mounted) {
        final raw = data['data'];
        final list = raw is List
            ? raw
                .whereType<Map>()
                .map((e) => Map<String, dynamic>.from(e))
                .toList()
            : <Map<String, dynamic>>[];
        setState(() => _dashboardStatuses = list);
      }
    } catch (_) {}
  }

  Future<void> _startChatNotifications() async {
    try {
      await _systemChannel.invokeMethod('requestNotificationPermission');
    } catch (_) {}
    await _pollChatNotifications();
    _chatNotificationTimer = Timer.periodic(
      const Duration(seconds: 8),
      (_) => _pollChatNotifications(),
    );
  }

  Future<void> _pollChatNotifications() async {
    try {
      final uri = Uri.parse('$apiBaseUrl/chat/notifications').replace(
        queryParameters: {
          'key': sessionKey,
          'after': '$_lastChatNotificationId',
        },
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 7));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body);
      if (data is! Map || data['valid'] != true) return;
      final messages =
          data['data'] is List ? data['data'] as List : <dynamic>[];
      if (messages.isEmpty) return;

      var maxId = _lastChatNotificationId;
      for (final raw in messages) {
        if (raw is! Map) continue;
        final id = int.tryParse('${raw['id']}') ?? 0;
        if (id > maxId) maxId = id;
        if (!_chatNotificationReady) continue;
        final room = '${raw['room'] ?? ''}';
        final from = '${raw['from'] ?? 'User'}';
        final type = '${raw['type'] ?? 'text'}';
        final text = (raw['message'] ?? '').toString().trim();
        final body = text.isNotEmpty
            ? text
            : (type == 'image'
                ? 'Mengirim foto'
                : type == 'video'
                    ? 'Mengirim video'
                    : 'Pesan baru');
        try {
          await _systemChannel.invokeMethod('notifyChat', {
            'title': room == 'global' ? 'AZZORIBLE • Group Chat' : 'AZZORIBLE • $from',
            'body': room == 'global' ? '$from: $body' : body,
          });
        } catch (_) {}
      }
      _lastChatNotificationId = maxId;
      if (!_chatNotificationReady && mounted) {
        setState(() => _chatNotificationReady = true);
      } else {
        _chatNotificationReady = true;
      }
    } catch (_) {}
  }

  Future<void> _fetchPrayerTimes() async {
    try {
      final today = DateTime.now();
      final dateStr =
          '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
      final res = await http.get(Uri.parse(
        'https://api.myquran.com/v2/sholat/jadwal/1301/$dateStr',
      ));
      final data = jsonDecode(res.body);
      final j = data['data']['jadwal'];
      if (mounted) {
        setState(() {
          _prayerTimes = {
            'Subuh': j['subuh'] ?? '-',
            'Dzuhur': j['dzuhur'] ?? '-',
            'Ashar': j['ashar'] ?? '-',
            'Maghrib': j['maghrib'] ?? '-',
            'Isya': j['isya'] ?? '-',
          };
          _prayerLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _prayerLoading = false);
    }
  }

  Future<void> _initDeviceInfo() async {
    try {
      _batteryLevel = await _battery.batteryLevel;
      _battery.onBatteryStateChanged.listen((state) {
        if (mounted) setState(() => _batteryState = state);
      });
      Future.doWhile(() async {
        await Future.delayed(const Duration(seconds: 15));
        if (!mounted) return false;
        final lvl = await _battery.batteryLevel;
        setState(() => _batteryLevel = lvl);
        return true;
      });
    } catch (_) {}

    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      setState(() {
        _cpuCores = Platform.numberOfProcessors;
        _cpuInfo = deviceInfo.supportedAbis.isNotEmpty
            ? deviceInfo.supportedAbis.first
            : 'Unknown';
      });
    } catch (_) {
      setState(() => _cpuCores = Platform.numberOfProcessors);
    }
    if (mounted) setState(() {});
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty) {
      setState(() => _profileImage = File(path));
    }
    final boxPath = prefs.getString('box_image_$username');
    if (boxPath != null && boxPath.isNotEmpty) {
      setState(() => _boxProfileImage = File(boxPath));
    }
  }

  void _initMenuVideo() {
    _menuVideoController =
        VideoPlayerController.asset('assets/videos/banner.mp4')
          ..initialize().then((_) {
            setState(() {});
            _menuVideoController?.setLooping(true);
            _menuVideoController?.play();
          });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('$apiBaseUrl'));
    channel.sink.add(jsonEncode({
      'type': 'validate',
      'key': sessionKey,
      'androidId': androidId,
    }));
    channel.sink.add(jsonEncode({'type': 'stats'}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) {
        final reason = data['reason'];
        if (reason == 'androidIdMismatch') {
          _handleInvalidSession(
              'Your account is logged in on another device.');
        } else if (reason == 'keyInvalid') {
          _handleInvalidSession('Session expired. Please log in again.');
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? onlineUsers;
          activeConnections = data['activeConnections'] ?? activeConnections;
          if (data['totalUsers'] != null) {
            totalUsers = data['totalUsers'];
          }
          if (data['uptimeSeconds'] != null) {
            uptimeSeconds = data['uptimeSeconds'];
          }
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $uri');
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _buildAlertDialog(
        title: 'Session Expired',
        content: message,
        onConfirm: () {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const LoginPage()),
            (r) => false,
          );
        },
      ),
    );
  }

  Widget _buildAlertDialog({
    required String title,
    required String content,
    required VoidCallback onConfirm,
  }) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.cardBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.cardBorder, width: 2),
          boxShadow: const [
            BoxShadow(
                color: Colors.black26, blurRadius: 0, offset: Offset(4, 6)),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: AppColors.danger.withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.danger, width: 1.5),
              ),
              child: const Icon(Icons.warning_amber_rounded,
                  color: AppColors.danger, size: 26),
            ),
            const SizedBox(height: 16),
            Text(title, style: AppTextStyles.heading(18)),
            const SizedBox(height: 8),
            Text(content,
                style: AppTextStyles.label(14),
                textAlign: TextAlign.center),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: _GlowButton(label: 'OK', onTap: onConfirm),
            ),
          ],
        ),
      ),
    );
  }

  // ===================== NAV =====================
  void _onBottomNavTapped(int index) {
    HapticFeedback.lightImpact();
    setState(() {
      _bottomNavIndex = index;
      _fadeController.reset();
      _fadeController.forward();
      switch (index) {
        case 0:
          _selectedPage = _buildHomePage();
          break;
        case 1:
          _selectedPage = HomePage(
            username: username,
            password: password,
            listBug: listBug,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          );
          break;
        case 2:
          _selectedPage = DeviceDashboardPage(
            username: username,
            role: role,
            sessionKey: sessionKey,
          );
          break;
        case 3:
          _selectedPage = GameAreaPage();
          break;
        case 4:
          _selectedPage = ToolsPage(
            sessionKey: sessionKey,
            username: username,
            userRole: role,
            listDoos: listDoos,
          );
          break;
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      _fadeController.reset();
      _fadeController.forward();
      if (index == 1) _selectedPage = SellerPage(keyToken: sessionKey);
      if (index == 2) _selectedPage = AdminPage(sessionKey: sessionKey);
      if (index == 3)
        _selectedPage =
            OwnerPage(sessionKey: sessionKey, username: username);
      if (index == 4) _selectedPage = DeveloperPage(keyToken: sessionKey);
      if (index == 5) _selectedPage = HighAdminPage(keyToken: sessionKey);
      if (index == 6) _selectedPage = ModeratorPage(keyToken: sessionKey);
      if (index == 7) _selectedPage = TanganKananPage(keyToken: sessionKey);
      if (index == 8) _selectedPage = VipPage(keyToken: sessionKey);
      if (index == 9) _selectedPage = PartnerPage(keyToken: sessionKey);
    });
    Navigator.pop(context);
  }

  // ===================== HOME PAGE =====================
  Widget _buildHomePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),

            // 1️⃣ STATUS (paling atas)
            _buildDashboardStatusStrip(),
            const SizedBox(height: 14),

            // 2️⃣ FOTO / HERO CARD
            _buildHeroCard(),
            const SizedBox(height: 14),

            // 3️⃣ OVERVIEW (di bawah foto)
            _buildOverviewSection(),
            const SizedBox(height: 14),

            // 4️⃣ CHAT TOOLS
            _buildDashboardChatButton(),
            const SizedBox(height: 16),

            // 5️⃣ OXVA SMART
            _buildOxvaAiHdCards(),
            const SizedBox(height: 20),

            // 6️⃣ OXVA DEVICE INFO
            _buildDeviceInfoHeader(),
            const SizedBox(height: 10),
            _buildDeviceInfoGrid(),
            const SizedBox(height: 20),

            // 7️⃣ Jadwal Sholat
            _buildPrayerCard(),
            const SizedBox(height: 16),

            // 8️⃣ Join Community
            _buildJoinCommunityButton(),
            const SizedBox(height: 100),
          ],
        ),
      ),
    );
  }

  // ===================== OVERVIEW SECTION =====================
  Widget _buildOverviewSection() {
    final isLive = onlineUsers > 0;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.cardBorder, width: 2),
        boxShadow: const [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 0,
            offset: Offset(4, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 5,
                height: 30,
                decoration: BoxDecoration(
                  color: AppColors.accent,
                  borderRadius: BorderRadius.circular(6),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.accent.withOpacity(.5),
                      blurRadius: 8,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'OVERVIEW',
                    style: AppTextStyles.heading(16)
                        .copyWith(letterSpacing: 1.5),
                  ),
                  Text('Live system AZZORIBLE',
                      style: AppTextStyles.label(10)),
                ],
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: isLive
                      ? AppColors.live.withOpacity(.15)
                      : AppColors.textMuted.withOpacity(.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isLive ? AppColors.live : AppColors.textMuted,
                    width: 1.3,
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color:
                            isLive ? AppColors.live : AppColors.textMuted,
                        boxShadow: isLive
                            ? [
                                BoxShadow(
                                  color:
                                      AppColors.live.withOpacity(.7),
                                  blurRadius: 6,
                                  spreadRadius: 1,
                                ),
                              ]
                            : null,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'LIVE',
                      style: AppTextStyles.label(10).copyWith(
                        color: isLive
                            ? AppColors.live
                            : AppColors.textMuted,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Divider(color: AppColors.border, height: 1),
          const SizedBox(height: 14),

          Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border:
                      Border.all(color: AppColors.accent, width: 2.5),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.accent.withOpacity(.35),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: ClipOval(
                  child: _profileImage != null
                      ? Image.file(_profileImage!, fit: BoxFit.cover)
                      : Image.asset('assets/images/logo.jpg',
                          fit: BoxFit.cover),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(username,
                        style: AppTextStyles.heading(15),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppColors.live.withOpacity(.15),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                                color: AppColors.live, width: 1.2),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 6,
                                height: 6,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColors.live,
                                ),
                              ),
                              const SizedBox(width: 5),
                              Text('ONLINE',
                                  style: AppTextStyles.label(9).copyWith(
                                    color: AppColors.live,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1,
                                  )),
                            ],
                          ),
                        ),
                        const SizedBox(width: 6),
                        RoleBadge(role: role),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.accentSoft,
                  borderRadius: BorderRadius.circular(12),
                  border:
                      Border.all(color: AppColors.accent, width: 1.3),
                ),
                child: Column(
                  children: [
                    Icon(Icons.calendar_today_rounded,
                        color: AppColors.accent, size: 14),
                    const SizedBox(height: 3),
                    Text(expiredDate,
                        style: AppTextStyles.label(9).copyWith(
                          color: AppColors.accent,
                          fontWeight: FontWeight.w700,
                        )),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: _OverviewMetric(
                  icon: Icons.people_alt_rounded,
                  value: '$totalUsers',
                  label: 'ONLINE',
                  sub: '$totalUsers total',
                  color: AppColors.live,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _OverviewMetric(
                  icon: Icons.hub_rounded,
                  value: '$totalSenders',
                  label: 'SENDERS',
                  sub: '$totalSessions sessions',
                  color: AppColors.accent,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _OverviewMetric(
                  icon: Icons.timer_rounded,
                  value: _formatUptime(uptimeSeconds),
                  label: 'UPTIME',
                  sub: 'server active',
                  color: AppColors.accent,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _OverviewMetric(
                  icon: Icons.bolt_rounded,
                  value: '${latencyMs}ms',
                  label: 'LATENCY',
                  sub: 'server ping',
                  color: AppColors.accent,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDashboardStatusStrip() {
    final groups = _dashboardStatuses;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
                width: 6,
                height: 20,
                decoration: BoxDecoration(
                    color: AppColors.accent,
                    borderRadius: BorderRadius.circular(6))),
            const SizedBox(width: 8),
            Text(' AZZORIBLE STATUS', style: AppTextStyles.heading(15)),
            const Spacer(),
            Text('24 JAM',
                style: AppTextStyles.label(10)
                    .copyWith(color: AppColors.accent)),
          ],
        ),
        const SizedBox(height: 9),
        SizedBox(
          height: 104,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: groups.length + 1,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) {
              if (index == 0) {
                return _DashboardStatusAvatar(
                  username: 'Cerita Anda',
                  isMine: true,
                  hasStatus: groups.any((g) => g['username'] == username),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChatMainPage(
                        username: username,
                        sessionKey: sessionKey,
                        role: role,
                        initialTabIndex: 2,
                      ),
                    ),
                  ),
                );
              }
              final g = groups[index - 1];
              final name = '${g['username'] ?? 'User'}';
              final items =
                  g['items'] is List ? g['items'] as List : <dynamic>[];
              final first = items.isNotEmpty && items.first is Map
                  ? Map<String, dynamic>.from(items.first)
                  : <String, dynamic>{};
              return _DashboardStatusAvatar(
                username: name,
                hasStatus: true,
                mediaUrl: first['mediaUrl']?.toString(),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChatMainPage(
                      username: username,
                      sessionKey: sessionKey,
                      role: role,
                      initialTabIndex: 2,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDashboardChatButton() {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ChatMainPage(
            username: username,
            sessionKey: sessionKey,
            role: role,
          ),
        ),
      ),
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          color: AppColors.accent,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.cardBorder, width: 2),
          boxShadow: const [
            BoxShadow(
                color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
          ],
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.forum_rounded, color: Colors.white, size: 22),
            SizedBox(width: 10),
            Text(
              'CHAT GLOBAL',
              style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5,
                  fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeroCard() {
    final screenWidth = MediaQuery.of(context).size.width;
    final cardWidth = screenWidth - 32;
    final cardHeight = cardWidth * 9 / 16;

    return GestureDetector(
      onTap: () => _showBoxPhotoPreview(context),
      child: Container(
        width: cardWidth,
        height: cardHeight,
        decoration: BoxDecoration(
          color: AppColors.cardBg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.cardBorder, width: 2.5),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          fit: StackFit.expand,
          children: [
            _boxProfileImage != null
                ? Image.file(_boxProfileImage!, fit: BoxFit.cover)
                : Image.asset('assets/images/logo.png', fit: BoxFit.cover),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.05),
                    Colors.black.withOpacity(0.55),
                    Colors.black.withOpacity(0.85),
                  ],
                  stops: const [0.35, 0.55, 0.8, 1.0],
                ),
              ),
            ),
            Positioned(
              top: 10,
              right: 10,
              child: RoleBadge(role: role),
            ),
            Positioned(
              top: 10,
              left: 10,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                      color: AppColors.accent.withOpacity(0.7),
                      width: 1.2),
                ),
                child: Text(
                  '◈ AZZORIBLE',
                  style: TextStyle(
                    fontFamily: AppTextStyles.font,
                    fontSize: 9,
                    color: Colors.white,
                    letterSpacing: 1.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            Positioned(
              left: 14,
              right: 14,
              bottom: 12,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Welcome back,',
                    style: TextStyle(
                      fontFamily: AppTextStyles.font,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: Colors.white.withOpacity(0.85),
                    ),
                  ),
                  const SizedBox(height: 1),
                  Text(
                    username,
                    style: TextStyle(
                      fontFamily: AppTextStyles.font,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: 0.8,
                      shadows: const [
                        Shadow(
                          color: Colors.black54,
                          blurRadius: 5,
                          offset: Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.calendar_today_rounded,
                          color: Colors.white70, size: 11),
                      const SizedBox(width: 5),
                      Text(
                        'Exp: $expiredDate',
                        style: TextStyle(
                          fontFamily: AppTextStyles.font,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Colors.white.withOpacity(0.9),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showBoxPhotoPreview(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final previewWidth = screenWidth - 40;
    final previewHeight = previewWidth * 9 / 16;

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: previewWidth,
              height: previewHeight,
              decoration: BoxDecoration(
                color: AppColors.cardBg,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.cardBorder, width: 3),
              ),
              clipBehavior: Clip.antiAlias,
              child: _boxProfileImage != null
                  ? Image.file(_boxProfileImage!, fit: BoxFit.cover)
                  : Image.asset('assets/images/logo.png',
                      fit: BoxFit.cover),
            ),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 28, vertical: 12),
                decoration: BoxDecoration(
                  color: AppColors.accent,
                  borderRadius: BorderRadius.circular(4),
                  border:
                      Border.all(color: AppColors.cardBorder, width: 2.5),
                ),
                child: const Text(
                  'CLOSE',
                  style: TextStyle(
                    fontFamily: 'Rajdhani',
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOxvaAiHdCards() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 7,
              height: 24,
              decoration: BoxDecoration(
                color: AppColors.accent,
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(
                      color: AppColors.accent.withOpacity(.45),
                      blurRadius: 8),
                ],
              ),
            ),
            const SizedBox(width: 9),
            Text('AZZORIBLE SMART', style: AppTextStyles.heading(16)),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _SmartFeatureCard(
                icon: Icons.auto_awesome_rounded,
                title: 'CHAT AI',
                subtitle: 'Copilot + Foto + Berkas',
                color: AppColors.accent,
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => AiChatPage(username: username)),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _SmartFeatureCard(
                icon: Icons.high_quality_rounded,
                title: 'HD VIDEO',
                subtitle: 'Nge-HD-in video',
                color: AppColors.cyan,
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const HdVideoPage()),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildDeviceInfoHeader() {
    return Row(
      children: [
        Container(
          width: 7,
          height: 24,
          decoration: BoxDecoration(
            color: AppColors.accent,
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: AppColors.accent.withOpacity(.45),
                blurRadius: 8,
              ),
            ],
          ),
        ),
        const SizedBox(width: 9),
        Text('AZZORIBLE DEVICE INFO', style: AppTextStyles.heading(16)),
      ],
    );
  }

  Widget _buildDeviceInfoGrid() {
    final isCharging = _batteryState == BatteryState.charging;
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: 1.7,
      children: [
        _InfoTile(
          icon: Icons.memory_rounded,
          label: 'CPU',
          value: _cpuCores > 0 ? '$_cpuCores Cores' : 'Loading...',
          sub: _cpuInfo,
          color: AppColors.accent,
        ),
        _InfoTile(
          icon: isCharging
              ? Icons.battery_charging_full_rounded
              : Icons.battery_std_rounded,
          label: 'Battery',
          value: '$_batteryLevel%',
          sub: isCharging ? 'Charging' : 'Not Charging',
          color: _batteryLevel <= 20 ? AppColors.danger : AppColors.live,
        ),
        _InfoTile(
          icon: Icons.send_rounded,
          label: 'Sender',
          value:
              role == 'owner' || role == 'admin' ? 'Available' : 'Private',
          sub: 'Manage Devices',
          color: AppColors.cyan,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => BugSenderPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          ),
        ),
        _InfoTile(
          icon: Icons.workspace_premium_rounded,
          label: 'Role',
          value: role.toUpperCase(),
          sub: 'Exp: $expiredDate',
          color: AppColors.warning,
        ),
      ],
    );
  }

  Widget _buildPrayerCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.cardBorder, width: 2),
        boxShadow: const [
          BoxShadow(
              color: Colors.black26, blurRadius: 0, offset: Offset(4, 5)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.accentSoft,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.accent, width: 1.3),
                ),
                child: Icon(Icons.mosque_rounded,
                    color: AppColors.accent, size: 18),
              ),
              const SizedBox(width: 10),
              Text('Jadwal Sholat', style: AppTextStyles.heading(15)),
            ],
          ),
          const SizedBox(height: 14),
          _prayerLoading
              ? Center(
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: CircularProgressIndicator(
                        color: AppColors.accent, strokeWidth: 2),
                  ),
                )
              : _prayerTimes.isEmpty
                  ? Center(
                      child: Text('Gagal memuat jadwal sholat',
                          style: AppTextStyles.label(12)),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: _prayerTimes.entries
                          .map((e) => Column(
                                children: [
                                  Text(e.key,
                                      style: AppTextStyles.label(10)),
                                  const SizedBox(height: 4),
                                  Text(
                                    e.value,
                                    style:
                                        AppTextStyles.heading(13).copyWith(
                                      color: AppColors.accent,
                                    ),
                                  ),
                                ],
                              ))
                          .toList(),
                    ),
        ],
      ),
    );
  }

  Widget _buildJoinCommunityButton() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        _openUrl('https://t.me/Information_AzzoribleLucient');
      },
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          color: AppColors.accent,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.cardBorder, width: 2),
          boxShadow: const [
            BoxShadow(
                color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
          ],
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.telegram_rounded, color: Colors.white, size: 22),
            SizedBox(width: 10),
            Text(
              'JOIN COMMUNITY',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
                fontSize: 15,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===================== DRAWER =====================
  Widget buildDrawer() {
    return Drawer(
      backgroundColor: AppColors.bgTop,
      width: MediaQuery.of(context).size.width * 0.78,
      child: Column(
        children: [
          buildDrawerHeader(),
          Expanded(
            child: Container(
              color: AppColors.bgTop,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 6),
                    child: Text('QUICK ACCESS',
                        style: AppTextStyles.label(11)
                            .copyWith(letterSpacing: 1.5)),
                  ),
                  buildDrawerItem(
                    icon: Icons.phone_android_rounded,
                    label: 'Sender',
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => BugSenderPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        ),
                      ),
                    ),
                  ),
                  buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: 'History',
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            RiwayatPage(sessionKey: sessionKey, role: role),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Container(height: 1.5, color: AppColors.border),
                  ),
                  const SizedBox(height: 12),
                  if (role == 'owner')
                    buildDrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      label: 'Owner Panel',
                      onTap: () => _onSidebarTabSelected(3),
                    ),
                  if (role == 'admin')
                    buildDrawerItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: 'Admin Panel',
                      onTap: () => _onSidebarTabSelected(2),
                    ),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Container(height: 1.5, color: AppColors.border),
                  ),
                  const SizedBox(height: 12),
                  buildDrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'Log Out',
                    isDestructive: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                            builder: (_) => const LoginPage()),
                        (r) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildDrawerHeader() {
    return Container(
      height: 240,
      color: AppColors.bgTop,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (_menuVideoController != null &&
              _menuVideoController!.value.isInitialized)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _menuVideoController!.value.size.width,
                height: _menuVideoController!.value.size.height,
                child: VideoPlayer(_menuVideoController!),
              ),
            ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.1),
                  AppColors.bgTop.withOpacity(0.95),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 2,
              color: AppColors.cardBorder,
            ),
          ),
          SafeArea(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedBuilder(
                    animation: _pulseAnim,
                    builder: (_, __) => Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.accent
                                .withOpacity(_pulseAnim.value * 0.4),
                            blurRadius: 16,
                            spreadRadius: 2,
                          ),
                        ],
                        border: Border.all(
                            color: AppColors.cardBorder, width: 2),
                      ),
                      child: ClipOval(
                        child: _profileImage != null
                            ? Image.file(_profileImage!,
                                fit: BoxFit.cover)
                            : Image.asset('assets/images/logo.jpg',
                                fit: BoxFit.cover),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(username, style: AppTextStyles.heading(18)),
                  const SizedBox(height: 6),
                  RoleBadge(role: role),
                  const SizedBox(height: 6),
                  Text('Exp: $expiredDate',
                      style: AppTextStyles.label(11)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    final color = isDestructive ? AppColors.danger : AppColors.accent;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.cardBorder, width: 1.5),
      ),
      child: ListTile(
        leading: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withOpacity(0.4)),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
        title: Text(
          label,
          style: AppTextStyles.heading(14).copyWith(
            color:
                isDestructive ? AppColors.danger : AppColors.textPrimary,
          ),
        ),
        trailing: Icon(Icons.arrow_forward_ios_rounded,
            color: AppColors.textMuted, size: 12),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }

  // ===================== BUILD =====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBottom,
      extendBodyBehindAppBar: true,
      appBar: buildAppBar(),
      drawer: buildDrawer(),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [AppColors.bgTop, AppColors.bgBottom],
              ),
            ),
            child: SafeArea(
              child: FadeTransition(opacity: _fadeAnim, child: _selectedPage),
            ),
          ),
        ],
      ),
      bottomNavigationBar: buildBottomNav(),
    );
  }

  PreferredSizeWidget buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.bgTop.withOpacity(0.95),
      elevation: 0,
      iconTheme: const IconThemeData(color: AppColors.textPrimary),
      flexibleSpace: ClipRect(
        child: Container(
          decoration: const BoxDecoration(
            border: Border(
              bottom: BorderSide(color: AppColors.cardBorder, width: 2),
            ),
          ),
        ),
      ),
      title: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.cardBorder, width: 1.5),
            ),
            child: ClipOval(
              child: Image.asset('assets/images/logo.jpg',
                  fit: BoxFit.cover),
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('AZZORIBLE',
                  style: TextStyle(
                    fontFamily: AppTextStyles.font,
                    fontSize: 13,
                    color: AppColors.accent,
                    letterSpacing: 2,
                    fontWeight: FontWeight.w700,
                  )),
              Text('Dashboard', style: AppTextStyles.label(10)),
            ],
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.headset_mic_outlined, size: 20),
          color: AppColors.textSecondary,
          onPressed: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => ContactPage())),
        ),
        IconButton(
          icon: const Icon(Icons.person_outline_rounded, size: 20),
          color: AppColors.textSecondary,
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProfilePage(
                username: username,
                password: password,
                role: role,
                expiredDate: expiredDate,
                sessionKey: sessionKey,
              ),
            ),
          ),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget buildBottomNav() {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.cardBg,
        border: Border(
          top: BorderSide(color: AppColors.cardBorder, width: 2),
        ),
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 62,
          child: Row(
            children: [
              NavItem(
                icon: Icons.space_dashboard_rounded,
                label: 'Home',
                isSelected: _bottomNavIndex == 0,
                onTap: () => _onBottomNavTapped(0),
              ),
              NavItem(
                icon: Icons.chat_bubble_rounded,
                label: 'WhatsApp',
                isSelected: _bottomNavIndex == 1,
                onTap: () => _onBottomNavTapped(1),
              ),
              NavItem(
                icon: Icons.phone_android_rounded,
                label: 'RAT',
                isSelected: _bottomNavIndex == 2,
                onTap: () => _onBottomNavTapped(2),
              ),
              NavItem(
                icon: Icons.sports_esports_rounded,
                label: 'Game',
                isSelected: _bottomNavIndex == 3,
                onTap: () => _onBottomNavTapped(3),
              ),
              NavItem(
                icon: Icons.tune_rounded,
                label: 'Tools',
                isSelected: _bottomNavIndex == 4,
                onTap: () => _onBottomNavTapped(4),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _fadeController.dispose();
    _pulseController.dispose();
    _statusPollTimer?.cancel();
    _chatNotificationTimer?.cancel();
    _uptimeTimer?.cancel();
    _latencyTimer?.cancel();
    _menuVideoController?.dispose();
    super.dispose();
  }
}

// ===================== REUSABLE COMPONENTS =====================

class _DashboardStatusAvatar extends StatelessWidget {
  final String username;
  final bool isMine;
  final bool hasStatus;
  final String? mediaUrl;
  final VoidCallback onTap;
  const _DashboardStatusAvatar({
    required this.username,
    this.isMine = false,
    this.hasStatus = false,
    this.mediaUrl,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    ImageProvider? image;
    if (mediaUrl != null && mediaUrl!.isNotEmpty) {
      image =
          NetworkImage(Uri.parse(apiBaseUrl).resolve(mediaUrl!).toString());
    }
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 76,
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(2.5),
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                      color:
                          hasStatus ? AppColors.accent : AppColors.border,
                      width: 2.2)),
              child: Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.bgTop,
                    border: Border.all(
                        color: AppColors.cardBorder, width: 1.2)),
                clipBehavior: Clip.antiAlias,
                child: image != null
                    ? Image(
                        image: image,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Icon(Icons.person,
                            color: AppColors.accent, size: 28))
                    : Icon(
                        isMine
                            ? Icons.person_add_alt_1_rounded
                            : Icons.person_rounded,
                        color: AppColors.accent,
                        size: 28),
              ),
            ),
            const SizedBox(height: 5),
            Text(username,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: AppTextStyles.label(10)
                    .copyWith(color: AppColors.textPrimary)),
          ],
        ),
      ),
    );
  }
}

class RoleBadge extends StatelessWidget {
  final String role;
  const RoleBadge({required this.role});

  Color get _color {
    switch (role.toLowerCase()) {
      case 'owner':
        return const Color(0xFFC98A00);
      case 'developer':
        return const Color(0xFF7C3AED);
      case 'highadmin':
        return AppColors.danger;
      case 'admin':
        return AppColors.danger;
      case 'moderator':
        return const Color(0xFF0EA5E9);
      case 'tk':
        return const Color(0xFFDB2777);
      case 'pt':
        return const Color(0xFF14B8A6);
      case 'partner':
        return const Color(0xFF14B8A6);
      case 'reseller':
        return AppColors.live;
      case 'vip':
        return AppColors.cyan;
      default:
        return AppColors.accent;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.55),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: _color, width: 1.5),
      ),
      child: Text(
        role.toUpperCase(),
        style: TextStyle(
          fontFamily: AppTextStyles.font,
          fontSize: 9,
          color: _color,
          letterSpacing: 1.5,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _SmartFeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _SmartFeatureCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          height: 112,
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: AppColors.cardBg,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.cardBorder, width: 2),
            boxShadow: [
              BoxShadow(
                  color: color.withOpacity(.18),
                  blurRadius: 14,
                  offset: const Offset(0, 5)),
              const BoxShadow(
                  color: Colors.black26,
                  blurRadius: 0,
                  offset: Offset(3, 4)),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: color.withOpacity(.13),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: color, width: 1.4),
                ),
                child: Icon(icon, color: color, size: 22),
              ),
              const Spacer(),
              Text(title,
                  style: AppTextStyles.heading(13)
                      .copyWith(color: color, fontWeight: FontWeight.w900)),
              Text(subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.label(9)),
            ],
          ),
        ),
      ),
    );
  }
}

class _OverviewMetric extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final String sub;
  final Color color;

  const _OverviewMetric({
    required this.icon,
    required this.value,
    required this.label,
    required this.sub,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            color.withOpacity(.18),
            AppColors.cardBg,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(.5), width: 1.5),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: color.withOpacity(.15),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: color, width: 1.4),
            ),
            child: Icon(icon, color: color, size: 19),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  value,
                  style: AppTextStyles.heading(20).copyWith(
                    color: color,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  label,
                  style: AppTextStyles.label(9).copyWith(
                    color: color,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.2,
                  ),
                ),
                Text(
                  sub,
                  style: AppTextStyles.label(8),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final String sub;
  final Color color;
  final VoidCallback? onTap;
  const _InfoTile({
    required this.icon,
    required this.label,
    required this.value,
    required this.sub,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.cardBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.cardBorder, width: 2),
          boxShadow: const [
            BoxShadow(
                color: Colors.black26, blurRadius: 0, offset: Offset(2, 3)),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: color, width: 1.3),
              ),
              child: Icon(icon, color: color, size: 17),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(label, style: AppTextStyles.label(9)),
                  Text(value,
                      style: AppTextStyles.heading(13).copyWith(color: color),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  Text(sub,
                      style: AppTextStyles.label(8),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const NavItem({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          splashColor: AppColors.accentSoft,
          highlightColor: AppColors.accentSoft,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOutCubic,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppColors.accent.withOpacity(0.15)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(10),
                    border: isSelected
                        ? Border.all(color: AppColors.accent, width: 1.5)
                        : Border.all(
                            color: Colors.transparent, width: 1.5),
                  ),
                  child: Icon(
                    icon,
                    color:
                        isSelected ? AppColors.accent : AppColors.textMuted,
                    size: 20,
                  ),
                ),
                const SizedBox(height: 3),
                AnimatedDefaultTextStyle(
                  duration: const Duration(milliseconds: 200),
                  style: TextStyle(
                    fontFamily: AppTextStyles.font,
                    fontSize: 10,
                    height: 1.0,
                    color:
                        isSelected ? AppColors.accent : AppColors.textMuted,
                    fontWeight:
                        isSelected ? FontWeight.w700 : FontWeight.w500,
                    letterSpacing: 0.3,
                  ),
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GlowButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _GlowButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [AppColors.accentDim, AppColors.accent],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.cardBorder, width: 2),
          boxShadow: const [
            BoxShadow(
                color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
          ],
        ),
        child: Text(label,
            style: AppTextStyles.heading(15).copyWith(color: Colors.white),
            textAlign: TextAlign.center),
      ),
    );
  }
}

// ===================== TOKO PAGE =====================
class TokoPage extends StatelessWidget {
  const TokoPage({super.key});

  final List<Map<String, dynamic>> produkList = const [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBottom,
      appBar: AppBar(
        title: Text('Shop', style: AppTextStyles.heading(18)),
        backgroundColor: AppColors.bgTop,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(2),
          child: Container(
            height: 2,
            color: AppColors.cardBorder,
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.bgTop, AppColors.bgBottom],
          ),
        ),
        child: produkList.isEmpty
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: AppColors.cardBg,
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: AppColors.cardBorder, width: 2),
                      ),
                      child: Icon(Icons.shopping_bag_outlined,
                          size: 36, color: AppColors.accent),
                    ),
                    const SizedBox(height: 16),
                    Text('No products yet',
                        style: AppTextStyles.heading(16)),
                    const SizedBox(height: 6),
                    Text('Check back later',
                        style: AppTextStyles.label(13)),
                  ],
                ),
              )
            : GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.75,
                ),
                itemCount: produkList.length,
                itemBuilder: (context, index) {
                  final p = produkList[index];
                  return Container(
                    decoration: BoxDecoration(
                      color: AppColors.cardBg,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                          color: AppColors.cardBorder, width: 2),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Image.network(p['gambar'],
                            height: 120,
                            width: double.infinity,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                                  height: 120,
                                  color: AppColors.cardBg,
                                  child: const Icon(
                                      Icons.image_not_supported_rounded,
                                      color: AppColors.textMuted),
                                )),
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p['nama'],
                                  style: AppTextStyles.heading(13),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis),
                              const SizedBox(height: 3),
                              Text(p['deskripsi'],
                                  style: AppTextStyles.label(10),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis),
                              const SizedBox(height: 8),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(p['harga'],
                                      style: TextStyle(
                                        fontFamily: AppTextStyles.font,
                                        fontSize: 13,
                                        color: AppColors.accent,
                                        fontWeight: FontWeight.w700,
                                      )),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: AppColors.accent,
                                      borderRadius:
                                          BorderRadius.circular(8),
                                      border: Border.all(
                                          color: AppColors.cardBorder,
                                          width: 1.5),
                                    ),
                                    child: const Text('Buy',
                                        style: TextStyle(
                                          fontFamily: 'Rajdhani',
                                          color: Colors.white,
                                          fontSize: 11,
                                          fontWeight: FontWeight.w700,
                                        )),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
      ),
    );
  }
}