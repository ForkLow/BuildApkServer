import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

// ===================== DESIGN TOKENS (Sama seperti Dashboard) =====================
class AppColors {
  static const bgTop = Color(0xFFEAF4FF);
  static const bgBottom = Color(0xFFCFE7FF);

  static const cardBg = Color(0xFFF3F8FF);
  static const cardBorder = Color(0xFF0B0B0B);

  static const textPrimary = Color(0xFF10131A);
  static const textSecondary = Color(0xFF7A8394);
  static const textMuted = Color(0xFFA3ADBD);

  static const accent = Color(0xFF2F6FED);
  static const accentDim = Color(0xFF1B4FC4);
  static const accentSoft = Color(0x1A2F6FED);

  static const danger = Color(0xFFE0245E);
  static const warning = Color(0xFFC98A00);
  static const live = Color(0xFF16A34A);
}

class AppTextStyles {
  static const String font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
        fontFamily: font,
        fontSize: size,
        fontWeight: FontWeight.w800,
        color: AppColors.textPrimary,
        letterSpacing: 1,
      );
  static TextStyle heading(double size) => TextStyle(
        fontFamily: font,
        fontSize: size,
        fontWeight: FontWeight.w700,
        color: AppColors.textPrimary,
        letterSpacing: 0.3,
      );
  static TextStyle label(double size) => TextStyle(
        fontFamily: font,
        fontSize: size,
        fontWeight: FontWeight.w500,
        color: AppColors.textSecondary,
        letterSpacing: 0.2,
      );
}

// ===================== WHATSAPP APPEAL PAGE =====================
class WhatsAppAppealPage extends StatefulWidget {
  const WhatsAppAppealPage({super.key});

  @override
  State<WhatsAppAppealPage> createState() => _WhatsAppAppealPageState();
}

class _WhatsAppAppealPageState extends State<WhatsAppAppealPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _gmailController = TextEditingController();

  // Daftar Gmail yang ditambahkan
  List<String> _gmailList = [];
  String? _selectedGmail;

  @override
  void initState() {
    super.initState();
    // Tambahkan Gmail default jika ada
    _gmailList.add('support@senzy.com'); // Contoh default, bisa diubah
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _gmailController.dispose();
    super.dispose();
  }

  // ── TAMBAH GMAIL ──
  void _addGmail() {
    final email = _gmailController.text.trim();
    if (email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Masukkan alamat Gmail terlebih dahulu',
              style: AppTextStyles.label(12).copyWith(color: Colors.white)),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }
    if (!email.contains('@')) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Format email tidak valid',
              style: AppTextStyles.label(12).copyWith(color: Colors.white)),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }
    if (_gmailList.contains(email)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gmail sudah ada dalam daftar',
              style: AppTextStyles.label(12).copyWith(color: Colors.white)),
          backgroundColor: AppColors.warning,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() {
      _gmailList.add(email);
      _gmailController.clear();
      if (_selectedGmail == null) {
        _selectedGmail = email;
      }
    });
  }

  // ── HAPUS GMAIL ──
  void _removeGmail(String email) {
    setState(() {
      _gmailList.remove(email);
      if (_selectedGmail == email) {
        _selectedGmail = _gmailList.isNotEmpty ? _gmailList.first : null;
      }
    });
  }

  // ── KIRIM BANDING VIA GMAIL APP ──
  Future<void> _submitAppeal() async {
    if (!_formKey.currentState!.validate()) return;

    if (_selectedGmail == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Pilih Gmail tujuan terlebih dahulu',
              style: AppTextStyles.label(12).copyWith(color: Colors.white)),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final phone = _phoneController.text.trim();
    final subject = 'Report Banding WhatsApp No Merah - $phone';
    final body = '''
Halo Tim AZZORIBLE,

Saya ingin mengajukan banding untuk nomor WhatsApp saya yang terkena banned.

Nomor WhatsApp: $phone

Mohon untuk ditinjau kembali. Terima kasih.

Salam,
Pengguna AZZORIBLE
''';

    // Buat URI mailto
    final Uri emailUri = Uri(
      scheme: 'mailto',
      path: _selectedGmail,
      queryParameters: {
        'subject': subject,
        'body': body,
      },
    );

    try {
      if (await canLaunchUrl(emailUri)) {
        await launchUrl(emailUri);
      } else {
        throw 'Tidak dapat membuka aplikasi Gmail';
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal membuka Gmail: $e',
              style: AppTextStyles.label(12).copyWith(color: Colors.white)),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBottom,
      appBar: AppBar(
        title: Text('WhatsApp Appeal', style: AppTextStyles.heading(18)),
        backgroundColor: AppColors.bgTop,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(2),
          child: Container(height: 2, color: AppColors.cardBorder),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.bgTop, AppColors.bgBottom],
          ),
        ),
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── HEADER CARD ──
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppColors.danger,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.cardBorder, width: 2.5),
                    boxShadow: const [
                      BoxShadow(
                          color: Colors.black26,
                          blurRadius: 0,
                          offset: Offset(4, 6)),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.white, width: 1.5),
                            ),
                            child: const Icon(Icons.report_rounded,
                                color: Colors.white, size: 24),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'REPORT BANDING',
                                  style: AppTextStyles.heading(18)
                                      .copyWith(color: Colors.white),
                                ),
                                Text(
                                  'WhatsApp No Merah',
                                  style: AppTextStyles.label(12)
                                      .copyWith(color: Colors.white70),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Ajukan banding untuk nomor WhatsApp Anda yang terkena banned. Report akan dikirim melalui Gmail App.',
                        style: AppTextStyles.label(12)
                            .copyWith(color: Colors.white.withOpacity(0.9)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // ── FORM INPUT NOMOR WA ──
                Text('NOMOR WHATSAPP', style: AppTextStyles.heading(12)),
                const SizedBox(height: 6),
                Container(
                  decoration: BoxDecoration(
                    color: AppColors.cardBg,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.cardBorder, width: 2),
                    boxShadow: const [
                      BoxShadow(
                          color: Colors.black12,
                          blurRadius: 0,
                          offset: Offset(2, 3)),
                    ],
                  ),
                  child: TextFormField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    style: AppTextStyles.heading(14),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Nomor WhatsApp wajib diisi';
                      }
                      if (value.length < 10) {
                        return 'Nomor WhatsApp tidak valid';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      hintText: 'Contoh: 6281234567890',
                      hintStyle: AppTextStyles.label(13),
                      prefixIcon: Container(
                        margin: const EdgeInsets.all(8),
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: AppColors.accentSoft,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.accent, width: 1.3),
                        ),
                        child: const Icon(Icons.phone_android_rounded,
                            color: AppColors.accent, size: 18),
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // ── GMAIL MANAGER ──
                Text('GMAIL TUJUAN', style: AppTextStyles.heading(12)),
                const SizedBox(height: 6),

                // Input tambah Gmail
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppColors.cardBg,
                          borderRadius: BorderRadius.circular(14),
                          border:
                              Border.all(color: AppColors.cardBorder, width: 2),
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.black12,
                                blurRadius: 0,
                                offset: Offset(2, 3)),
                          ],
                        ),
                        child: TextFormField(
                          controller: _gmailController,
                          keyboardType: TextInputType.emailAddress,
                          style: AppTextStyles.heading(14),
                          decoration: InputDecoration(
                            hintText: 'Masukkan alamat Gmail...',
                            hintStyle: AppTextStyles.label(13),
                            prefixIcon: Container(
                              margin: const EdgeInsets.all(8),
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                color: AppColors.accentSoft,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    color: AppColors.accent, width: 1.3),
                              ),
                              child: const Icon(Icons.email_rounded,
                                  color: AppColors.accent, size: 18),
                            ),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 14),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    GestureDetector(
                      onTap: _addGmail,
                      child: Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: AppColors.accent,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: AppColors.cardBorder, width: 2),
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.black26,
                                blurRadius: 0,
                                offset: Offset(2, 3)),
                          ],
                        ),
                        child: const Icon(Icons.add_rounded,
                            color: Colors.white, size: 26),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                // Daftar Gmail yang ditambahkan
                if (_gmailList.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.cardBg,
                      borderRadius: BorderRadius.circular(14),
                      border:
                          Border.all(color: AppColors.cardBorder, width: 2),
                      boxShadow: const [
                        BoxShadow(
                            color: Colors.black12,
                            blurRadius: 0,
                            offset: Offset(2, 3)),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Daftar Gmail:',
                            style: AppTextStyles.label(11)),
                        const SizedBox(height: 8),
                        ..._gmailList.map((email) {
                          final isSelected = _selectedGmail == email;
                          return GestureDetector(
                            onTap: () {
                              setState(() => _selectedGmail = email);
                            },
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 6),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 8),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? AppColors.accentSoft
                                    : Colors.transparent,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: isSelected
                                      ? AppColors.accent
                                      : AppColors.cardBorder,
                                  width: isSelected ? 2 : 1.2,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    isSelected
                                        ? Icons.radio_button_checked_rounded
                                        : Icons.radio_button_off_rounded,
                                    color: isSelected
                                        ? AppColors.accent
                                        : AppColors.textMuted,
                                    size: 18,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      email,
                                      style: AppTextStyles.heading(12)
                                          .copyWith(
                                        color: isSelected
                                            ? AppColors.accent
                                            : AppColors.textPrimary,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () => _removeGmail(email),
                                    child: Container(
                                      padding: const EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: AppColors.danger
                                            .withOpacity(0.1),
                                        borderRadius:
                                            BorderRadius.circular(6),
                                        border: Border.all(
                                            color: AppColors.danger,
                                            width: 1),
                                      ),
                                      child: const Icon(
                                          Icons.delete_outline_rounded,
                                          color: AppColors.danger,
                                          size: 16),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }).toList(),
                      ],
                    ),
                  ),
                const SizedBox(height: 24),

                // ── TOMBOL KIRIM ──
                GestureDetector(
                  onTap: _submitAppeal,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.accentDim, AppColors.accent],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border:
                          Border.all(color: AppColors.cardBorder, width: 2.5),
                      boxShadow: const [
                        BoxShadow(
                            color: Colors.black26,
                            blurRadius: 0,
                            offset: Offset(4, 6)),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.send_rounded,
                            color: Colors.white, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          'KIRIM VIA GMAIL',
                          style: AppTextStyles.heading(16)
                              .copyWith(color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // ── INFO CARD ──
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.cardBg,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.cardBorder, width: 2),
                    boxShadow: const [
                      BoxShadow(
                          color: Colors.black26,
                          blurRadius: 0,
                          offset: Offset(3, 4)),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.warning.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: AppColors.warning, width: 1.5),
                        ),
                        child: const Icon(Icons.info_outline_rounded,
                            color: AppColors.warning, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Pastikan Gmail tujuan sudah benar. Report akan dikirim melalui aplikasi Gmail di perangkat Anda.',
                          style: AppTextStyles.label(12),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }
}