// buy_account_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

// ── Design Tokens (tema terang, sama dengan landing page) ──
class _C {
  static const bgTop = Color(0xFFEAF4FF);
  static const bgBottom = Color(0xFFCFE7FF);

  static const cardBg = Color(0xFFF3F8FF);
  static const cardBorder = Color(0xFF0B0B0B);

  static const accent     = Color(0xFF2F6FED);
  static const accentDim  = Color(0xFF1B4FC4);
  static const accentGlow = Color(0x332F6FED);
  static const accentSoft = Color(0x1A2F6FED);

  static const cyan     = Color(0xFF57A6FF);
  static const cyanGlow = Color(0x3357A6FF);

  static const textPrimary   = Color(0xFF10131A);
  static const textSecondary = Color(0xFF7A8394);
  static const textMuted     = Color(0xFFA3ADBD);

  static const borderBright = Color(0xFF0B0B0B);
}

class _T {
  static const font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w800,
    color: _C.textPrimary, letterSpacing: 1,
  );
  static TextStyle heading(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textPrimary, letterSpacing: 0.3,
  );
  static TextStyle label(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w500,
    color: _C.textSecondary, letterSpacing: 0.2,
  );
}

class BuyAccountPage extends StatelessWidget {
  const BuyAccountPage({super.key});

  final List<Map<String, String>> priceList = const [
    {
      "title": "Member Account",
      "monthly": "20K IDR / Month",
      "permanent": "30K IDR / Permanent",
      "icon": "person",
    },
    {
      "title": "Reseller Account",
      "monthly": "50K IDR",
      "icon": "storefront",
    },
    {
      "title": "Partner Account",
      "monthly": "60K IDR",
      "icon": "handshake",
    },
    {
      "title": "Mod Account",
      "monthly": "70K IDR",
      "icon": "shield",
    },
    {
      "title": "Owner Account",
      "monthly": "80K IDR",
      "icon": "workspace_premium",
    },
    {
      "title": "Project Account",
      "monthly": "90K IDR",
      "icon": "rocket_launch",
    },
    {
      "title": "High Admin Account",
      "monthly": "100K IDR",
      "icon": "admin_panel_settings",
    },
  ];

  static const Map<String, IconData> _iconMap = {
    "person": Icons.person_rounded,
    "storefront": Icons.storefront_rounded,
    "handshake": Icons.handshake_rounded,
    "shield": Icons.shield_rounded,
    "workspace_premium": Icons.workspace_premium_rounded,
    "rocket_launch": Icons.rocket_launch_rounded,
    "admin_panel_settings": Icons.admin_panel_settings_rounded,
  };

  // ── Dialog QRIS + Dana + Contact ──────────────────────────
  Future<void> _showBuyDialog(BuildContext context, String plan, String price) async {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: _C.cardBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _C.cardBorder, width: 2),
            boxShadow: const [
              BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(5, 7)),
            ],
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // ── Header ──
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(text: 'BUY '.toUpperCase(), style: _T.display(18).copyWith(color: _C.textPrimary)),
                      TextSpan(text: plan.toUpperCase(), style: _T.display(18).copyWith(color: _C.accent)),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 4),
                Text(price, style: _T.label(14).copyWith(color: _C.accent, fontWeight: FontWeight.w700)),
                const SizedBox(height: 20),

                // ── QRIS Image ──
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: _C.cardBorder, width: 2),
                    boxShadow: const [
                      BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Image.network(
                      'https://files.catbox.moe/cyfmfc.jpeg',
                      height: 220,
                      fit: BoxFit.contain,
                      loadingBuilder: (_, child, progress) {
                        if (progress == null) return child;
                        return SizedBox(
                          height: 220,
                          child: Center(
                            child: CircularProgressIndicator(
                              color: _C.accent,
                              value: progress.expectedTotalBytes != null
                                  ? progress.cumulativeBytesLoaded /
                                  progress.expectedTotalBytes!
                                  : null,
                            ),
                          ),
                        );
                      },
                      errorBuilder: (_, __, ___) => SizedBox(
                        height: 220,
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.qr_code_2_rounded, color: _C.accent, size: 60),
                              const SizedBox(height: 8),
                              Text('QRIS tidak tersedia', style: _T.label(12)),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // ── Dana Number ──
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _C.cardBorder, width: 1.5),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 36, height: 36,
                        decoration: BoxDecoration(
                          color: _C.accentSoft,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: _C.accent.withOpacity(0.4)),
                        ),
                        child: const Icon(Icons.account_balance_wallet_rounded,
                            color: _C.accent, size: 18),
                      ),
                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('DANA', style: _T.heading(13).copyWith(color: _C.accent)),
                          Text('08138768292',
                              style: _T.display(15).copyWith(
                                color: _C.textPrimary,
                                letterSpacing: 2,
                              )),
                        ],
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(
                              const ClipboardData(text: '08138768292'));
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Nomor disalin!',
                                  style: _T.label(13).copyWith(color: Colors.white)),
                              backgroundColor: _C.accentDim,
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                                side: const BorderSide(color: _C.cardBorder, width: 1.5),
                              ),
                              duration: const Duration(seconds: 2),
                            ),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.all(7),
                          decoration: BoxDecoration(
                            color: _C.accentSoft,
                            borderRadius: BorderRadius.circular(9),
                            border: Border.all(color: _C.accent, width: 1.2),
                          ),
                          child: const Icon(Icons.copy_rounded,
                              color: _C.accent, size: 16),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // ── Divider ──
                Row(
                  children: [
                    Expanded(
                      child: Container(height: 1.5, color: _C.cardBorder.withOpacity(0.15)),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Text('ATAU HUBUNGI',
                          style: _T.label(9).copyWith(letterSpacing: 2)),
                    ),
                    Expanded(
                      child: Container(height: 1.5, color: _C.cardBorder.withOpacity(0.15)),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // ── Contact Buttons ──
                Row(
                  children: [
                    Expanded(
                      child: _contactBtn(
                        context: context,
                        icon: Icons.telegram_rounded,
                        label: 'Telegram',
                        color: const Color(0xFF29B6F6),
                        onTap: () async {
                          Navigator.pop(context);
                          final uri =
                          Uri.parse("tg://resolve?domain=SenzOkkotsu");
                          if (await canLaunchUrl(uri)) {
                            await launchUrl(uri,
                                mode: LaunchMode.externalApplication);
                          } else {
                            await launchUrl(
                                Uri.parse("https://t.me/SenzOkkotsu"),
                                mode: LaunchMode.externalApplication);
                          }
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _contactBtn(
                        context: context,
                        icon: Icons.chat_rounded,
                        label: 'WhatsApp',
                        color: const Color(0xFF25D366),
                        onTap: () async {
                          Navigator.pop(context);
                          final uri = Uri.parse(
                              "https://wa.me/628138768292?text=Halo%20saya%20mau%20beli%20$plan");
                          if (await canLaunchUrl(uri)) {
                            await launchUrl(uri,
                                mode: LaunchMode.externalApplication);
                          }
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // ── Close ──
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 24),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _C.cardBorder.withOpacity(0.3), width: 1.2),
                    ),
                    child: Text(
                      'TUTUP',
                      style: _T.label(13).copyWith(letterSpacing: 2),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _contactBtn({
    required BuildContext context,
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color, width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 8),
            Text(label, style: _T.heading(14).copyWith(color: color)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bgBottom,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_C.bgTop, _C.bgBottom],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // ── AppBar custom ──
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        HapticFeedback.lightImpact();
                        Navigator.pop(context);
                      },
                      child: Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: _C.cardBg,
                          borderRadius: BorderRadius.circular(13),
                          border: Border.all(color: _C.cardBorder, width: 2),
                          boxShadow: const [
                            BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(2, 3)),
                          ],
                        ),
                        child: const Icon(Icons.arrow_back_ios_new_rounded,
                            color: _C.accent, size: 18),
                      ),
                    ),
                    const SizedBox(width: 14),
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(text: 'BUY ', style: _T.display(22).copyWith(color: _C.textPrimary)),
                          TextSpan(text: 'ACCESS', style: _T.display(22).copyWith(color: _C.accent)),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: _C.cardBg,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _C.cardBorder, width: 1.5),
                      ),
                      child: Text(
                        '${priceList.length} PLANS',
                        style:
                        _T.label(10).copyWith(letterSpacing: 1.5, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),

              // ── List ──
              Expanded(
                child: ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 8),
                  itemCount: priceList.length,
                  itemBuilder: (context, index) {
                    final item = priceList[index];
                    return _buildPriceCard(context, item, index);
                  },
                ),
              ),

              // ── Footer ──
              Padding(
                padding: const EdgeInsets.only(bottom: 16, top: 4),
                child: Text(
                  '© 2026 AZZORIBLE LUCIENT',
                  style: _T.label(11),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPriceCard(BuildContext context, Map<String, String> item, int index) {
    final icon = _iconMap[item["icon"]] ?? Icons.workspace_premium_rounded;
    // Warna aksen bergantian biar tiap kartu punya nuansa berbeda tapi tetap dalam palet biru
    final accentColors = [_C.accent, _C.cyan];
    final cardAccent = accentColors[index % accentColors.length];

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 300 + index * 60),
      curve: Curves.easeOutBack,
      builder: (_, v, child) => Transform.translate(
        offset: Offset(0, (1 - v) * 16),
        child: Opacity(opacity: v.clamp(0, 1), child: child),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: _C.cardBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _C.cardBorder, width: 2),
          boxShadow: const [
            BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 5)),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // ── Icon badge ──
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: cardAccent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: cardAccent, width: 1.5),
                ),
                child: Icon(icon, color: cardAccent, size: 24),
              ),
              const SizedBox(width: 14),

              // ── Info ──
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item["title"]!,
                      style: _T.heading(15),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.calendar_month_rounded,
                            color: _C.textSecondary, size: 13),
                        const SizedBox(width: 5),
                        Flexible(
                          child: Text(item["monthly"]!,
                              style: _T.label(12).copyWith(
                                  color: _C.textPrimary, fontWeight: FontWeight.w600),
                              overflow: TextOverflow.ellipsis),
                        ),
                      ],
                    ),
                    if (item["permanent"] != null) ...[
                      const SizedBox(height: 3),
                      Row(
                        children: [
                          Icon(Icons.all_inclusive_rounded,
                              color: _C.accent, size: 13),
                          const SizedBox(width: 5),
                          Flexible(
                            child: Text(item["permanent"]!,
                                style: _T.label(12),
                                overflow: TextOverflow.ellipsis),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 10),

              // ── Buy Button ──
              GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  _showBuyDialog(
                    context,
                    item["title"]!,
                    item["monthly"]!,
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 18, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [_C.accentDim, _C.accent],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(13),
                    border: Border.all(color: _C.cardBorder, width: 1.5),
                    boxShadow: const [
                      BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(2, 3)),
                    ],
                  ),
                  child: Text(
                    'BUY',
                    style: _T.heading(13).copyWith(color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}