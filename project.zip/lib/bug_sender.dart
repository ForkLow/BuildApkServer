// bug_sender.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

// ── Design Tokens (tema terang) ──────────────────────────────
class _C {
  static const bgTop = Color(0xFFEAF4FF);
  static const bgBottom = Color(0xFFCFE7FF);

  static const cardBg = Color(0xFFF3F8FF);
  static const cardBorder = Color(0xFF0B0B0B);

  static const accent     = Color(0xFF2F6FED);
  static const accentDim  = Color(0xFF1B4FC4);
  static const accentSoft = Color(0x1A2F6FED);

  static const cyan     = Color(0xFF57A6FF);

  static const live    = Color(0xFF16A34A);
  static const danger  = Color(0xFFE0245E);
  static const warning = Color(0xFFC98A00);

  static const textPrimary   = Color(0xFF10131A);
  static const textSecondary = Color(0xFF7A8394);
  static const textMuted     = Color(0xFFA3ADBD);

  static const border       = Color(0xFFB9D3F2);
  static const borderBright = Color(0xFF0B0B0B);
}

class _T {
  static const font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w800,
    color: _C.textPrimary, letterSpacing: 1,
  );
  static TextStyle heading(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textPrimary, letterSpacing: 0.3,
  );
  static TextStyle label(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w500,
    color: _C.textSecondary, letterSpacing: 0.2,
  );
  static TextStyle mono(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.accent, letterSpacing: 4,
  );
}

// ── Page ───────────────────────────────────────────────────
class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage>
    with SingleTickerProviderStateMixin {
  List<dynamic> senderList = [];
  bool isLoading = false;
  String? errorMessage;
  late TabController _tabCtrl;

  bool get canAddGlobal =>
      ['owner', 'developer'].contains(widget.role.toLowerCase());

  List<dynamic> get _privateSenders =>
      senderList.where((s) => s['isGlobal'] != true).toList();

  List<dynamic> get _globalSenders =>
      senderList.where((s) => s['isGlobal'] == true).toList();

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _tabCtrl.addListener(() => setState(() {}));
    _fetchSenders();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  // ── API calls ──────────────────────────────────────────────
  Future<void> _fetchSenders() async {
    setState(() { isLoading = true; errorMessage = null; });
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/mySender?key=${widget.sessionKey}'),
      );
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data['valid'] == true) {
        final connections = data['connections'] as List<dynamic>? ?? [];
        connections.sort((a, b) {
          final ag = a['isGlobal'] == true ? 0 : 1;
          final bg = b['isGlobal'] == true ? 0 : 1;
          if (ag != bg) return ag.compareTo(bg);
          return (a['sessionName'] ?? '').toString()
              .compareTo((b['sessionName'] ?? '').toString());
        });
        setState(() => senderList = connections);
      } else {
        setState(() => errorMessage = data['message'] ?? 'Failed to fetch senders');
      }
    } catch (e) {
      setState(() => errorMessage = 'Connection failed: $e');
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _addSender(String number, bool isGlobal) async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
        '$apiBaseUrl/getPairing?key=${widget.sessionKey}&number=$number&global=${isGlobal ? 1 : 0}',
      ));
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data['valid'] == true) {
        _pairingDialog(number, data['pairingCode'].toString());
        _snack('Pairing code generated!');
      } else {
        _snack(data['message'] ?? 'Failed to generate pairing code', err: true);
      }
    } catch (e) {
      _snack('Connection failed: $e', err: true);
    } finally {
      setState(() => isLoading = false);
      _fetchSenders();
    }
  }

  Future<void> _deleteSender(String id, bool isGlobal) async {
    final ok = await _confirmDialog(
      title: 'Delete Sender',
      content: isGlobal
          ? 'Global sender ini akan dihapus untuk semua user.'
          : 'Yakin ingin menghapus sender ini?',
      confirmLabel: 'DELETE',
      confirmColor: _C.danger,
    );
    if (ok != true) return;

    setState(() => isLoading = true);
    try {
      final res = await http.delete(Uri.parse(
        '$apiBaseUrl/deleteSender?key=${widget.sessionKey}&id=$id&scope=${isGlobal ? 'global' : 'private'}',
      ));
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data['valid'] == true) {
        _snack('Sender deleted successfully!');
        _fetchSenders();
      } else {
        _snack(data['message'] ?? 'Failed to delete sender', err: true);
      }
    } catch (e) {
      _snack('Connection failed: $e', err: true);
    } finally {
      setState(() => isLoading = false);
    }
  }

  // ── Dialogs ───────────────────────────────────────────────
  Future<bool?> _confirmDialog({
    required String title,
    required String content,
    required String confirmLabel,
    required Color confirmColor,
  }) {
    return showDialog<bool>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _C.cardBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.cardBorder, width: 2),
            boxShadow: const [
              BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 6)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  color: confirmColor.withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: confirmColor, width: 1.5),
                ),
                child: Icon(Icons.warning_amber_rounded, color: confirmColor, size: 24),
              ),
              const SizedBox(height: 16),
              Text(title, style: _T.heading(18)),
              const SizedBox(height: 8),
              Text(content, style: _T.label(13), textAlign: TextAlign.center),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: _OutlineBtn(
                      label: 'CANCEL',
                      onTap: () => Navigator.pop(context, false),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _GlowBtn(
                      label: confirmLabel,
                      color: confirmColor,
                      onTap: () => Navigator.pop(context, true),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _addDialog({required bool isGlobal}) {
    if (isGlobal && !canAddGlobal) {
      _snack('Hanya owner & developer yang dapat menambahkan Global Sender.', err: true);
      return;
    }
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _C.cardBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.cardBorder, width: 2),
            boxShadow: const [
              BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 6)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                children: [
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: _C.accentSoft,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _C.accent, width: 1.3),
                    ),
                    child: Icon(
                      isGlobal ? Icons.public_rounded : Icons.add_rounded,
                      color: _C.accent, size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    isGlobal ? 'Add Global Sender' : 'Add Sender',
                    style: _T.heading(18),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.only(left: 48),
                child: Text(
                  isGlobal
                      ? 'Sender ini akan bisa dipakai semua user.'
                      : 'Sender ini hanya untuk akun kamu sendiri.',
                  style: _T.label(12),
                ),
              ),
              const SizedBox(height: 20),
              // Phone input
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _C.cardBorder, width: 1.5),
                ),
                child: TextField(
                  controller: ctrl,
                  keyboardType: TextInputType.phone,
                  style: _T.heading(15),
                  cursorColor: _C.accent,
                  decoration: InputDecoration(
                    labelText: 'Phone number',
                    labelStyle: _T.label(13),
                    prefixIcon: const Icon(Icons.phone_android_rounded, color: _C.accent, size: 20),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 4),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: _OutlineBtn(
                      label: 'CANCEL',
                      onTap: () => Navigator.pop(context),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _GlowBtn(
                      label: 'SUBMIT',
                      color: _C.accent,
                      onTap: () async {
                        final number = ctrl.text.trim();
                        if (number.isEmpty) {
                          _snack('Please enter phone number', err: true);
                          return;
                        }
                        Navigator.pop(context);
                        await _addSender(number, isGlobal);
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _pairingDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _C.cardBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.cardBorder, width: 2),
            boxShadow: const [
              BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 6)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  color: _C.accentSoft,
                  shape: BoxShape.circle,
                  border: Border.all(color: _C.accent, width: 1.5),
                ),
                child: const Icon(Icons.qr_code_rounded, color: _C.accent, size: 24),
              ),
              const SizedBox(height: 14),
              Text('Pairing Required', style: _T.heading(18)),
              const SizedBox(height: 4),
              Text(number, style: _T.label(13)),
              const SizedBox(height: 20),
              // Code box
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _C.cardBorder, width: 2),
                  boxShadow: const [
                    BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
                  ],
                ),
                child: SelectableText(
                  code,
                  textAlign: TextAlign.center,
                  style: _T.mono(32),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: _OutlineBtn(
                      label: 'CLOSE',
                      onTap: () {
                        Navigator.pop(context);
                        _fetchSenders();
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _GlowBtn(
                      label: 'COPY',
                      color: _C.cyan,
                      onTap: () async {
                        await Clipboard.setData(ClipboardData(text: code));
                        _snack('Code copied to clipboard!');
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Snackbar ──────────────────────────────────────────────
  void _snack(String msg, {bool err = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              err ? Icons.error_outline_rounded : Icons.check_circle_outline_rounded,
              color: err ? _C.danger : _C.live,
              size: 18,
            ),
            const SizedBox(width: 10),
            Expanded(child: Text(msg, style: _T.heading(13))),
          ],
        ),
        backgroundColor: _C.cardBg,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: err ? _C.danger : _C.live, width: 1.5),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ── Sender card ───────────────────────────────────────────
  Widget _buildCard(Map<String, dynamic> s) {
    final name      = (s['sessionName'] ?? 'WhatsApp Sender').toString();
    final id        = (s['id'] ?? name).toString();
    final isGlobal  = s['isGlobal'] == true;
    final canDelete = s['canDelete'] != false;
    final badgeColor = isGlobal ? _C.accent : _C.cyan;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _C.cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.cardBorder, width: 2),
        boxShadow: const [
          BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top row
          Row(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: badgeColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: badgeColor, width: 1.5),
                ),
                child: Icon(
                  isGlobal ? Icons.public_rounded : Icons.phone_android_rounded,
                  color: badgeColor, size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(name, style: _T.heading(15), overflow: TextOverflow.ellipsis),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: badgeColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: badgeColor, width: 1.3),
                ),
                child: Text(
                  isGlobal ? 'GLOBAL' : 'PRIVATE',
                  style: TextStyle(
                    fontFamily: _T.font,
                    fontSize: 9,
                    color: badgeColor,
                    letterSpacing: 1.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(height: 1.5, color: _C.cardBorder.withOpacity(0.12)),
          const SizedBox(height: 14),
          // Action buttons
          Row(
            children: [
              Expanded(
                child: _OutlineBtn(
                  label: 'REFRESH',
                  icon: Icons.refresh_rounded,
                  onTap: _fetchSenders,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _GlowBtn(
                  label: canDelete ? 'DELETE' : 'LOCKED',
                  color: canDelete ? _C.danger : _C.textMuted,
                  icon: canDelete ? Icons.delete_outline_rounded : Icons.lock_outline_rounded,
                  onTap: canDelete ? () => _deleteSender(id, isGlobal) : null,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bgBottom,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: _C.bgTop.withOpacity(0.95),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          color: _C.textPrimary,
          onPressed: () => Navigator.pop(context),
        ),
        title: RichText(
          text: TextSpan(
            children: [
              TextSpan(text: 'Manage ', style: _T.display(16).copyWith(color: _C.textPrimary)),
              TextSpan(text: 'Sender', style: _T.display(16).copyWith(color: _C.accent)),
            ],
          ),
        ),
        actions: [
          IconButton(
            onPressed: isLoading ? null : _fetchSenders,
            icon: AnimatedRotation(
              turns: isLoading ? 1 : 0,
              duration: const Duration(milliseconds: 600),
              child: const Icon(Icons.refresh_rounded, size: 20),
            ),
            color: _C.textSecondary,
          ),
          const SizedBox(width: 4),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          child: Column(
            children: [
              TabBar(
                controller: _tabCtrl,
                labelColor: _C.accent,
                unselectedLabelColor: _C.textSecondary,
                indicatorColor: _C.accent,
                indicatorWeight: 3,
                labelStyle: TextStyle(
                  fontFamily: _T.font, fontSize: 13,
                  fontWeight: FontWeight.w700, letterSpacing: 0.5,
                ),
                tabs: const [
                  Tab(text: 'MY SENDER', icon: Icon(Icons.phone_android_rounded, size: 18)),
                  Tab(text: 'GLOBAL SENDER', icon: Icon(Icons.public_rounded, size: 18)),
                ],
              ),
              Container(height: 2, color: _C.cardBorder),
            ],
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_C.bgTop, _C.bgBottom],
          ),
        ),
        child: SafeArea(
          child: TabBarView(
            controller: _tabCtrl,
            children: [
              _buildTabBody(
                list: _privateSenders,
                bannerText: 'Sender pribadi hanya bisa dipakai oleh akun kamu sendiri.',
                bannerIcon: Icons.phone_android_rounded,
                emptyTitle: 'No Senders Found',
                emptySubtitle: 'Tap + to add your first sender',
              ),
              _buildTabBody(
                list: _globalSenders,
                bannerText: canAddGlobal
                    ? 'Global sender bisa dipakai semua user. Hanya owner/developer yang bisa menambah.'
                    : 'Global sender bisa dipakai semua user, tapi hanya owner/developer yang bisa menambahkannya.',
                bannerIcon: Icons.public_rounded,
                emptyTitle: 'No Global Sender',
                emptySubtitle: canAddGlobal
                    ? 'Tap + to add a global sender'
                    : 'Belum ada global sender yang ditambahkan',
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: _buildFAB(),
    );
  }

  Widget _buildTabBody({
    required List<dynamic> list,
    required String bannerText,
    required IconData bannerIcon,
    required String emptyTitle,
    required String emptySubtitle,
  }) {
    return Column(
      children: [
        // Info banner
        Container(
          margin: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: _C.cardBg,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _C.cardBorder, width: 1.5),
          ),
          child: Row(
            children: [
              Icon(bannerIcon, color: _C.accent, size: 18),
              const SizedBox(width: 10),
              Expanded(
                child: Text(bannerText, style: _T.label(12)),
              ),
            ],
          ),
        ),

        // Body
        Expanded(
          child: isLoading && senderList.isEmpty
              ? const Center(
                  child: CircularProgressIndicator(
                    color: _C.accent,
                    strokeWidth: 2,
                  ),
                )
              : errorMessage != null && senderList.isEmpty
                  ? _buildEmptyState(
                      icon: Icons.error_outline_rounded,
                      color: _C.danger,
                      title: 'Connection Error',
                      subtitle: errorMessage!,
                    )
                  : list.isEmpty
                      ? _buildEmptyState(
                          icon: Icons.phone_android_rounded,
                          color: _C.accent,
                          title: emptyTitle,
                          subtitle: emptySubtitle,
                        )
                      : RefreshIndicator(
                          onRefresh: _fetchSenders,
                          color: _C.accent,
                          backgroundColor: _C.cardBg,
                          child: ListView.builder(
                            physics: const BouncingScrollPhysics(),
                            padding: const EdgeInsets.only(top: 8, bottom: 100),
                            itemCount: list.length,
                            itemBuilder: (_, i) => _buildCard(
                              Map<String, dynamic>.from(list[i]),
                            ),
                          ),
                        ),
        ),
      ],
    );
  }

  Widget _buildEmptyState({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
  }) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(color: color, width: 1.8),
            ),
            child: Icon(icon, color: color, size: 34),
          ),
          const SizedBox(height: 16),
          Text(title, style: _T.heading(18)),
          const SizedBox(height: 6),
          Text(subtitle, style: _T.label(13)),
        ],
      ),
    );
  }

  Widget _buildFAB() {
    final isGlobalTab = _tabCtrl.index == 1;
    final locked = isGlobalTab && !canAddGlobal;

    return Container(
      decoration: BoxDecoration(
        gradient: locked
            ? null
            : const LinearGradient(
                colors: [_C.accentDim, _C.accent],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        color: locked ? _C.textMuted.withOpacity(0.3) : null,
        shape: BoxShape.circle,
        border: Border.all(color: _C.cardBorder, width: 2),
        boxShadow: const [
          BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
        ],
      ),
      child: FloatingActionButton(
        onPressed: () {
          HapticFeedback.lightImpact();
          if (locked) {
            _snack('Hanya owner & developer yang dapat menambahkan Global Sender.', err: true);
            return;
          }
          _addDialog(isGlobal: isGlobalTab);
        },
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        elevation: 0,
        child: Icon(locked ? Icons.lock_outline_rounded : Icons.add_rounded),
      ),
    );
  }
}

// ── Reusable Buttons ──────────────────────────────────────
class _GlowBtn extends StatelessWidget {
  final String label;
  final Color color;
  final IconData? icon;
  final VoidCallback? onTap;

  const _GlowBtn({
    required this.label,
    required this.color,
    this.icon,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return GestureDetector(
      onTap: enabled ? () {
        HapticFeedback.lightImpact();
        onTap!();
      } : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: enabled ? color.withOpacity(0.12) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: enabled ? color : _C.cardBorder.withOpacity(0.3),
            width: enabled ? 1.8 : 1.5,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, color: enabled ? color : _C.textMuted, size: 16),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: TextStyle(
                fontFamily: _T.font,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: enabled ? color : _C.textMuted,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OutlineBtn extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback onTap;

  const _OutlineBtn({required this.label, required this.onTap, this.icon});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.cardBorder, width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, color: _C.textSecondary, size: 16),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: TextStyle(
                fontFamily: _T.font,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: _C.textSecondary,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}