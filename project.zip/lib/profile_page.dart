// profile_page.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'change_password_page.dart';

// ── Design Tokens (tema terang, selaras dengan dashboard_page.dart) ─────
class AppColors {
  static const bgTop = Color(0xFFEAF4FF);
  static const bgBottom = Color(0xFFCFE7FF);

  static const cardBg = Color(0xFFF3F8FF);
  static const cardBorder = Color(0xFF0B0B0B);

  static const textPrimary = Color(0xFF10131A);
  static const textSecondary = Color(0xFF7A8394);
  static const textMuted = Color(0xFFA3ADBD);

  static const accent = Color(0xFF2F6FED);
  static const accentDim = Color(0xFF1B4FC4);
  static const accentGlow = Color(0x332F6FED);
  static const accentSoft = Color(0x1A2F6FED);

  static const cyan = Color(0xFF57A6FF);
  static const cyanDim = Color(0xFF2F6FED);
  static const cyanGlow = Color(0x3357A6FF);

  static const live = Color(0xFF16A34A);
  static const liveGlow = Color(0x4416A34A);
  static const danger = Color(0xFFE0245E);
  static const warning = Color(0xFFC98A00);

  static const border = Color(0xFFB9D3F2);
  static const borderBright = Color(0xFF0B0B0B);
}

class AppTextStyles {
  static const String font = 'Rajdhani';

  static TextStyle display(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w800,
    color: AppColors.textPrimary, letterSpacing: 1,
  );
  static TextStyle heading(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: AppColors.textPrimary, letterSpacing: 0.3,
  );
  static TextStyle label(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w500,
    color: AppColors.textSecondary, letterSpacing: 0.2,
  );
}

// ══════════════════════════════════════════════════════════
// PROFILE PAGE
// ══════════════════════════════════════════════════════════
class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with SingleTickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _loadProfileImage();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_${widget.username}');
    if (path != null && path.isNotEmpty) {
      setState(() => _profileImage = File(path));
    }
  }

  String _censor(String text, {bool isPassword = false}) {
    if (text.isEmpty) return 'N/A';
    if (isPassword) return '••••••••';
    if (text.length <= 2) return '${text[0]}••';
    return '${text.substring(0, 2)}${'•' * (text.length - 2)}';
  }

  Color get _roleColor {
    switch (widget.role.toLowerCase()) {
      case 'owner':    return AppColors.warning;
      case 'admin':    return AppColors.danger;
      case 'reseller': return AppColors.live;
      case 'vip':      return AppColors.cyan;
      default:         return AppColors.accent;
    }
  }

  Future<void> _showImageSourceSheet() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: AppColors.cardBg,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: AppColors.cardBorder, width: 2),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12, bottom: 8),
                width: 36, height: 4,
                decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(4)),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: Text('Change Photo', style: AppTextStyles.heading(16)),
              ),
              _sheetOption(Icons.camera_alt_rounded, 'Camera', AppColors.accent, () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              }),
              _sheetOption(Icons.photo_library_rounded, 'Gallery', AppColors.cyan, () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              }),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sheetOption(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.bgTop,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.cardBorder, width: 1.5),
        ),
        child: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: color.withOpacity(0.4)),
              ),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 14),
            Text(label, style: AppTextStyles.heading(14)),
            const Spacer(),
            Icon(Icons.arrow_forward_ios_rounded, color: AppColors.textMuted, size: 13),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? picked = await _picker.pickImage(source: source, imageQuality: 70);
      if (picked != null) {
        final file = File(picked.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', file.path);
        setState(() => _profileImage = file);
      }
    } catch (e) {
      debugPrint('Error picking image: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBottom,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: AppColors.bgTop.withOpacity(0.95),
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          color: AppColors.textPrimary,
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'My Profile',
          style: TextStyle(
            fontFamily: AppTextStyles.font,
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: AppColors.accent,
            letterSpacing: 1.5,
          ),
        ),
        centerTitle: true,
        flexibleSpace: ClipRect(
          child: Container(
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: AppColors.cardBorder, width: 2),
              ),
            ),
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.bgTop, AppColors.bgBottom],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                const SizedBox(height: 28),
                _buildAvatar(),
                const SizedBox(height: 16),
                _buildNameBadge(),
                const SizedBox(height: 32),
                _buildInfoGrid(),
                const SizedBox(height: 32),
                _buildChangePasswordBtn(),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAvatar() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        _showImageSourceSheet();
      },
      child: AnimatedBuilder(
        animation: _pulseAnim,
        builder: (_, __) => Stack(
          alignment: Alignment.center,
          children: [
            // Glow ring
            Container(
              width: 130, height: 130,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accent.withOpacity(_pulseAnim.value * 0.35),
                    blurRadius: 28, spreadRadius: 3,
                  ),
                ],
              ),
            ),
            // Border ring
            Container(
              width: 120, height: 120,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.cardBorder, width: 2),
              ),
              child: ClipOval(
                child: _profileImage != null
                    ? Image.file(_profileImage!, fit: BoxFit.cover)
                    : Container(
                        color: AppColors.cardBg,
                        child: const Icon(
                          FontAwesomeIcons.userAstronaut,
                          size: 46,
                          color: AppColors.accent,
                        ),
                      ),
              ),
            ),
            // Camera badge
            Positioned(
              bottom: 4,
              right: 4,
              child: Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: AppColors.accent,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.bgTop, width: 2.5),
                  boxShadow: [BoxShadow(color: AppColors.accentGlow, blurRadius: 10)],
                ),
                child: const Icon(Icons.camera_alt_rounded, size: 14, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNameBadge() {
    return Column(
      children: [
        Text(
          widget.username,
          style: AppTextStyles.display(24).copyWith(color: AppColors.accent),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: BoxDecoration(
            color: _roleColor.withOpacity(0.12),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _roleColor, width: 1.5),
          ),
          child: Text(
            widget.role.toUpperCase(),
            style: TextStyle(
              fontFamily: AppTextStyles.font, fontSize: 10, fontWeight: FontWeight.w700,
              color: _roleColor, letterSpacing: 2,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInfoGrid() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(child: _infoCard(Icons.person_outline_rounded, 'Username', _censor(widget.username))),
            const SizedBox(width: 14),
            Expanded(child: _infoCard(Icons.lock_outline_rounded, 'Password', _censor(widget.password, isPassword: true))),
          ],
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(child: _infoCard(Icons.verified_user_outlined, 'Role', widget.role.toUpperCase(), valueColor: _roleColor)),
            const SizedBox(width: 14),
            Expanded(child: _infoCard(Icons.calendar_today_rounded, 'Expired', widget.expiredDate)),
          ],
        ),
        const SizedBox(height: 14),
        _infoCard(
          Icons.vpn_key_rounded,
          'Session Key',
          '${widget.sessionKey.substring(0, 8)}••••••••',
          fullWidth: true,
        ),
      ],
    );
  }

  Widget _infoCard(
    IconData icon,
    String label,
    String value, {
    bool fullWidth = false,
    Color? valueColor,
  }) {
    return Container(
      width: fullWidth ? double.infinity : null,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder, width: 2),
        boxShadow: const [
          BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(2, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: AppColors.accentSoft,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.accent.withOpacity(0.4)),
                ),
                child: Icon(icon, color: AppColors.accent, size: 14),
              ),
              const SizedBox(width: 8),
              Expanded(child: Text(label, style: AppTextStyles.label(11), overflow: TextOverflow.ellipsis)),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: AppTextStyles.heading(14).copyWith(color: valueColor ?? AppColors.textPrimary),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }

  Widget _buildChangePasswordBtn() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ChangePasswordPage(
              username: widget.username,
              sessionKey: widget.sessionKey,
            ),
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.accentDim, AppColors.accent],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.cardBorder, width: 2),
          boxShadow: const [
            BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.lock_reset_rounded, color: Colors.white, size: 20),
            const SizedBox(width: 10),
            Text('CHANGE PASSWORD', style: AppTextStyles.heading(15).copyWith(color: Colors.white, letterSpacing: 1)),
          ],
        ),
      ),
    );
  }
}