/// OXVA API integration contract.
/// Base URL: config.dart.
/// Chat/private/status/catalog routes are connected to the supplied API.
/// Destructive payload/RAT execution endpoints are intentionally not called.
const String oxvaApiCompatibility = 'safe-compat-1';
