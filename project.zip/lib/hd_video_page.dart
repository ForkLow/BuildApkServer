import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:video_player/video_player.dart';

class HdVideoPage extends StatefulWidget {
  const HdVideoPage({super.key});

  @override
  State<HdVideoPage> createState() => _HdVideoPageState();
}

class _HdVideoPageState extends State<HdVideoPage> {
  static const _blue = Color(0xFF2F6FED);
  static const _blue2 = Color(0xFF57A6FF);
  static const _bg = Color(0xFF07090F);
  static const _card = Color(0xFF0E1420);
  static const _border = Color(0xFF263C66);
  static const _endpoint = 'https://api.nexray.eu.cc/tools/v1/hdvideo?resolusi=hd';

  final _urlController = TextEditingController();
  File? _inputVideo;
  String? _resultUrl;
  File? _resultFile;
  VideoPlayerController? _preview;
  bool _processing = false;
  double _progress = 0;
  String _status = 'Pilih video untuk mulai.';

  @override
  void dispose() {
    _urlController.dispose();
    _preview?.dispose();
    super.dispose();
  }

  Future<void> _pickVideo() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.video, withData: false);
    if (result == null || result.files.single.path == null) return;
    setState(() {
      _inputVideo = File(result.files.single.path!);
      _resultUrl = null;
      _resultFile = null;
      _status = 'Video siap diproses dalam kualitas HD.';
    });
  }

  Future<http.Response> _multipart(String endpoint, String fieldName) async {
    final request = http.MultipartRequest('POST', Uri.parse(endpoint));
    request.headers['Accept'] = 'application/json, video/*, application/octet-stream, text/plain, */*';
    request.fields['resolusi'] = 'hd';
    final bytes = await _inputVideo!.readAsBytes();
    final filename = _inputVideo!.path.split(Platform.pathSeparator).last;
    request.files.add(http.MultipartFile.fromBytes(fieldName, bytes, filename: filename));
    final streamed = await request.send().timeout(const Duration(minutes: 5));
    return http.Response.fromStream(streamed);
  }

  Future<http.Response> _jsonUrl(String endpoint, String url) async {
    return http.post(
      Uri.parse(endpoint),
      headers: const {'Content-Type': 'application/json', 'Accept': 'application/json, text/plain, */*'},
      body: jsonEncode({'url': url, 'videoUrl': url, 'video_url': url, 'link': url, 'resolusi': 'hd'}),
    ).timeout(const Duration(minutes: 5));
  }

  Future<http.Response> _getUrl(String endpoint, String url) async {
    final base = Uri.parse(endpoint);
    final uri = base.replace(queryParameters: {
      ...base.queryParameters,
      'url': url,
      'videoUrl': url,
      'video_url': url,
      'link': url,
      'resolusi': 'hd',
    });
    return http.get(uri, headers: const {'Accept': 'application/json, video/*, application/octet-stream, text/plain, */*'})
        .timeout(const Duration(minutes: 5));
  }

  Future<http.Response> _processRequest() async {
    final endpoints = <String>[_endpoint, '$_endpoint&'];
    http.Response? last;

    if (_inputVideo != null) {
      // Different Nexray deployments have used either "video" or "file" for multipart input.
      for (final endpoint in [_endpoint, 'https://api.nexray.eu.cc/tools/v1/hdvideo']) {
        for (final field in ['video', 'file']) {
          final response = await _multipart(endpoint, field);
          last = response;
          if (response.statusCode != 404) return response;
        }
      }
    } else {
      final url = _urlController.text.trim();
      for (final endpoint in [_endpoint, 'https://api.nexray.eu.cc/tools/v1/hdvideo']) {
        final post = await _jsonUrl(endpoint, url);
        last = post;
        if (post.statusCode != 404) return post;
        final get = await _getUrl(endpoint, url);
        last = get;
        if (get.statusCode != 404) return get;
      }
    }
    return last ?? (throw const SocketException('Server HD tidak dapat dijangkau.'));
  }

  Future<void> _processHd() async {
    if (_inputVideo == null && _urlController.text.trim().isEmpty) {
      _snack('Pilih video atau masukkan URL video terlebih dahulu.');
      return;
    }

    setState(() {
      _processing = true;
      _progress = 0.12;
      _status = 'Mengirim video ke AZZORIBLE HD Engine...';
      _resultUrl = null;
      _resultFile = null;
    });

    try {
      final response = await _processRequest();
      if (!mounted) return;
      setState(() => _progress = 0.72);

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Server HD mengembalikan HTTP ${response.statusCode}: ${_shorten(response.body)}');
      }

      final contentType = response.headers['content-type'] ?? '';
      if (contentType.contains('video/') || contentType.contains('octet-stream')) {
        final dir = await getTemporaryDirectory();
        final file = File('${dir.path}/azzorible_hd_${DateTime.now().millisecondsSinceEpoch}.mp4');
        await file.writeAsBytes(response.bodyBytes, flush: true);
        await _showResultFile(file);
      } else {
        final decoded = _tryJson(response.body);
        final extractedUrl = _extractUrl(decoded) ?? _plainUrl(response.body);
        if (extractedUrl != null) {
          setState(() {
            _resultUrl = extractedUrl;
            _status = 'Video HD berhasil dibuat.';
          });
        } else {
          final base64Value = _extractBase64(decoded);
          if (base64Value == null) throw Exception('Respons API tidak berisi URL atau file HD yang dikenali.');
          final bytes = base64Decode(base64Value.contains(',') ? base64Value.split(',').last : base64Value);
          final dir = await getTemporaryDirectory();
          final file = File('${dir.path}/azzorible_hd_${DateTime.now().millisecondsSinceEpoch}.mp4');
          await file.writeAsBytes(bytes, flush: true);
          await _showResultFile(file);
        }
      }
      if (mounted) {
        setState(() {
          _processing = false;
          _progress = 1;
          _status = 'Selesai — video HD siap diputar.';
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _processing = false;
        _progress = 0;
        _status = 'Gagal memproses video.';
      });
      _snack('HD Video gagal: ${_friendlyError(e)}');
    }
  }

  String _shorten(String value) {
    final v = value.trim();
    return v.length > 500 ? '${v.substring(0, 500)}…' : v;
  }

  String _friendlyError(Object e) {
    final s = e.toString();
    if (s.contains('SocketException')) return 'Server HD tidak dapat dijangkau.';
    if (s.contains('TimeoutException')) return 'Server HD terlalu lama merespons.';
    return s.replaceFirst('Exception: ', '');
  }

  dynamic _tryJson(String text) {
    try { return jsonDecode(text); } catch (_) { return null; }
  }

  String? _plainUrl(String text) {
    final value = text.trim();
    return value.startsWith('http://') || value.startsWith('https://') ? value : null;
  }

  String? _extractUrl(dynamic data) {
    if (data is String) return _plainUrl(data);
    if (data is List) {
      for (final item in data) {
        final found = _extractUrl(item);
        if (found != null) return found;
      }
    }
    if (data is Map) {
      for (final key in ['url', 'videoUrl', 'video_url', 'download', 'downloadUrl', 'result', 'output', 'link']) {
        final found = _extractUrl(data[key]);
        if (found != null) return found;
      }
      for (final key in ['data', 'result']) {
        final found = _extractUrl(data[key]);
        if (found != null) return found;
      }
    }
    return null;
  }

  String? _extractBase64(dynamic data) {
    if (data is String && data.length > 100 && !data.startsWith('http')) return data;
    if (data is List) {
      for (final item in data) {
        final found = _extractBase64(item);
        if (found != null) return found;
      }
    }
    if (data is Map) {
      for (final key in ['base64', 'video', 'file', 'buffer']) {
        final value = data[key];
        if (value is String && value.length > 100) return value;
      }
      return _extractBase64(data['data']);
    }
    return null;
  }

  Future<void> _showResultFile(File file) async {
    _preview?.dispose();
    final controller = VideoPlayerController.file(file);
    await controller.initialize();
    await controller.setLooping(true);
    await controller.play();
    if (!mounted) return;
    setState(() {
      _resultFile = file;
      _preview = controller;
      _status = 'Video HD berhasil dibuat.';
    });
  }

  void _snack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('AZZORIBLE HD VIDEO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5)),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [_hero(), const SizedBox(height: 14), _inputCard(), const SizedBox(height: 14), _resultCard()],
        ),
      ),
    );
  }

  Widget _hero() => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [_blue, _blue2]),
      borderRadius: BorderRadius.circular(24),
      boxShadow: const [BoxShadow(color: Color(0x552F6FED), blurRadius: 22)],
    ),
    child: const Row(children: [
      Icon(Icons.high_quality_rounded, color: Colors.white, size: 42),
      SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('NGE-HD-IN VIDEO', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 1)),
        SizedBox(height: 4),
        Text('Naikkan kualitas video melalui AZZORIBLE HD Engine.', style: TextStyle(color: Colors.white70, fontSize: 12)),
      ])),
    ]),
  );

  Widget _inputCard() => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(22), border: Border.all(color: _border)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('VIDEO INPUT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, letterSpacing: 1)),
      const SizedBox(height: 12),
      GestureDetector(
        onTap: _processing ? null : _pickVideo,
        child: Container(
          height: 130,
          width: double.infinity,
          decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(18), border: Border.all(color: _blue2)),
          child: _inputVideo == null
              ? const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.video_library_rounded, color: _blue2, size: 36),
                  SizedBox(height: 8),
                  Text('Pilih Video', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                  SizedBox(height: 3),
                  Text('MP4 / MOV / video lain', style: TextStyle(color: Colors.white54, fontSize: 11)),
                ])
              : const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.check_circle_rounded, color: Colors.greenAccent, size: 36),
                  SizedBox(height: 8),
                  Text('Video siap di-HD-kan', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                ]),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _urlController,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          hintText: 'Atau tempel URL video...',
          hintStyle: const TextStyle(color: Colors.white38),
          prefixIcon: const Icon(Icons.link_rounded, color: _blue2),
          filled: true,
          fillColor: Colors.black26,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 14),
      if (_processing) ...[LinearProgressIndicator(value: _progress, color: _blue2, backgroundColor: Colors.white12), const SizedBox(height: 10)],
      Text(_status, style: const TextStyle(color: Colors.white54, fontSize: 11)),
      const SizedBox(height: 12),
      SizedBox(
        width: double.infinity,
        height: 54,
        child: ElevatedButton.icon(
          onPressed: _processing ? null : _processHd,
          icon: const Icon(Icons.auto_fix_high_rounded),
          label: Text(_processing ? 'SEDANG MEMPROSES...' : 'CLICK HD IN VIDEO'),
          style: ElevatedButton.styleFrom(
            backgroundColor: _blue,
            foregroundColor: Colors.white,
            disabledBackgroundColor: _blue.withOpacity(.35),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
        ),
      ),
    ]),
  );

  Widget _resultCard() => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(22), border: Border.all(color: _border)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('HASIL HD', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, letterSpacing: 1)),
      const SizedBox(height: 12),
      if (_preview != null && _preview!.value.isInitialized)
        AspectRatio(aspectRatio: _preview!.value.aspectRatio, child: ClipRRect(borderRadius: BorderRadius.circular(14), child: VideoPlayer(_preview!)))
      else if (_resultUrl != null)
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            const Icon(Icons.ondemand_video_rounded, color: _blue2),
            const SizedBox(width: 10),
            Expanded(child: Text(_resultUrl!, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 11))),
          ]),
        )
      else
        const Padding(padding: EdgeInsets.all(18), child: Center(child: Text('Hasil video HD akan muncul di sini.', style: TextStyle(color: Colors.white38)))),
    ]),
  );
}
