
import 'package:flutter/material.dart';
class AddGmailPage extends StatelessWidget {
  const AddGmailPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AZZORIBLE - Add Gmail')),
      body: const Center(child: Text('Add Gmail Page')),
    );
  }
}
