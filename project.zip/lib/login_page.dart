// login_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'splash.dart';
import 'config.dart';

// ── Design Tokens (tema terang, sama dengan halaman lain) ──
class _C {
  static const bgTop = Color(0xFFEAF4FF);
  static const bgBottom = Color(0xFFCFE7FF);

  static const cardBg = Color(0xFFF3F8FF);
  static const cardBorder = Color(0xFF0B0B0B);

  static const accent     = Color(0xFF2F6FED);
  static const accentDim  = Color(0xFF1B4FC4);
  static const accentSoft = Color(0x1A2F6FED);

  static const cyan     = Color(0xFF57A6FF);

  static const danger  = Color(0xFFE0245E);
  static const warning = Color(0xFFC98A00);

  static const textPrimary   = Color(0xFF10131A);
  static const textSecondary = Color(0xFF7A8394);
  static const textMuted     = Color(0xFFA3ADBD);
}

class _T {
  static const font = 'Rajdhani';
  static TextStyle display(double s) => TextStyle(fontFamily: font, fontSize: s, fontWeight: FontWeight.w800, color: _C.textPrimary, letterSpacing: 1);
  static TextStyle heading(double s) => TextStyle(fontFamily: font, fontSize: s, fontWeight: FontWeight.w700, color: _C.textPrimary, letterSpacing: 0.3);
  static TextStyle label(double s)   => TextStyle(fontFamily: font, fontSize: s, fontWeight: FontWeight.w500, color: _C.textSecondary, letterSpacing: 0.2);
}

// ══════════════════════════════════════════════════════════
// LOGIN PAGE
// ══════════════════════════════════════════════════════════
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _formKey  = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscure  = true;
  String? androidId;

  late AnimationController _entryCtrl;
  late AnimationController _pulseCtrl;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();

    _entryCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);

    _fadeAnim  = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic));
    _pulseAnim = Tween<double>(begin: 0.5, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _initLogin();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _pulseCtrl.dispose();
    _userCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _initLogin() async {
    androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey  = prefs.getString('key');

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
        '$apiBaseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey',
      );
      try {
        final res  = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          _goToSplash(savedUser, savedPass, data);
        }
      } catch (_) {}
    }
  }

  Future<String> _getAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    return info.id ?? 'unknown_device';
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    HapticFeedback.lightImpact();
    final username = _userCtrl.text.trim();
    final password = _passCtrl.text.trim();
    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse('$apiBaseUrl/validate'),
        body: {
          'username': username,
          'password': password,
          'androidId': androidId ?? 'unknown_device',
        },
      );
      final data = jsonDecode(res.body);

      if (data['expired'] == true) {
        _showDialog(
          icon: Icons.timer_off_rounded,
          iconColor: _C.warning,
          title: 'Akses Habis',
          message: 'Masa akses Anda telah berakhir. Silakan perpanjang.',
          showContact: true,
        );
      } else if (data['valid'] != true) {
        final msg = (data['message'] ?? '').toString().toLowerCase();
        final isDevice = msg.contains('perangkat') || msg.contains('device') || msg.contains('another');
        _showDialog(
          icon: isDevice ? Icons.devices_other_rounded : Icons.lock_person_rounded,
          iconColor: _C.danger,
          title: isDevice ? 'Sesi Aktif' : 'Login Gagal',
          message: isDevice
              ? 'Akun ini sedang login di perangkat lain. Logout terlebih dahulu.'
              : 'Username atau password salah.',
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('username', username);
        await prefs.setString('password', password);
        await prefs.setString('key', data['key']);
        if (mounted) _goToSplash(username, password, data);
      }
    } catch (e) {
      _showDialog(
        icon: Icons.wifi_off_rounded,
        iconColor: _C.danger,
        title: 'Koneksi Error',
        message: 'Gagal terhubung ke server. Periksa internet Anda.',
      );
    }

    setState(() => isLoading = false);
  }

  void _goToSplash(String user, String pass, Map data) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => SplashScreen(
          username: user,
          password: pass,
          role: data['role'],
          sessionKey: data['key'],
          expiredDate: data['expiredDate'],
          listBug: (data['listBug'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
          listDoos: (data['listDDoS'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
          news: (data['news'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
        ),
      ),
    );
  }

  void _showDialog({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String message,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _C.cardBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.cardBorder, width: 2),
            boxShadow: const [
              BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(4, 6)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 52, height: 52,
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: iconColor, width: 1.5),
                ),
                child: Icon(icon, color: iconColor, size: 26),
              ),
              const SizedBox(height: 14),
              Text(title, style: _T.heading(18)),
              const SizedBox(height: 8),
              Text(message, style: _T.label(13), textAlign: TextAlign.center),
              const SizedBox(height: 24),
              if (showContact)
                GestureDetector(
                  onTap: () async {
                    await launchUrl(Uri.parse('https://t.me/vcsja'), mode: LaunchMode.externalApplication);
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    margin: const EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                      color: _C.accentSoft,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _C.accent, width: 1.5),
                    ),
                    child: Text('Hubungi Admin', style: _T.heading(14).copyWith(color: _C.accent), textAlign: TextAlign.center),
                  ),
                ),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _C.cardBorder, width: 1.5),
                  ),
                  child: Text('Tutup', style: _T.heading(14).copyWith(color: _C.textSecondary), textAlign: TextAlign.center),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bgBottom,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_C.bgTop, _C.bgBottom],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: SlideTransition(
              position: _slideAnim,
              child: Center(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 20),
                      _buildLogo(),
                      const SizedBox(height: 32),
                      _buildTitleBlock(),
                      const SizedBox(height: 48),
                      Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            _buildInput(_userCtrl, 'Username', Icons.person_outline_rounded),
                            const SizedBox(height: 16),
                            _buildInput(_passCtrl, 'Password', Icons.lock_outline_rounded, isPassword: true),
                            const SizedBox(height: 36),
                            _buildLoginBtn(),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      _buildBottomLinks(),
                      const SizedBox(height: 24),
                      _buildFooter(),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogo() {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, __) => Hero(
        tag: 'logo',
        child: Container(
          width: 100, height: 100,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: _C.cardBorder, width: 2),
            boxShadow: [
              BoxShadow(
                color: _C.accent.withOpacity(_pulseAnim.value * 0.35),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(26),
            child: Image.asset('assets/images/login.png', fit: BoxFit.cover),
          ),
        ),
      ),
    );
  }

  Widget _buildTitleBlock() {
    return Column(
      children: [
        RichText(
          text: TextSpan(
            children: [
              TextSpan(text: 'Welcome ', style: _T.display(32).copyWith(color: _C.textPrimary)),
              TextSpan(text: 'Back', style: _T.display(32).copyWith(color: _C.accent)),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text('Masuk ke akun Anda', style: _T.label(15)),
      ],
    );
  }

  Widget _buildInput(
    TextEditingController ctrl,
    String label,
    IconData icon, {
    bool isPassword = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.cardBorder, width: 2),
      ),
      child: TextFormField(
        controller: ctrl,
        obscureText: isPassword ? _obscure : false,
        style: _T.heading(15),
        cursorColor: _C.accent,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: _T.label(13),
          prefixIcon: Icon(icon, color: _C.accent, size: 20),
          suffixIcon: isPassword
              ? IconButton(
                  icon: Icon(
                    _obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                    color: _C.textMuted,
                    size: 20,
                  ),
                  onPressed: () => setState(() => _obscure = !_obscure),
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: _C.accent, width: 2),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Colors.transparent),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: _C.danger),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: _C.danger, width: 2),
          ),
        ),
        validator: (v) => (v == null || v.isEmpty) ? '$label tidak boleh kosong' : null,
      ),
    );
  }

  Widget _buildLoginBtn() {
    final w = MediaQuery.of(context).size.width - 56;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      width: isLoading ? 58 : w,
      height: 56,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_C.accentDim, _C.accent],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: _C.cardBorder, width: 2),
        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 5))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: isLoading ? null : _login,
          borderRadius: BorderRadius.circular(30),
          child: Center(
            child: isLoading
                ? const SizedBox(
                    width: 24, height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                  )
                : Text(
                    'Sign In',
                    style: _T.heading(17).copyWith(color: Colors.white, letterSpacing: 1.2),
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildBottomLinks() {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(text: 'Developer? ', style: _T.label(13)),
          TextSpan(
            text: 'CLICK TO',
            style: _T.heading(13).copyWith(color: _C.accent, letterSpacing: 0.5),
            recognizer: TapGestureRecognizer()
              ..onTap = () async {
                await launchUrl(Uri.parse('https://t.me/SenzOkkotsu'), mode: LaunchMode.externalApplication);
              },
          ),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Text('© 2026 AZZORIBLE OFFICIAL', style: _T.label(11));
  }
}