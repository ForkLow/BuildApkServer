// landing_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'buy_account_page.dart';

// ── Design Tokens ──────────────────────────────────────────
class _C {
  static const bgTop = Color(0xFFEAF4FF);
  static const bgBottom = Color(0xFFCFE7FF);

  static const cardBg = Color(0xFFF3F8FF);
  static const cardBorder = Color(0xFF0B0B0B);

  static const textDark = Color(0xFF10131A);
  static const textGrey = Color(0xFF7A8394);

  static const blue = Color(0xFF2F6FED);
  static const blueDark = Color(0xFF1B4FC4);
  static const blueLight = Color(0xFF57A6FF);

  static const pink = Color(0xFFFF7FC0);
  static const yellow = Color(0xFFFFD93B);
}

class _T {
  static const font = 'Rajdhani';

  static TextStyle title(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w800,
    color: _C.textDark, letterSpacing: 0.5,
  );
  static TextStyle heading(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w700,
    color: _C.textDark,
  );
  static TextStyle body(double size) => TextStyle(
    fontFamily: font, fontSize: size, fontWeight: FontWeight.w500,
    color: _C.textGrey, height: 1.4,
  );
}

// ── Links ──────────────────────────────────────────────────
const String kDeveloperTelegramUrl = 'https://t.me/SenzOkkotsu';
const String kCreatorTelegramUrl = 'https://t.me/SenzOkkotsu';

// ── Landing Page ───────────────────────────────────────────
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  late AnimationController _entryCtrl;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _fadeAnim = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.15),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic));
    _entryCtrl.forward();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    super.dispose();
  }

  Future<void> _openTelegram(String url) async {
    HapticFeedback.lightImpact();
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bgBottom,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_C.bgTop, _C.bgBottom],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: SlideTransition(
              position: _slideAnim,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeaderImage(),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 28),
                          _buildTitle(),
                          const SizedBox(height: 16),
                          _buildSubtitle(),
                          const SizedBox(height: 28),
                          _buildInfoCard(),
                          const SizedBox(height: 24),
                          _buildSignInButton(),
                          const SizedBox(height: 14),
                          _buildDevCreatorRow(),
                          const SizedBox(height: 14),
                          _buildBuyButton(),
                          const SizedBox(height: 32),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── Header image (top banner) ──────────────────────────────
  Widget _buildHeaderImage() {
    return SizedBox(
      width: double.infinity,
      height: 240,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/landing.png',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              color: _C.bgTop,
              child: const Icon(Icons.image_not_supported_rounded,
                  size: 48, color: _C.textGrey),
            ),
          ),
          // fade into background at bottom, like the screenshot
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: 90,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    _C.bgTop.withOpacity(0.6),
                    _C.bgTop,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Title ───────────────────────────────────────────────────
  Widget _buildTitle() {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(
            text: 'AZZORIBLE ',
            style: _T.title(40).copyWith(color: _C.textDark),
          ),
          TextSpan(
            text: 'LUCIENT',
            style: _T.title(40).copyWith(color: _C.blue),
          ),
        ],
      ),
    );
  }

  // ── Subtitle ────────────────────────────────────────────────
  Widget _buildSubtitle() {
    return Text(
      'Aplikasi Yang Dikembangkan oleh Tim AZZORIBLE OFFICIAL',
      style: _T.body(17).copyWith(color: _C.textGrey, fontWeight: FontWeight.w600),
    );
  }

  // ── Info card ───────────────────────────────────────────────
  Widget _buildInfoCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _C.cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.cardBorder, width: 2),
        boxShadow: const [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 0,
            offset: Offset(4, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.info_outline_rounded, color: _C.blue, size: 22),
              const SizedBox(width: 8),
              Text('ABOUT AZZORIBLE', style: _T.heading(20)),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            'AZZORIBLE LUCIENT adalah platform tools canggih yang dirancang untuk '
            'memberikan performa terbaik. Dikembangkan secara profesional oleh '
            'tim AZZORIBLE OFFICIAL dengan teknologi mutakhir dan sistem keamanan tinggi.',
            style: _T.body(16),
          ),
        ],
      ),
    );
  }

  // ── Sign In button ─────────────────────────────────────────
  Widget _buildSignInButton() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        Navigator.pushNamed(context, '/login');
      },
      child: Container(
        width: double.infinity,
        height: 58,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [_C.blueDark, _C.blue],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.cardBorder, width: 2),
          boxShadow: const [
            BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 5)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.login_rounded, color: Colors.white, size: 20),
            const SizedBox(width: 10),
            Text('Sign-In To AZZORIBLE',
                style: _T.heading(17).copyWith(color: Colors.white)),
            const SizedBox(width: 8),
            const Icon(Icons.chevron_right_rounded, color: Colors.white, size: 22),
          ],
        ),
      ),
    );
  }

  // ── Developer / Creator row ─────────────────────────────────
  Widget _buildDevCreatorRow() {
    return Row(
      children: [
        Expanded(
          child: _buildTeleButton(
            label: 'Developer',
            colors: const [_C.blueDark, _C.blue],
            url: kDeveloperTelegramUrl,
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: _buildTeleButton(
            label: 'Creator',
            colors: const [_C.blue, _C.blueLight],
            url: kCreatorTelegramUrl,
          ),
        ),
      ],
    );
  }

  Widget _buildTeleButton({
    required String label,
    required List<Color> colors,
    required String url,
  }) {
    return GestureDetector(
      onTap: () => _openTelegram(url),
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: colors),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.cardBorder, width: 2),
          boxShadow: const [
            BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.send_rounded, size: 14, color: _C.blue),
            ),
            const SizedBox(width: 8),
            Text(label, style: _T.heading(15).copyWith(color: Colors.white)),
          ],
        ),
      ),
    );
  }

  // ── Buy Access button ──────────────────────────────────────
  Widget _buildBuyButton() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const BuyAccountPage()),
        );
      },
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          color: _C.cardBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.cardBorder, width: 2),
          boxShadow: const [
            BoxShadow(color: Colors.black26, blurRadius: 0, offset: Offset(3, 4)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.shopping_bag_rounded, color: _C.blue, size: 20),
            const SizedBox(width: 10),
            Text('Buy Access', style: _T.heading(17).copyWith(color: _C.blue)),
          ],
        ),
      ),
    );
  }
}